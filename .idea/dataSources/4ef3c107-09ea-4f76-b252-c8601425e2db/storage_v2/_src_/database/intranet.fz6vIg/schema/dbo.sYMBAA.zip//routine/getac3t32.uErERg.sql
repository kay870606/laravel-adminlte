-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[getac3t32] (@pl1no char(4),@ac3yy char(4),@bmm char(2),@emm char(2),@dp1lun char(1))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	declare @ac1tyy char(4),@ac1cyy char(4),@ac1pyy char(4)
	declare @run varchar(600),@ac2no1 char(4),@ac2no2 char(4),@ac2no3 char(4)
	declare @accok char(1)
	
	set @ac2no1='1110'
	set @ac2no2='1120'
	set @ac2no3='1130'
	select @accok=accok from intranet.dbo.depcode where dp1no=@pl1no
	select @ac1tyy=ac1tyy,@ac1cyy=ac1cyy,@ac1pyy=ac1pyy from intranet.dbo.ac1yy
	create table #tmp (ad1no char(8) COLLATE Chinese_Taiwan_Stroke_CI_AS)
	if @dp1lun='T'
	begin
		if @ac3yy<=@ac1tyy
		begin
			set @run='select DISTINCT ad2.ad1no from intranet.dbo.ad1'+@ac3yy+' as ad1,intranet.dbo.ad2'+@ac3yy+' as ad2 where ad1.ad1no=ad2.ad1no and ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+@pl1no+''' and YEAR(ad1.ad1date)='+@ac3yy+' and ad2.ad1yy='+@ac3yy+' and MONTH(ad1.ad1date) between '+@bmm+' and '+@emm+' and ad2.ac2no in ('''+@ac2no1+''','''+@ac2no2+''','''+@ac2no3+''')'
			insert into #tmp (ad1no) exec (@run)
			set @run='select ad2.ac2no,ad2.ac2no2,ad2.ac2name,ad2.ad1dc,SUM(ad1dmon) as ad1dmon,SUM(ad2.ad1cmon) as ad1cmon from intranet.dbo.ad1'+@ac3yy+' as ad1,intranet.dbo.ad2'+@ac3yy+' as ad2 where ad1.ad1no=ad2.ad1no and  ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+@pl1no+''' and YEAR(ad1.ad1date)='+@ac3yy+' and ad2.ad1yy='+@ac3yy+' and MONTH(ad1.ad1date) between '+@bmm+' and '+@emm+' and not(ad2.ac2no in ('''+@ac2no1+''','''+@ac2no2+''','''+@ac2no3+''')) and ad2.ad1no in (select * from #tmp) group by ad2.ac2no,ad2.ac2no2,ad2.ac2name,ad2.ad1dc order by ad2.ac2no,ad2.ac2no2'
		end
		else
		begin
			set @run='select DISTINCT ad2.ad1no from intranet.dbo.ad1,intranet.dbo.ad2 where ad1.ad1no=ad2.ad1no and ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+@pl1no+''' and YEAR(ad1.ad1date)='+@ac3yy+' and ad2.ad1yy='+@ac3yy+' and MONTH(ad1.ad1date) between '+@bmm+' and '+@emm+' and ad2.ac2no in ('''+@ac2no1+''','''+@ac2no2+''','''+@ac2no3+''')'
			insert into #tmp (ad1no) exec (@run)
			set @run='select ad2.ac2no,ad2.ac2no2,ad2.ac2name,ad2.ad1dc,SUM(ad1dmon) as ad1dmon,SUM(ad2.ad1cmon) as ad1cmon from intranet.dbo.ad1,intranet.dbo.ad2 where ad1.ad1no=ad2.ad1no and ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+@pl1no+''' and YEAR(ad1.ad1date)='+@ac3yy+' and ad2.ad1yy='+@ac3yy+' and MONTH(ad1.ad1date) between '+@bmm+' and '+@emm+' and not(ad2.ac2no in ('''+@ac2no1+''','''+@ac2no2+''','''+@ac2no3+''')) and ad2.ad1no in (select * from #tmp) group by ad2.ac2no,ad2.ac2no2,ad2.ac2name,ad2.ad1dc order by ad2.ac2no,ad2.ac2no2'
		end
		exec (@run)
--		select @run as cc
--		return
	end
	if @dp1lun='C'
	begin
		if @ac3yy<=@ac1cyy
		begin
			set @run='select DISTINCT ad2.ad1no from intranet2.dbo.ad1o'+@ac3yy+' as ad1,intranet2.dbo.ad2o'+@ac3yy+' as ad2 where ad1.ad1no=ad2.ad1no and ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+@pl1no+''' and YEAR(ad1.ad1date)='+@ac3yy+' and ad2.ad1yy='+@ac3yy+' and MONTH(ad1.ad1date) between '+@bmm+' and '+@emm+' and ad2.ac2no in ('''+@ac2no1+''','''+@ac2no2+''','''+@ac2no3+''')'
			insert into #tmp (ad1no) exec (@run)
			set @run='select ad2.ac2no,ad2.ac2no2,ad2.ac2name,ad2.ad1dc,SUM(ad1dmon) as ad1dmon,SUM(ad2.ad1cmon) as ad1cmon from intranet2.dbo.ad1o'+@ac3yy+' as ad1,intranet2.dbo.ad2o'+@ac3yy+' as ad2 where ad1.ad1no=ad2.ad1no and  ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+@pl1no+''' and YEAR(ad1.ad1date)='+@ac3yy+' and ad2.ad1yy='+@ac3yy+' and MONTH(ad1.ad1date) between '+@bmm+' and '+@emm+' and not(ad2.ac2no in ('''+@ac2no1+''','''+@ac2no2+''','''+@ac2no3+''')) and ad2.ad1no in (select * from #tmp) group by ad2.ac2no,ad2.ac2no2,ad2.ac2name,ad2.ad1dc order by ad2.ac2no,ad2.ac2no2'
		end
		else
		begin
			set @run='select DISTINCT ad2.ad1no from intranet2.dbo.ad1c as ad1,intranet2.dbo.ad2c as ad2 where ad1.ad1no=ad2.ad1no and ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+@pl1no+''' and YEAR(ad1.ad1date)='+@ac3yy+' and ad2.ad1yy='+@ac3yy+' and MONTH(ad1.ad1date) between '+@bmm+' and '+@emm+' and ad2.ac2no in ('''+@ac2no1+''','''+@ac2no2+''','''+@ac2no3+''')'
			insert into #tmp (ad1no) exec (@run)
			set @run='select ad2.ac2no,ad2.ac2no2,ad2.ac2name,ad2.ad1dc,SUM(ad1dmon) as ad1dmon,SUM(ad2.ad1cmon) as ad1cmon from intranet2.dbo.ad1c as ad1,intranet2.dbo.ad2c as ad2 where ad1.ad1no=ad2.ad1no and  ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+@pl1no+''' and YEAR(ad1.ad1date)='+@ac3yy+' and ad2.ad1yy='''+@ac3yy+''' and MONTH(ad1.ad1date) between '+@bmm+' and '+@emm+' and not (ad2.ac2no in ('''+@ac2no1+''','''+@ac2no2+''','''+@ac2no3+''')) and ad2.ad1no in (select * from #tmp) group by ad2.ac2no,ad2.ac2no2,ad2.ac2name,ad2.ad1dc order by ad2.ac2no,ad2.ac2no2'
		end
		exec (@run)
		--select @run as cc
	end
	if @dp1lun='P'
	begin
		if @ac3yy<=@ac1pyy
		begin
			set @run='select DISTINCT ad2.ad1no from intranet2.dbo.ad1o'+@ac3yy+' as ad1,intranet2.dbo.ad2o'+@ac3yy+' as ad2 where ad1.ad1no=ad2.ad1no and ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+@pl1no+''' and YEAR(ad1.ad1date)='+@ac3yy+' and ad2.ad1yy='+@ac3yy+' and MONTH(ad1.ad1date) between '+@bmm+' and '+@emm+' and ad2.ac2no in ('''+@ac2no1+''','''+@ac2no2+''','''+@ac2no3+''')'
			insert into #tmp (ad1no) exec (@run)
			set @run='select ad2.ac2no,ad2.ac2no2,ad2.ac2name,ad2.ad1dc,SUM(ad1dmon) as ad1dmon,SUM(ad2.ad1cmon) as ad1cmon from intranet2.dbo.ad1o'+@ac3yy+' as ad1,intranet2.dbo.ad2o'+@ac3yy+' as ad2 where ad1.ad1no=ad2.ad1no and  ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+@pl1no+''' and YEAR(ad1.ad1date)='+@ac3yy+' and ad2.ad1yy='+@ac3yy+' and MONTH(ad1.ad1date) between '+@bmm+' and '+@emm+' and not(ad2.ac2no in ('''+@ac2no1+''','''+@ac2no2+''','''+@ac2no3+''')) and ad2.ad1no in (select * from #tmp) group by ad2.ac2no,ad2.ac2no2,ad2.ac2name,ad2.ad1dc order by ad2.ac2no,ad2.ac2no2'
		end
		else
		begin
			set @run='select DISTINCT ad2.ad1no from intranet2.dbo.ad1o as ad1,intranet2.dbo.ad2o as ad2 where ad1.ad1no=ad2.ad1no and ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+@pl1no+''' and YEAR(ad1.ad1date)='+@ac3yy+' and ad2.ad1yy='+@ac3yy+' and MONTH(ad1.ad1date) between '+@bmm+' and '+@emm+' and ad2.ac2no in ('''+@ac2no1+''','''+@ac2no2+''','''+@ac2no3+''')'
			insert into #tmp (ad1no) exec (@run)
			set @run='select ad2.ac2no,ad2.ac2no2,ad2.ac2name,ad2.ad1dc,SUM(ad1dmon) as ad1dmon,SUM(ad2.ad1cmon) as ad1cmon from intranet2.dbo.ad1o as ad1,intranet2.dbo.ad2o as ad2 where ad1.ad1no=ad2.ad1no and  ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+@pl1no+''' and YEAR(ad1.ad1date)='+@ac3yy+' and ad2.ad1yy='+@ac3yy+' and MONTH(ad1.ad1date) between '+@bmm+' and '+@emm+' and not(ad2.ac2no in ('''+@ac2no1+''','''+@ac2no2+''','''+@ac2no3+''')) and ad2.ad1no in (select * from #tmp) group by ad2.ac2no,ad2.ac2no2,ad2.ac2name,ad2.ad1dc order by ad2.ac2no,ad2.ac2no2'
		end
		exec (@run)
	end
	drop table #tmp
	
END
go

