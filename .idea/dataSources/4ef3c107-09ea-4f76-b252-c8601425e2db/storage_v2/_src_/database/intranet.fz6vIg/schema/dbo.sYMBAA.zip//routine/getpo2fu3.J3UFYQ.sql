-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[getpo2fu3] (@pe1no char(5),@po2no char(3),@po2no2 char(3),@fu1sys char(1),@dp1lun char(1))
AS
BEGIN
	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp
	end
	if (select object_id('tempdb..#tmp2'))is not null
	begin
		drop table #tmp2
	end
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	select fu3.fu1no,fu3.fu1group,fu3.fu1name,fu3.fu1name_c,fu3.fu1name_e,fu3.fu1name_a,fu3.fu1type into #tmp from po2fu3,fu3 where po2fu3.fu1no=fu3.fu1no2 and po2fu3.fu1lun_t='Z' and fu3.fu1sys=@fu1sys and fu3.fu1type='Z' order by fu3.fu1group
	if @dp1lun='T'
	begin
		select fu3.fu1no,fu3.fu1group,fu3.fu1name,fu3.fu1name_c,fu3.fu1name_e,fu3.fu1name_a,fu3.fu1type into #tmp11 from po2fu3,fu3 where po2fu3.fu1no=fu3.fu1no2 and (po2fu3.po2no=@po2no or po2fu3.po2no=@po2no2) and fu3.fu1sys=@fu1sys  and po2fu3.fu1lun_t='Y' and fu3.fu1type='M' order by fu3.fu1group
		insert into tempdb.#tmp (fu1no,fu1group,fu1name,fu1name_c,fu1name_e,fu1name_a,fu1type) select fu1no,fu1group,fu1name,fu1name_c,fu1name_e,fu1name_a,fu1type from tempdb.#tmp11
		drop table #tmp11
	end
	if @dp1lun='C'
	begin
		select fu3.fu1no,fu3.fu1group,fu3.fu1name,fu3.fu1name_c,fu3.fu1name_e,fu3.fu1name_a,fu3.fu1type into #tmp12 from po2fu3,fu3 where po2fu3.fu1no=fu3.fu1no2 and (po2fu3.po2no=@po2no or po2fu3.po2no=@po2no2) and fu3.fu1sys=@fu1sys and po2fu3.fu1lun_c='Y' and fu3.fu1type='M' order by fu3.fu1group
		insert into tempdb.#tmp (fu1no,fu1group,fu1name,fu1name_c,fu1name_e,fu1name_a,fu1type) select fu1no,fu1group,fu1name,fu1name_c,fu1name_e,fu1name_a,fu1type from tempdb.#tmp12
		drop table #tmp12
	end
	if @dp1lun='P'
	begin
		select fu3.fu1no,fu3.fu1group,fu3.fu1name,fu3.fu1name_c,fu3.fu1name_e,fu3.fu1name_a,fu3.fu1type into #tmp13 from po2fu3,fu3 where po2fu3.fu1no=fu3.fu1no2 and (po2fu3.po2no=@po2no or po2fu3.po2no=@po2no2) and fu3.fu1sys=@fu1sys and po2fu3.fu1lun_p='Y' and fu3.fu1type='M' order by fu3.fu1group
		insert into tempdb.#tmp (fu1no,fu1group,fu1name,fu1name_c,fu1name_e,fu1name_a,fu1type) select fu1no,fu1group,fu1name,fu1name_c,fu1name_e,fu1name_a,fu1type from tempdb.#tmp13
		drop table #tmp13
	end
	if @dp1lun='S'
	begin
		select fu3.fu1no,fu3.fu1group,fu3.fu1name,fu3.fu1name_c,fu3.fu1name_e,fu3.fu1name_a,fu3.fu1type into #tmp133 from po2fu3,fu3 where po2fu3.fu1no=fu3.fu1no2 and (po2fu3.po2no=@po2no or po2fu3.po2no=@po2no2) and fu3.fu1sys=@fu1sys and po2fu3.fu1lun_s='Y' and fu3.fu1type='M' order by fu3.fu1group
		insert into tempdb.#tmp (fu1no,fu1group,fu1name,fu1name_c,fu1name_e,fu1name_a,fu1type) select fu1no,fu1group,fu1name,fu1name_c,fu1name_e,fu1name_a,fu1type from tempdb.#tmp133
		drop table #tmp133
	end
	select fu3.fu1no,fu3.fu1group,fu3.fu1name,fu3.fu1name_c,fu3.fu1name_e,fu3.fu1name_a,fu3.fu1type into #tmp2 from rg5,fu3 where rg5.fu1no=fu3.fu1no2 and rg5.pe1no=@pe1no and fu3.fu1sys=@fu1sys and fu3.fu1type='M' order by fu3.fu1group
	insert into tempdb.#tmp (fu1no,fu1group,fu1name,fu1name_c,fu1name_e,fu1name_a,fu1type) select fu1no,fu1group,fu1name,fu1name_c,fu1name_e,fu1name_a,fu1type from tempdb.#tmp2
	select DISTINCT * from tempdb.#tmp as t order by t.fu1no
	drop table #tmp2
	drop table #tmp
	
END
go

