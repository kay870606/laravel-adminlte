CREATE VIEW dbo.oa1rpt
AS
SELECT          dbo.bb1.bb1name, dbo.bb1.bb1eng, dbo.oa2.*
FROM              dbo.bb1 RIGHT OUTER JOIN
                            dbo.oa2 ON dbo.bb1.bb1no = dbo.oa2.bb1no
go

