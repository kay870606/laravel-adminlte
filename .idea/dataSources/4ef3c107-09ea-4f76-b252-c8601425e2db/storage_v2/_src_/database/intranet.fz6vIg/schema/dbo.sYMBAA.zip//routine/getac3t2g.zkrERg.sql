-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[getac3t2g] (@nowno char(9),@pl1no char(4),@ac3yy char(4),@bmm char(2),@emm char(2),@dp1lun char(1))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	declare @ac1tyy char(4),@ac1cyy char(4),@ac1pyy char(4)
	declare @run varchar(450),@accok char(1)
	
	select @accok=accok from intranet.dbo.depcode where dp1no=@pl1no
	select @ac1tyy=ac1tyy,@ac1cyy=ac1cyy,@ac1pyy=ac1pyy from intranet.dbo.ac1yy
	if @dp1lun='T'
	begin
		if @ac3yy<=@ac1tyy
			set @run='select ad2.ac2no,ad2.ac2name,ad2.ad1dc,SUM(ad1dmon) as ad1dmon,SUM(ad2.ad1cmon) as ad1cmon from ad1'+@ac3yy+' as ad1,ad2'+@ac3yy+' as ad2 where ad1.ad1no=ad2.ad1no and ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+@pl1no+''' and YEAR(ad1.ad1date)='+@ac3yy+' and ad2.ad1yy='''+@ac3yy+''' group by ad2.ac2no,ad2.ac2name,ad2.ad1dc order by ad2.ac2no'
		else
			set @run='select ad2.ac2no,ad2.ac2name,ad2.ad1dc,SUM(ad1dmon) as ad1dmon,SUM(ad2.ad1cmon) as ad1cmon from ad1,ad2 where ad1.ad1no=ad2.ad1no and ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+@pl1no+''' and YEAR(ad1.ad1date)='+@ac3yy+' and ad2.ad1yy='''+@ac3yy+''' group by ad2.ac2no,ad2.ac2name,ad2.ad1dc order by ad2.ac2no'
	
		exec (@run)
	end
	if @dp1lun='C'
	begin
		if @ac3yy<=@ac1cyy
			set @run='select ad2.ac2no,ad2.ac2name,ad2.ad1dc,SUM(ad1dmon) as ad1dmon,SUM(ad2.ad1cmon) as ad1cmon from intranet2.dbo.ad1o'+@ac3yy+' as ad1,intranet2.dbo.ad2o'+@ac3yy+' as ad2 where ad1.ad1no=ad2.ad1no and ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+@pl1no+''' and YEAR(ad1.ad1date)='+@ac3yy+' and ad2.ad1yy='''+@ac3yy+''' group by ad2.ac2no,ad2.ac2name,ad2.ad1dc order by ad2.ac2no'
		else
		begin
			if @accok='Y'
				set @run='select ad2.ac2no,ad2.ac2name,ad2.ad1dc,SUM(ad1dmon) as ad1dmon,SUM(ad2.ad1cmon) as ad1cmon from intranet2.dbo.ad1c as ad1,intranet2.dbo.ad2c as ad2 where ad1.ad1no=ad2.ad1no and ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+@pl1no+''' and YEAR(ad1.ad1date)='+@ac3yy+' and ad2.ad1yy='+@ac3yy+' group by ad2.ac2no,ad2.ac2name,ad2.ad1dc order by ad2.ac2no'
			else
				set @run='select ad2.ac2no,ad2.ac2name,ad2.ad1dc,SUM(ad1dmon) as ad1dmon,SUM(ad2.ad1cmon) as ad1cmon from intranet2.dbo.ad1o as ad1,intranet2.dbo.ad2o as ad2 where ad1.ad1no=ad2.ad1no and ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+@pl1no+''' and YEAR(ad1.ad1date)='+@ac3yy+' and ad2.ad1yy='+@ac3yy+' group by ad2.ac2no,ad2.ac2name,ad2.ad1dc order by ad2.ac2no'
		end
		exec (@run)
	end
	if @dp1lun='P'
	begin
	if @ac3yy<=@ac1pyy
			set @run='select ad2.ac2no,ad2.ac2name,ad2.ad1dc,SUM(ad1dmon) as ad1dmon,SUM(ad2.ad1cmon) as ad1cmon from intranet2.dbo.ad1o'+@ac3yy+' as ad1,intranet2.dbo.ad2o'+@ac3yy+' as ad2 where ad1.ad1no=ad2.ad1no and ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+@pl1no+''' and YEAR(ad1.ad1date)='+@ac3yy+' and ad2.ad1yy='''+@ac3yy+''' group by ad2.ac2no,ad2.ac2name,ad2.ad1dc order by ad2.ac2no'
		else
			set @run='select ad2.ac2no,ad2.ac2name,ad2.ad1dc,SUM(ad1dmon) as ad1dmon,SUM(ad2.ad1cmon) as ad1cmon from intranet2.dbo.ad1o as ad1,intranet2.dbo.ad2o as ad2 where ad1.ad1no=ad2.ad1no and ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+@pl1no+''' and YEAR(ad1.ad1date)='+@ac3yy+' and ad2.ad1yy='''+@ac3yy+''' group by ad2.ac2no,ad2.ac2name,ad2.ad1dc order by ad2.ac2no'
	
		exec (@run)
	end

END
go

