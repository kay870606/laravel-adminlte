-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[in1_A0204_6] (@nowno char(9),@dp1lun char(1),@dp1yn2 char(1),@byy char(4),@byy2 char(4),@bmm char(2),@mon21 char(1))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	declare @yy char(4),@yy2 char(4)

	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
delete from intra3.dbo.in1_A0126 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
insert into intra3.dbo.in1_A0126 (nowno,pl1no,pl1name,lu1no) select @nowno,dp1no,dp1name,dp1lun2 from intranet.dbo.depcode where dp1lun=@dp1lun and dp1over<>'Y' and dp1yn='Y' and dp1yn2<>'Y'
update intra3.dbo.in1_a0126 set lu1name=(select lu1name from lu1 where lu1no=intra3.dbo.in1_a0126.lu1no)where nowno=@nowno
update intra3.dbo.in1_a0126 set lu1dno=(select lu1dno from lu1 where lu1no=intra3.dbo.in1_a0126.lu1no)where nowno=@nowno
update intra3.dbo.in1_a0126 set lu1sort=(select lu1sort from lu1 where lu1no=intra3.dbo.in1_a0126.lu1no)where nowno=@nowno
create table #tmp (dp1no char(4),yy2 char(4),mon decimal(10, 0))
insert into #tmp (dp1no,yy2,mon) select pl1no, year(bk1date) as yy2, sum(bk1cah+bk1oth2+bk1oth+bk1mon3+bk1mon2) as mon from intranet2.dbo.in2 where (year(bk1date)=@byy or year(bk1date)=@byy2) and month(bk1date)=@bmm and pl1no in (select dp1no from intranet.dbo.depcode where dp1lun=@dp1lun) group by pl1no,year(bk1date)  order by pl1no,yy2
--select * from #tmp order by pl1no,yy2
update intra3.dbo.in1_a0126 set in1mon=(select mon from #tmp where yy2=@byy and dp1no=pl1no)
update intra3.dbo.in1_a0126 set in1pmon=(select mon from #tmp where yy2=@byy2 and dp1no=pl1no)
select * from intra3.dbo.in1_a0126 order by lu1no,pl1no
drop table #tmp
END
go

