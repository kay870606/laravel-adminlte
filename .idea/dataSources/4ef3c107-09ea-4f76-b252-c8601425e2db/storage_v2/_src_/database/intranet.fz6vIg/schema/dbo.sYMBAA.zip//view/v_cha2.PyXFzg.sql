CREATE VIEW dbo.v_cha2
AS
SELECT          dbo.cha2.cha2num, dbo.cha2.pe1no, dbo.cha2.pe1no2, dbo.cha2.cha2date, dbo.cha2.cha2mess, dbo.cha2.cha2type, 
                            dbo.cha2.cha2sfile, dbo.cha2.cha2rfile, dbo.usr.usrname, dbo.usr.dep, dbo.usr.post, dbo.usr.po2no, 
                            usr_1.usrname AS pe1name, usr_1.dep AS dp1no
FROM              dbo.cha2 INNER JOIN
                            dbo.usr ON dbo.cha2.pe1no = dbo.usr.usrno INNER JOIN
                            dbo.usr AS usr_1 ON dbo.cha2.pe1no2 = usr_1.usrno
go

