-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[ap1_C7019] (@ap1ym2 char(6),@su1no char(4))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
create table #tmp (mon decimal(8, 0))
insert into #tmp (mon) select sum(su1mon1) from ap1s where ap1ym2=@ap1ym2 and su1no1=@su1no group by su1no1
insert into #tmp (mon) select sum(su1mon2) from ap1s where ap1ym2=@ap1ym2 and su1no2=@su1no group by su1no2
insert into #tmp (mon) select sum(su1mon3) from ap1s where ap1ym2=@ap1ym2 and su1no3=@su1no group by su1no3
insert into #tmp (mon) values (0)
select sum(mon) as mon from #tmp
drop table #tmp
END
go

