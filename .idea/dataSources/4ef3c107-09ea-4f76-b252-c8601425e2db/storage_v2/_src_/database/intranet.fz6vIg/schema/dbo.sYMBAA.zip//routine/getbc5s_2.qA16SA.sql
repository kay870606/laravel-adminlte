-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[getbc5s_2] (@pl1no char(4),@nowno char(9))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end

	create table #tmp (dp1no char(4),bc5type2 char(1),bc5id2 char(11))
	insert into #tmp (dp1no,bc5type2,bc5id2) select pl1no,bc5type,bc5id from bc7 where pl1no=@pl1no
	update intra3.dbo.bc5s set bc5type=#tmp.bc5type2 from #tmp join intra3.dbo.bc5s bc5s ON bc5id2 = bc5id and dp1no=pl1no and nowno=@nowno
	--update intra3.dbo.bc5s set bc5qty5='1' from #tmp join intra3.dbo.bc5s bc5s ON bc5id2 = bc5id and dp1no=pl1no and bc5type2='5'
	--update intra3.dbo.bc5s set bc5qty4='1' from #tmp join intra3.dbo.bc5s bc5s ON bc5id2 = bc5id and dp1no=pl1no and bc5type2='4'
	--update intra3.dbo.bc5s set bc5qty2='1' from #tmp join intra3.dbo.bc5s bc5s ON bc5id2 = bc5id and dp1no=pl1no and bc5type2='2'
	drop table #tmp
	
END
go

