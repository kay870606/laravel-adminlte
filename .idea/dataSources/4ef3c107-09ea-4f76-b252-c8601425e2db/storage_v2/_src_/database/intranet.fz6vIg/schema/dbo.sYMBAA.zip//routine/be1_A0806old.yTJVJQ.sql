-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[be1_A0806old] (@nowno char(9),@pl1no char(4),@yymm char(4),@fe1no char(2),@byy char(4),@in1p decimal(4,2))

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
	if (select object_id('tempdb..#tmp2'))is not null
	begin
		drop table #tmp2;
	end
	if (select object_id('tempdb..#tmp3'))is not null
	begin
		drop table #tmp3;
	end
  delete from intra3.dbo.be1_A0306 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
if (@fe1no = '')   
begin   
   insert into intra3. dbo.be1_A0306 (nowno, pl1no,bb1no,bb1no2, be1price, bh1num,bh1mon ,bd1rel, bi1range) select @nowno,@pl1no ,bb1no, LEFT(bb1no,1), be1price,sum (be1qty), sum(be1price *be1qty) as mon,bh1mac,bi1range from intranet2.dbo .be1 where pl1no=@pl1no and bh1ym=@yymm and be1bad<>'Y' group by pl1no,bb1no ,be1price, bh1mac,bi1range order by bb1no        
       if((select sy1pyn3 from sy11 where pl1no=@pl1no) ='Y')
        begin
            CREATE TABLE #tmp (bb1no char(6),bb1no2 char(1),be1price decimal(7, 2),bh1num decimal(8, 0),bh1mon decimal(8, 0) ,bd1rel decimal(4, 0),bi1range char(4))
            insert into #tmp (bb1no,bb1no2,be1price,bh1num ,bh1mon,bd1rel) select bb1no,LEFT(bb1no,1),be1price, sum(bh1num),sum(bh1mon),sum(bd1rel) from intra3.dbo.be1_A0306 where nowno=@nowno group by bb1no,be1price 
            update #tmp set bi1range = (select top 1(case SUBSTRING(@yymm,3,2) when 01 then bd1m1 when 02 then bd1m2 when 03 then bd1m3 when 04 then bd1m4 when 05 then bd1m5 when 06 then bd1m6 when 07 then bd1m7 when 08 then bd1m8 when 09 then bd1m9 when 10 then bd1m10 when 11 then bd1m11 when 12 then bd1m12 end) from intranet2.dbo.bd1 where pl1no=@pl1no and bb1yyyy=@byy and bb1no=#tmp.bb1no)
	        delete from intra3. dbo.be1_A0306 where nowno=@nowno			
            insert into intra3. dbo.be1_A0306 (nowno,pl1no,bb1no,bb1no2, be1price,bh1num,bh1mon,bd1rel,bi1range) select @nowno,@pl1no ,bb1no, bb1no2, be1price,bh1num,bh1mon,bd1rel,bi1range from #tmp order by bb1no
			drop table #tmp;
        end
   end
  else
  if (@fe1no <> '')   
   begin
   insert into intra3. dbo.be1_A0306 (nowno, pl1no,bb1no,bb1no2,be1price, bh1num,bh1mon ,bd1rel, bi1range) select @nowno,@pl1no ,bb1no, LEFT(bb1no,1), be1price,sum (be1qty), sum(be1price *be1qty) as mon,bh1mac ,bi1range from intranet2 .dbo. be1 where pl1no= @pl1no and bh1ym= @yymm and fe1no= @fe1no and be1bad<>'Y' group by pl1no ,bb1no, be1price,bh1mac ,bi1range order by bb1no
   end
update intra3 .dbo. be1_A0306 set bd1qty=( select top 1 bd1qty from intranet2.dbo.bd1 where bb1no =intra3. dbo.be1_A0306 .bb1no and bb1yyyy=@byy and pl1no=@pl1no) where nowno=@nowno  
update intra3 .dbo. be1_A0306 set bb1name=( select bb1name from intranet.dbo .bb1 where bb1no =intra3. dbo.be1_A0306 .bb1no)  where nowno=@nowno
update intra3 .dbo. be1_A0306 set bd1rel=1 where bd1rel=0 and nowno=@nowno
update intra3 .dbo. be1_A0306 set bh1cal=(be1price * bh1num/ bd1rel)/((cast (right(bi1range, 2)as decimal)- cast(left(bi1range ,2) as decimal)+1 )) where bh1cal is null and nowno=@nowno 
update intra3 .dbo. be1_A0306 set bc3price=(select top 1 bc1prc from intranet.dbo.bc3n where bc3flag='A' and pl1no in (select dp1no from depcode where dp1lun=(select dp1lun from depcode where dp1no=@pl1no)) and bb1no=intra3. dbo.be1_A0306 .bb1no and bc1prc>0 order by bc3date2 desc) where nowno=@nowno
if (@fe1no <> '')
  begin
  update intra3 .dbo. be1_A0306 set bb1fcost=(select TOP 1 bb1fcost from intranet2.dbo .bd1 where fe1no=@fe1no and bb1no=intra3. dbo.be1_A0306.bb1no and bb1yyyy=@byy and pl1no=@pl1no )  where nowno=@nowno
   end
else
  begin
   update intra3 .dbo. be1_A0306 set bb1fcost=(select TOP 1 bb1fcost from intranet2.dbo .bd1 where fe1no='A' and bb1no=intra3. dbo.be1_A0306.bb1no and bb1yyyy=@byy and pl1no=@pl1no )  where nowno=@nowno
  -- update intra3.dbo.be1_A0306 set bd1rel=(select bd1rel from intranet2.dbo.bd1 where pl1no=@pl1no and bb1yy=left(@yymm,2) and bb1no=intra3. dbo.be1_A0306.bb1no )
  end

update intra3.dbo.be1_A0306 set pi1=100*bh1mon/(select sum(bh1mon) from intra3.dbo.be1_A0306 where nowno=@nowno) where nowno=@nowno
 CREATE TABLE #tmp2 (bb1no2 char(6),bd1rel decimal(4, 0))
    insert into #tmp2 (bb1no2,bd1rel) select bb1no,bd1rel from intra3.dbo.be1_A0306 where bh1num>0 and nowno=@nowno group by bb1no,bd1rel
	update intra3.dbo.be1_A0306 set bd1rel=(select top 1 bd1rel from #tmp2 where bh1num>0 and bb1no2=intra3.dbo.be1_A0306.bb1no) where nowno=@nowno and bh1num<0 and exists (select bb1no2 from #tmp2 where bb1no2=bb1no)
	drop table #tmp2;  
	CREATE TABLE #tmp3 (bb1no2 char(6),rate decimal(6, 2))
insert into #tmp3 (bb1no2,rate) select bb1no,rate from intranet2.dbo.be1 where pl1no=@pl1no and bh1ym=@yymm and be1bad<>'Y' group by bb1no,rate
update intra3.dbo.be1_A0306 set rate=(select top 1 rate from #tmp3 where bb1no2=intra3.dbo.be1_A0306.bb1no)  where nowno=@nowno
update intra3 .dbo. be1_A0306 set bh1mon=bh1mon*@in1p where nowno=@nowno  
update intra3 .dbo. be1_A0306 set bh1cal=bh1cal*@in1p where nowno=@nowno  
  drop table #tmp3
END
go

