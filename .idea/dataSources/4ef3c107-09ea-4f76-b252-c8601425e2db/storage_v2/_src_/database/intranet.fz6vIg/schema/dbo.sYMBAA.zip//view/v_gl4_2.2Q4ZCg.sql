CREATE VIEW dbo.v_gl4_2
AS
SELECT          dbo.gl4.pl1no, dbo.gl4.gl3month, dbo.gl4.ge1no, dbo.gl4.gl1pi, dbo.gl4.gl4mon, dbo.gl4.gl4mon2, dbo.gl4.gl4mon3, 
                            dbo.depcode.DP1NAME, dbo.depcode.dp1lun3, dbo.ge1.ge1name, dbo.ge1.ge1no1, dbo.ge1.ge1no2, 
                            dbo.gl4.gl3t3040
FROM              dbo.ge1 INNER JOIN
                            dbo.gl4 ON dbo.ge1.ge1no = dbo.gl4.ge1no INNER JOIN
                            dbo.depcode ON dbo.gl4.pl1no = dbo.depcode.DP1NO
go

