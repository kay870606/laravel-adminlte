-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[pe1b0821] (@nowno char(9),@yy char(4),@dp1lun char(1))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
delete from intra3.dbo.pe1_B0821 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
if @dp1lun='A'
begin
	insert into intra3.dbo.pe1_B0821 (nowno,pl1no,pl1name,dp1lun,dp1lun2,lu1name) select DISTINCT @nowno,usr.dep,d.dp1name,d.dp1lun,d.dp1lun2,(select lu1name from lu1 where lu1no=d.dp1lun2) as lu1name from usr,depcode as d where usr.dep=d.dp1no and usr.dep in (select dp1no from depcode where dp1lun<>'P' and dp1over<>'Y') and (year(usr.pf1ari)=@yy or year(usr.pf1lef)=@yy) order by d.dp1lun2,usr.dep
	select usr.usrno,usr.dep as pl1no,usr.pf1ari,usr.pf1lef from usr where usr.dep in (select dp1no from depcode where dp1lun<>'P' and dp1over<>'Y') and (year(usr.pf1ari)=@yy or year(usr.pf1lef)=@yy) order by usr.dep,usr.usrno
end
else
begin
	insert into intra3.dbo.pe1_B0821 (nowno,pl1no,pl1name,dp1lun,dp1lun2,lu1name) select DISTINCT @nowno,usr.dep,d.dp1name,d.dp1lun,d.dp1lun2,(select lu1name from lu1 where lu1no=d.dp1lun2) as lu1name from usr,depcode as d where usr.dep=d.dp1no and usr.dep in (select dp1no from depcode where dp1lun=@dp1lun and dp1over<>'Y') and (year(usr.pf1ari)=@yy or year(usr.pf1lef)=@yy) order by d.dp1lun2,usr.dep
	select usr.usrno,usr.dep as pl1no,usr.pf1ari,usr.pf1lef from usr where usr.dep in (select dp1no from depcode where dp1lun=@dp1lun and dp1over<>'Y') and (year(usr.pf1ari)=@yy or year(usr.pf1lef)=@yy) order by usr.dep,usr.usrno
end

END
go

