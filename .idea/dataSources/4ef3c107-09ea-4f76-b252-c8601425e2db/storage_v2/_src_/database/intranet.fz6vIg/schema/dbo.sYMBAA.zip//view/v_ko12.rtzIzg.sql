CREATE VIEW dbo.v_ko12
AS
SELECT          dbo.ko1.ko1num, dbo.ko1.ko1mon, dbo.ko1.ko1date, dbo.su1.ecomp, dbo.ko1.su1no, dbo.ko1.ko1bad, dbo.ko1.su1tl, 
                            dbo.ko1.su1mon, dbo.ko1.ap1ym, dbo.ko1.ko1no
FROM              dbo.ko1 INNER JOIN
                            dbo.su1 ON dbo.ko1.su1no = dbo.su1.su1no
go

