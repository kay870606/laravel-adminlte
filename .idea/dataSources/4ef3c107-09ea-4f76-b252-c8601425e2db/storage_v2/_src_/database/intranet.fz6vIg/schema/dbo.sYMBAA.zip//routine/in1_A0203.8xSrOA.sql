-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[in1_A0203] (@nowno char(9),@byy char(4),@dp1lun char(1),@fu1no char(5))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end

delete from intra3.dbo.in1_A0121 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
create table #tmp (mm char(2),dp1no char(4),in1sum decimal(12, 2))
if @dp1lun='A'
  begin
	insert into intra3.dbo.in1_A0121 (nowno,in1yy,pl1no,dp1lun) select @nowno,@byy,pl1no,(select dp1lun from depcode where dp1no=pl1no) as dp1lun from intranet2.dbo.in2 where year(bk1date)=@byy and pl1no in (select pl1no from intra3.dbo.dp1ch where nowno=@nowno and fu1no=@fu1no) group by pl1no
	insert into #tmp (mm,dp1no,in1sum) select month(bk1date) as mm,pl1no,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as in1sum from intranet2.dbo.in2 where year(bk1date)=@byy and pl1no in (select pl1no from intra3.dbo.dp1ch where nowno=@nowno and fu1no=@fu1no) group by month(bk1date),pl1no
  end
else
  begin
	insert into intra3.dbo.in1_A0121 (nowno,in1yy,pl1no,dp1lun) select @nowno,@byy,pl1no,@dp1lun from intranet2.dbo.in2 where year(bk1date)=@byy and pl1no in (select dp1no from intranet.dbo.depcode where dp1lun=@dp1lun) and pl1no in (select pl1no from intra3.dbo.dp1ch where nowno=@nowno and fu1no=@fu1no) group by pl1no
	insert into #tmp (mm,dp1no,in1sum) select month(bk1date) as mm,pl1no,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as in1sum from intranet2.dbo.in2 where year(bk1date)=@byy and pl1no in (select pl1no from intra3.dbo.dp1ch where nowno=@nowno and fu1no=@fu1no and dp1lun=@dp1lun) group by month(bk1date),pl1no
  end

update intra3.dbo.in1_A0121 set in1m1=(select in1sum from #tmp where mm='1' and dp1no=pl1no) where nowno=@nowno and in1yy=@byy
update intra3.dbo.in1_A0121 set in1m2=(select in1sum from #tmp where mm='2' and dp1no=pl1no) where nowno=@nowno and in1yy=@byy
update intra3.dbo.in1_A0121 set in1m3=(select in1sum from #tmp where mm='3' and dp1no=pl1no) where nowno=@nowno and in1yy=@byy
update intra3.dbo.in1_A0121 set in1m4=(select in1sum from #tmp where mm='4' and dp1no=pl1no) where nowno=@nowno and in1yy=@byy
update intra3.dbo.in1_A0121 set in1m5=(select in1sum from #tmp where mm='5' and dp1no=pl1no) where nowno=@nowno and in1yy=@byy
update intra3.dbo.in1_A0121 set in1m6=(select in1sum from #tmp where mm='6' and dp1no=pl1no) where nowno=@nowno and in1yy=@byy
update intra3.dbo.in1_A0121 set in1m7=(select in1sum from #tmp where mm='7' and dp1no=pl1no) where nowno=@nowno and in1yy=@byy
update intra3.dbo.in1_A0121 set in1m8=(select in1sum from #tmp where mm='8' and dp1no=pl1no) where nowno=@nowno and in1yy=@byy
update intra3.dbo.in1_A0121 set in1m9=(select in1sum from #tmp where mm='9' and dp1no=pl1no) where nowno=@nowno and in1yy=@byy
update intra3.dbo.in1_A0121 set in1m10=(select in1sum from #tmp where mm='10' and dp1no=pl1no) where nowno=@nowno and in1yy=@byy
update intra3.dbo.in1_A0121 set in1m11=(select in1sum from #tmp where mm='11' and dp1no=pl1no) where nowno=@nowno and in1yy=@byy
update intra3.dbo.in1_A0121 set in1m12=(select in1sum from #tmp where mm='12' and dp1no=pl1no) where nowno=@nowno and in1yy=@byy

update intra3.dbo.in1_A0121 set in1m1=0 where nowno=@nowno and in1yy=@byy and in1m1 is null
update intra3.dbo.in1_A0121 set in1m2=0 where nowno=@nowno and in1yy=@byy and in1m2 is null
update intra3.dbo.in1_A0121 set in1m3=0 where nowno=@nowno and in1yy=@byy and in1m3 is null
update intra3.dbo.in1_A0121 set in1m4=0 where nowno=@nowno and in1yy=@byy and in1m4 is null
update intra3.dbo.in1_A0121 set in1m5=0 where nowno=@nowno and in1yy=@byy and in1m5 is null
update intra3.dbo.in1_A0121 set in1m6=0 where nowno=@nowno and in1yy=@byy and in1m6 is null
update intra3.dbo.in1_A0121 set in1m7=0 where nowno=@nowno and in1yy=@byy and in1m7 is null
update intra3.dbo.in1_A0121 set in1m8=0 where nowno=@nowno and in1yy=@byy and in1m8 is null
update intra3.dbo.in1_A0121 set in1m9=0 where nowno=@nowno and in1yy=@byy and in1m9 is null
update intra3.dbo.in1_A0121 set in1m10=0 where nowno=@nowno and in1yy=@byy and in1m10 is null
update intra3.dbo.in1_A0121 set in1m11=0 where nowno=@nowno and in1yy=@byy and in1m11 is null
update intra3.dbo.in1_A0121 set in1m12=0 where nowno=@nowno and in1yy=@byy and in1m12 is null

drop table #tmp

END
go

