-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[getbc6s] (@nowno char(9),@pl1no varchar(10),@bcode varchar(11),@ecode varchar(11),@bc5type char(1))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	delete from intra3.dbo.bc6s where nowno=@nowno or bc6idate2<CONVERT(nvarchar(30), GETDATE(), 111)
	if @bcode=''
	begin
	   insert into intra3.dbo.bc6s (nowno,pl1no,bc5type,bc5id,bc6date,bc5sname,bc5model,bc6memo,bc6idate,pl1no2,bc6bdate,bc6bmemo,bc5name) select @nowno,pl1no,bc5type,bc5id,bc6date,bc5sname,bc5model,bc6memo,bc6idate,pl1no2,bc6bdate,bc6bmemo,(select bc5name from bc5 where bc5id=bc6.bc5id and bc5.pl1no=@pl1no) as bc5name from intranet.dbo.bc6 as bc6 where pl1no=@pl1no and bc5type=@bc5type
	end
	else
	begin
	   insert into intra3.dbo.bc6s (nowno,pl1no,bc5type,bc5id,bc6date,bc5sname,bc5model,bc6memo,bc6idate,pl1no2,bc6bdate,bc6bmemo,bc5name) select @nowno,pl1no,bc5type,bc5id,bc6date,bc5sname,bc5model,bc6memo,bc6idate,pl1no2,bc6bdate,bc6bmemo,(select bc5name from bc5 where bc5id=bc6.bc5id and bc5.pl1no=@pl1no) as bc5name from intranet.dbo.bc6 as bc6 where pl1no=@pl1no and bc4no between @bcode and @ecode and bc5type=@bc5type
	end
END
go

