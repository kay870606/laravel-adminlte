-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[pt1_D0407] (@nowno char(9),@byymm char(4),@giftno1 char(3),@giftno2 char(3))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	delete from intra3.dbo.pt1_D0407 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)

	insert into intra3.dbo.pt1_D0407(nowno,pt2no,pt2name,mqty,msum,cost) select @nowno,SUBSTRING(giftno,3,3)as pt2no,(select pt2name from pt2 where pt2no=SUBSTRING(giftno,3,3))as pt2name,sum(lottery+spend)as mqty,sum((lottery+spend)*cost)as msum,ROUND(ISNULL(sum((lottery+spend)*cost) / (NULLIF(sum(lottery+spend),0)),0),1)as cost from intranet2.dbo.stock where date=@byymm and right(left(giftno,5),3) between @giftno1 and @giftno2 group by SUBSTRING(giftno,3,3) order by SUBSTRING(giftno,3,3)
END
go

