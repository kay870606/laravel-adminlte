-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[bc1_A4114] (@nowno char(9),@yymm1 char(6),@yymm2 char(6),@rad1 char(1))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
delete from intra3.dbo.bc1_A4114 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)

if @rad1='A'
	begin
		insert into intra3.dbo.bc1_A4114 (nowno,pl1no,bc3date2,bc1name,bb1id,bb1no,bb1name,bb1eng,bc1ser,bc1prc,prcmon,bc3memo) select @nowno,pl1no,CONVERT(nvarchar(10), bc3date2, 111)as bc3date2,bc1name,bb1id,bb1no,(select bb1name from bb1 where bb1.bb1no=bc3n.bb1no)as bb1name,(select bb1eng from bb1 where bb1.bb1no=bc3n.bb1no)as bb1eng,bc1ser,bc1prc,(bc1prc*bc1ser)as mon,bc3memo from bc3n where CONVERT(nvarchar(6), bc3date2, 112) between @yymm1 and @yymm2 and bc3flag='A'
	end
else
	begin
		insert into intra3.dbo.bc1_A4114 (nowno,pl1no,bc3date2,bc1name,bb1id,bb1no,bb1name,bb1eng,bc1ser,bc1prc,prcmon,bc3memo) select @nowno,pl1no,CONVERT(nvarchar(10), bc3date2, 111)as bc3date2,bc1name,bb1id,bb1no,(select bb1name from bb1 where bb1.bb1no=bc3n.bb1no)as bb1name,(select bb1eng from bb1 where bb1.bb1no=bc3n.bb1no)as bb1eng,bc1ser,bc1prc,(bc1prc*bc1ser)as mon,bc3memo from bc3n where pl1no in (select dp1no from depcode where dp1lun=@rad1) and CONVERT(nvarchar(6), bc3date2, 112) between @yymm1 and @yymm2 and bc3flag='A'
	end

END
go

