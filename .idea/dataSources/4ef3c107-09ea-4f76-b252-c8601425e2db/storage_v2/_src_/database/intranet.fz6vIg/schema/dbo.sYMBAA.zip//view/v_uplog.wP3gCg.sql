CREATE VIEW dbo.v_uplog
AS
SELECT          dbo.uplog.pl1no, dbo.uplog.update1, dbo.uplog.upym, dbo.uplog.uptype, dbo.uplog.pe1no, dbo.depcode.DP1NAME, 
                            dbo.depcode.dp1yn, dbo.depcode.dp1over, dbo.depcode.dp1lun2, dbo.uplog.upnum, dbo.depcode.dp1lun
FROM              dbo.depcode INNER JOIN
                            dbo.uplog ON dbo.depcode.DP1NO = dbo.uplog.pl1no
go

