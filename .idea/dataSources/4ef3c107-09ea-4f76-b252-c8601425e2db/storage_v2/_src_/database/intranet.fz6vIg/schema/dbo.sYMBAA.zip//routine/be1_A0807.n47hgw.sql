-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[be1_A0807] (@nowno char(9),@pl1no char(4),@byy char( 2),@bmm char( 2))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
	    if (select object_id( 'tempdb..#tmp2'))is not null
     begin
           drop table #tmp2;
     end
delete from intra3.dbo.be1_A0307 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)

CREATE TABLE #tmp (bh1lst char(4 ),bb1no char(6 ),be1mon decimal(12,2))

--如若跑的年度表為當年，當年當月份清除顯示0
if(@byy = substring((RIGHT('0'+CONVERT(VARCHAR(3), DATEPART(year,getdate())-1911), 3)),2,2))
begin
insert into #tmp (bh1lst, bb1no,be1mon ) select left(bh1lst ,4) as bh1lst,bb1no ,sum(( be1qty*be1price )) as be1mon from intranet2.dbo.be1  where pl1no=@pl1no and left(bh1lst, 2)=@byy and be1bad<>'Y' and SUBSTRING(bh1lst,3, 2) <> RIGHT('0'+CONVERT(VARCHAR(2), DATEPART(month,GETDATE())), 2) group by left( bh1lst,4 ),bb1no
insert into intra3.dbo.be1_A0307 (nowno,pl1no,bb1no2,bb1no) select @nowno,@pl1no,LEFT(bb1no,1), bb1no from intranet2.dbo.be1  where pl1no =@pl1no and left(bh1lst, 2)=@byy and be1bad<>'Y' and SUBSTRING(bh1lst,3, 2) <> RIGHT('0'+CONVERT(VARCHAR(2), DATEPART(month,GETDATE())), 2) group by bb1no
	end
	else
	begin
insert into #tmp (bh1lst, bb1no,be1mon ) select left(bh1lst ,4) as bh1lst,bb1no ,sum(( be1qty*be1price )) as be1mon from intranet2.dbo.be1  where pl1no=@pl1no and left(bh1lst, 2)=@byy and be1bad<>'Y' group by left( bh1lst,4 ),bb1no
insert into intra3.dbo.be1_A0307 (nowno,pl1no,bb1no2,bb1no) select @nowno,@pl1no,LEFT(bb1no,1), bb1no from intranet2.dbo.be1  where pl1no =@pl1no and left(bh1lst, 2)=@byy and be1bad<>'Y' group by bb1no	
	end
--select * from #tmp where right(bh1lst,2)='01' order by bb1no
update intra3.dbo.be1_A0307 set bb1name=(select bb1name from intranet.dbo.bb1 where bb1no=intra3.dbo.be1_A0307.bb1no) where nowno=@nowno
update intra3.dbo.be1_A0307 set bh1m1=be1mon from #tmp join intra3.dbo.be1_A0307 ON  #tmp .bb1no= intra3.dbo.be1_A0307.bb1no where right( #tmp.bh1lst ,2)= '01' and nowno=@nowno
update intra3.dbo.be1_A0307 set bh1m2=be1mon from #tmp join intra3.dbo.be1_A0307 ON  #tmp .bb1no= intra3.dbo.be1_A0307.bb1no where right( #tmp.bh1lst ,2)= '02' and nowno=@nowno
update intra3.dbo.be1_A0307 set bh1m3=be1mon from #tmp join intra3.dbo.be1_A0307 ON  #tmp .bb1no= intra3.dbo.be1_A0307.bb1no where right( #tmp.bh1lst ,2)= '03' and nowno=@nowno
update intra3.dbo.be1_A0307 set bh1m4=be1mon from #tmp join intra3.dbo.be1_A0307 ON  #tmp .bb1no= intra3.dbo.be1_A0307.bb1no where right( #tmp.bh1lst ,2)= '04' and nowno=@nowno
update intra3.dbo.be1_A0307 set bh1m5=be1mon from #tmp join intra3.dbo.be1_A0307 ON  #tmp .bb1no= intra3.dbo.be1_A0307.bb1no where right( #tmp.bh1lst ,2)= '05' and nowno=@nowno
update intra3.dbo.be1_A0307 set bh1m6=be1mon from #tmp join intra3.dbo.be1_A0307 ON  #tmp .bb1no= intra3.dbo.be1_A0307.bb1no where right( #tmp.bh1lst ,2)= '06' and nowno=@nowno
update intra3.dbo.be1_A0307 set bh1m7=be1mon from #tmp join intra3.dbo.be1_A0307 ON  #tmp .bb1no= intra3.dbo.be1_A0307.bb1no where right( #tmp.bh1lst ,2)= '07' and nowno=@nowno
update intra3.dbo.be1_A0307 set bh1m8=be1mon from #tmp join intra3.dbo.be1_A0307 ON  #tmp .bb1no= intra3.dbo.be1_A0307.bb1no where right( #tmp.bh1lst ,2)= '08' and nowno=@nowno
update intra3.dbo.be1_A0307 set bh1m9=be1mon from #tmp join intra3.dbo.be1_A0307 ON  #tmp .bb1no= intra3.dbo.be1_A0307.bb1no where right( #tmp.bh1lst ,2)= '09' and nowno=@nowno
update intra3.dbo.be1_A0307 set bh1m10=be1mon from #tmp join intra3.dbo.be1_A0307 ON  #tmp .bb1no= intra3.dbo.be1_A0307.bb1no where right( #tmp.bh1lst ,2)= '10' and nowno=@nowno
update intra3.dbo.be1_A0307 set bh1m11=be1mon from #tmp join intra3.dbo.be1_A0307 ON  #tmp .bb1no= intra3.dbo.be1_A0307.bb1no where right( #tmp.bh1lst ,2)= '11' and nowno=@nowno
update intra3.dbo.be1_A0307 set bh1m12=be1mon from #tmp join intra3.dbo.be1_A0307 ON  #tmp .bb1no= intra3.dbo.be1_A0307.bb1no where right( #tmp.bh1lst ,2)= '12' and nowno=@nowno
update intra3.dbo.be1_A0307 set bh1m1=0 where bh1m1 is null and nowno=@nowno
update intra3.dbo.be1_A0307 set bh1m2=0 where bh1m2 is null and nowno=@nowno
update intra3.dbo.be1_A0307 set bh1m3=0 where bh1m3 is null and nowno=@nowno
update intra3.dbo.be1_A0307 set bh1m4=0 where bh1m4 is null and nowno=@nowno
update intra3.dbo.be1_A0307 set bh1m5=0 where bh1m5 is null and nowno=@nowno
update intra3.dbo.be1_A0307 set bh1m6=0 where bh1m6 is null and nowno=@nowno
update intra3.dbo.be1_A0307 set bh1m7=0 where bh1m7 is null and nowno=@nowno
update intra3.dbo.be1_A0307 set bh1m8=0 where bh1m8 is null and nowno=@nowno
update intra3.dbo.be1_A0307 set bh1m9=0 where bh1m9 is null and nowno=@nowno
update intra3.dbo.be1_A0307 set bh1m10=0 where bh1m10 is null and nowno=@nowno
update intra3.dbo.be1_A0307 set bh1m11=0 where bh1m11 is null and nowno=@nowno
update intra3.dbo.be1_A0307 set bh1m12=0 where bh1m12 is null and nowno=@nowno
--select * from #tmp2 order by bb1no

create table #tmp2 (bb1no char(6),smon decimal(12, 2),bb1no2 char(6),smon2 decimal(12, 2))
insert into #tmp2 (bb1no,smon) select bb1no,(bh1m1+bh1m2+bh1m3+bh1m4+bh1m5+bh1m6+bh1m7+bh1m8+bh1m9+bh1m10+bh1m11+bh1m12) as smon from intra3.dbo.be1_A0307 where nowno=@nowno
update intra3.dbo.be1_A0307 set bh1smon=(select smon from #tmp2 where bb1no=intra3.dbo.be1_A0307.bb1no) where nowno=@nowno
insert into #tmp2 (bb1no2,smon2) select bb1no2,sum(bh1smon) from intra3.dbo.be1_A0307 group by bb1no2
update intra3.dbo.be1_A0307 set bh1smon2=(select smon2 from #tmp2 where bb1no2=intra3.dbo.be1_A0307.bb1no2) where nowno=@nowno
drop table #tmp
drop table #tmp2
END



go

