-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[getac3t316] (@nowno char(9),@pl1no varchar(4),@ac3yy char(4),@bmm char(2),@emm char(2),@bcode varchar(10),@ecode varchar(10),@dp1lun char(1))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
	delete from intra3.dbo.ac3t316 where ad1idate<CONVERT(nvarchar(30), GETDATE(), 111)
create table #tmp (ad1no char(8),ad1date datetime,ac2no char(4),ac2no2 char(6),ac2name nvarchar(50),ad1dc char(1),ad1dmon decimal(12, 2),ad1cmon decimal(12, 2),ad1memo nvarchar(200))
	insert into #tmp exec getad1g2 @nowno,@pl1no,@ac3yy,@bmm,@emm,@bcode,@ecode,@dp1lun
	insert into intra3.dbo.ac3t316 (nowno,pl1no,ac3yy,ac2sort,ad1no,ad1date,ac2no,ac2no2,ac2name,ad1dc,ad1dmon,ad1cmon,ad1memo) select @nowno,@pl1no,@ac3yy,'1',ad1no,ad1date,ac2no,ac2no2,ac2name,ad1dc,ad1dmon,ad1cmon,ad1memo from #tmp
	select * from intra3.dbo.ac3t316 where pl1no=@pl1no and ac3yy=@ac3yy
drop table #tmp
END
go

