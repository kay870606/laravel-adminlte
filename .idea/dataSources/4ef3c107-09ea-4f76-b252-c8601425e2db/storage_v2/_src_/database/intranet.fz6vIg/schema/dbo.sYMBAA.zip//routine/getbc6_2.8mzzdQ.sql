-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[getbc6_2] (@nowno char(9),@pl1no char(4),@bcode char(11),@ecode char(11),@bdate datetime,@edate datetime,@bc5type char(1))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
	if (select object_id('tempdb..#tmp2'))is not null
	begin
		drop table #tmp2;
	end
	if (select object_id('tempdb..#tmp3'))is not null
	begin
		drop table #tmp3;
	end
	if (select object_id('tempdb..#tmp4'))is not null
	begin
		drop table #tmp4;
	end
	delete from intra3.dbo.bc6s where nowno=@nowno or bc6idate2<CONVERT(nvarchar(30), GETDATE(), 111)
	if @bdate is null
	begin
		if @bcode=''
		begin
			select bc6.*,(select bc4name from bc4 where bc4no=bc6.bc4no) as bc4name into #tmp from bc6 where pl1no=@pl1no and bc5type=@bc5type order by bc6.bc5id
			insert into intra3.dbo.bc6s (nowno,pl1no,bc5type,bc5id,bc5name,bc6date,bc5sname,bc5model,bc6memo,pl1no2,bc4no,bc4name,bc6price) select @nowno,pl1no,bc5type,bc5id,bc5name,bc6date,bc5sname,bc5model,bc6memo,pl1no2,bc4no,bc4name,bc6price from #tmp 
			drop table #tmp
		end
		else
		begin
			select bc6.*,(select bc4name from bc4 where bc4no=bc6.bc4no) as bc4name into #tmp2 from bc6 where pl1no=@pl1no and bc4no between @bcode and @ecode and bc5type=@bc5type order by bc5id
			insert into intra3.dbo.bc6s (nowno,pl1no,bc5type,bc5id,bc5name,bc6date,bc5sname,bc5model,bc6memo,pl1no2,bc4no,bc4name,bc6price) select @nowno,pl1no,bc5type,bc5id,bc5name,bc6date,bc5sname,bc5model,bc6memo,pl1no2,bc4no,bc4name,bc6price from #tmp2
			drop table #tmp2
		end
	end
	else
	begin
		if @bcode=''
		begin
			select bc6.*,(select bc4name from bc4 where bc4no=bc6.bc4no) as bc4name into #tmp3 from bc6 where pl1no=@pl1no and bc6date between @bdate and @edate and bc5type=@bc5type order by bc5id
			insert into intra3.dbo.bc6s (nowno,pl1no,bc5type,bc5id,bc5name,bc6date,bc5sname,bc5model,bc6memo,pl1no2,bc4no,bc4name,bc6price) select @nowno,pl1no,bc5type,bc5id,bc5name,bc6date,bc5sname,bc5model,bc6memo,pl1no2,bc4no,bc4name,bc6price from #tmp3
			drop table #tmp3
		end
		else
		begin
			select bc6.*,(select bc4name from bc4 where bc4no=bc6.bc4no) as bc4name into #tmp4 from bc6 where pl1no=@pl1no and bc6date between @bdate and @edate and bc4no between @bcode and @ecode and bc5type=@bc5type order by bc5id
			insert into intra3.dbo.bc6s (nowno,pl1no,bc5type,bc5id,bc5name,bc6date,bc5sname,bc5model,bc6memo,pl1no2,bc4no,bc4name,bc6price) select @nowno,pl1no,bc5type,bc5id,bc5name,bc6date,bc5sname,bc5model,bc6memo,pl1no2,bc4no,bc4name,bc6price from #tmp4
			drop table #tmp4
		end
	end
END
go

