-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[pe1_B1101] (@nowno char(9),@dp3name char(50),@bdate datetime,@edate datetime)
AS
BEGIN
	SET NOCOUNT ON;
	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
	if (select object_id('tempdb..#tmp2'))is not null
	begin
		drop table #tmp2;
	end

	delete from pe3 where pe3month=CONVERT(nvarchar(6), @bdate, 112) and dp3name=@dp3name
CREATE TABLE #tmp (dep char(4),usrno char(5),usrname nvarchar(50),pf1sup decimal(8, 0),pf1nno decimal(6, 0),pf1gnd datetime,pf1gnl datetime,pf1ind datetime,pf1inl datetime,pf1umon2 decimal(5, 0),pf1upi2 decimal(5, 2),pf1lef datetime,pf1htype nchar(1),pf1inm decimal(8, 0),pf1upi1 decimal(5, 2),pf1umon decimal(5, 0) ,pf1ari datetime,post char(3),pf1lef2 char(1),pf1yn4 char(1),pf1yn5 char(1) )	
--pf1gnl= 退保日  pf1gnd 投保日
insert into #tmp (dep, usrno, usrname, pf1sup, pf1nno, pf1gnd, pf1gnl, pf1ind, pf1inl, pf1umon2, pf1upi2, pf1lef, pf1htype, pf1inm,pf1upi1,pf1umon, pf1ari,post,pf1lef2,pf1yn4,pf1yn5)
select  dep,usrno, usrname, pf1sup, pf1nno, pf1gnd, pf1gnl, pf1ind, pf1inl, pf1umon2, pf1upi2, pf1lef, pf1htype, pf1inm,pf1upi1,pf1umon, pf1ari,post,pf1lef2,pf1yn4,pf1yn5 from usr where pf1yn4<>'Y' AND dp3name=@dp3name AND ((pf1lef >=@bdate or pf1gnl >=@bdate or pf1lef is null) or ((pf1lef >=@bdate or pf1gnl >=@bdate or pf1lef is null) and pf1gnl>=@bdate)) AND pf1gnd<=@edate and (pf1gnl is null or pf1gnl >=@bdate) AND dep in (select dp1no from depcode where dp1over <> 'Y')
insert into #tmp (dep, usrno, usrname, pf1sup, pf1nno, pf1gnd, pf1gnl, pf1ind, pf1inl, pf1umon2, pf1upi2, pf1lef, pf1htype, pf1inm,pf1upi1,pf1umon, pf1ari,post,pf1yn4,pf1yn5)
select pl1no,'ZZZZZ', usrname, pf1sup, pf1nno, pf1gnd, pf1gnl, pf1ind, pf1inl, pf1umon2, pf1upi2, NULL, '', pf1inm,pf1upi1,pf1umon, NULL, 'ZZ','N','N' from pe2 where dp3name=@dp3name AND pf1gnd<=@edate AND pl1no in (select dp1no from depcode where dp1over <> 'Y')

UPDATE #tmp SET
    #tmp.pf1gnd = intranet2.dbo.pe4.pf1gnd2,
    #tmp.pf1gnl = intranet2.dbo.pe4.pf1gnl2,
	 #tmp.pf1nno = intranet2.dbo.pe4.pf1nno2
FROM #tmp INNER JOIN  intranet2.dbo.pe4 ON #tmp.usrno = intranet2.dbo.pe4.usrno
WHERE intranet2.dbo.pe4.dp3name2=@dp3name and convert(varchar(6),intranet2.dbo.pe4.pf1gnd2,112) =convert(varchar(6),@bdate,112)

UPDATE #tmp SET
    #tmp.pf1gnd = intranet2.dbo.pe4.pf1gnd,
    #tmp.pf1gnl = intranet2.dbo.pe4.pf1gnl,
    #tmp.pf1nno = intranet2.dbo.pe4.pf1nno
FROM #tmp INNER JOIN  intranet2.dbo.pe4 ON #tmp.usrno = intranet2.dbo.pe4.usrno
WHERE intranet2.dbo.pe4.dp3name=@dp3name and convert(varchar(6),intranet2.dbo.pe4.pf1gnl,112) =convert(varchar(6),@bdate,112)

insert into #tmp (dep,usrno,usrname,pf1ari,pf1lef,pf1gnd,pf1gnl,pf1nno,pf1sup,pf1ind, pf1inl, pf1umon2,pf1upi2,pf1htype,pf1inm,pf1upi1,pf1umon,post,pf1lef2,pf1yn4,pf1yn5)
select pl1no,usrno,usrname,(select pf1ari from usr where usrno=pe4.usrno),(select pf1lef from usr where usrno=pe4.usrno),pf1gnd,pf1gnl,pf1nno,pf1sup,pf1ind,pf1inl,(select pf1umon2 from usr where usrno=pe4.usrno),pe4.pf1upi2,(select pf1htype from usr where usrno=pe4.usrno),pe4.pf1inm,pe4.pf1upi1,(select pf1umon from usr where usrno=pe4.usrno),(select post from usr where usrno=pe4.usrno),(select pf1lef2 from usr where usrno=pe4.usrno),'N','N' from intranet2.dbo.pe4 as pe4 where dp3name=@dp3name and convert(varchar(6),pf1gnl,112) =convert(varchar(6),@bdate,112) and not exists (select usrno from #tmp where usrno=pe4.usrno)

insert into #tmp (dep,usrno,usrname,pf1ari,pf1lef,pf1gnd,pf1gnl,pf1nno,pf1sup,pf1ind,pf1inl,pf1umon2,pf1upi2,pf1htype,pf1inm,pf1upi1,pf1umon,post,pf1lef2,pf1yn4,pf1yn5)
select pl1no2,usrno,usrname,(select pf1ari from usr where usrno=pe4.usrno),(select pf1lef from usr where usrno=pe4.usrno),pf1gnd2,pf1gnl2,pf1nno2,pf1sup2,pf1ind2,pf1inl2,(select pf1umon2 from usr where usrno=pe4.usrno),pf1upi22,(select pf1htype from usr where usrno=pe4.usrno),pe4.pf1inm2,pf1upi12,(select pf1umon from usr where usrno=pe4.usrno),(select post from usr where usrno=pe4.usrno),(select pf1lef2 from usr where usrno=pe4.usrno),'N','N' from intranet2.dbo.pe4 as pe4 where dp3name2=@dp3name and convert(varchar(6),pf1gnd2,112) =convert(varchar(6),@bdate,112)  and  not exists (select usrno from #tmp where usrno=pe4.usrno)
--pf1ari,pf1lef,pf1umon2 ,pf1htype,pf1umon, post,pf1lef2

UPDATE #tmp SET #tmp.dep = intranet2.dbo.pe4.pl1no
FROM #tmp INNER JOIN  intranet2.dbo.pe4 ON #tmp.usrno = intranet2.dbo.pe4.usrno
WHERE intranet2.dbo.pe4.dp3name=@dp3name and convert(varchar(6),intranet2.dbo.pe4.pe4edate,112)=convert(varchar(6),@bdate,112)

select * from #tmp
drop table #tmp;
END
go

