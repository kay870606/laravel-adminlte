CREATE VIEW dbo.v_dp1
AS
SELECT     dbo.depcode.DP1NO, dbo.depcode.DP1NAME, dbo.depcode.dp1no2, dbo.depcode.dp1yn, dbo.depcode.dp1over, dbo.depcode.oy1over, dbo.depcode.oy1date, dbo.depcode.oy1month, 
                      dbo.depcode.dp1lun, dbo.depcode.dp1sort, dbo.depcode.dp1yn2, dbo.depcode.dp1date, dbo.depcode.dp1lun2, dbo.lu1.lu1name, dbo.lu1.lu1sort, dbo.lu1.lu1lun, dbo.lu1.lu1dno, dbo.lu1.lu2no, 
                      dbo.depcode.dp1lsort, dbo.depcode.pl1mon, dbo.depcode.pl1date, dbo.depcode.pl1dyn, dbo.depcode.dp1pi, dbo.depcode.dp1pi2, dbo.depcode.dp1mon, dbo.depcode.gr1no, dbo.depcode.dp1aover, 
                      dbo.depcode.dp1no3, dbo.depcode.dp1fok, dbo.depcode.pf1hr2, dbo.depcode.dp1bser, dbo.depcode.dp1byn, dbo.depcode.dp1card, dbo.depcode.dp1bn, dbo.depcode.gl1sum, 
                      dbo.depcode.dp1comm, dbo.depcode.dp1ip
FROM         dbo.depcode INNER JOIN
                      dbo.lu1 ON dbo.depcode.dp1lun2 = dbo.lu1.lu1no
go

