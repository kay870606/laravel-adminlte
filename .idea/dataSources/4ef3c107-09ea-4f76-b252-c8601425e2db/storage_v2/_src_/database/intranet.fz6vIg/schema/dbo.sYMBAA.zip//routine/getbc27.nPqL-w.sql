-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[getbc27] (@nowno char(9),@pl1no char(4),@bcode char(6),@ecode char(6),@bdate nchar(10),@edate nchar(10))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
	if (select object_id('tempdb..#tmp2'))is not null
	begin
		drop table #tmp2;
	end
	if (select object_id('tempdb..#tmp3'))is not null
	begin
		drop table #tmp3;
	end
	if (select object_id('tempdb..#tmp4'))is not null
	begin
		drop table #tmp4;
	end
	delete from intra3.dbo.bc7 where nowno=@nowno
	if @bdate='' and @edate=''
	begin
		if @bcode='' and @ecode=''
		begin
			select bc2.*,bb1.bb1name,bb1.bb1eng into #tmp from bc2n as bc2,bb1 where bc2.bb1no=bb1.bb1no and bc2.pl1no=@pl1no and bc2.bc2flag='2'
			insert into intra3.dbo.bc7 (nowno,pl1no,bb1no,bb1id,bb1name,bb1eng,bc1ser,bz1date2,bz1name,bc1ser2,bc1not) select @nowno,@pl1no,bb1no,bb1id,bb1name,bb1eng,bc1ser,bz1date2,bz1name,0,bc1not  from tempdb.#tmp
			drop table #tmp
		end
		else
		begin
			select bc2.*,bb1.bb1name,bb1.bb1eng into #tmp2 from bc2n as bc2,bb1 where bc2.bb1no=bb1.bb1no and bc2.pl1no=@pl1no and bc2.bc2flag='2' and bc2.bb1no between @bcode and @ecode
			insert into intra3.dbo.bc7 (nowno,pl1no,bb1no,bb1id,bb1name,bb1eng,bc1ser,bz1date2,bz1name,bc1ser2,bc1not) select @nowno,@pl1no,bb1no,bb1id,bb1name,bb1eng,bc1ser,bz1date2,bz1name,0,bc1not  from tempdb.#tmp2
			drop table #tmp2
		end
	end
	else
	begin
		if @bcode='' and @ecode=''
		begin
			select bc2.*,bb1.bb1name,bb1.bb1eng into #tmp3 from bc2n as bc2,bb1 where bc2.bb1no=bb1.bb1no and bc2.pl1no=@pl1no and bc2.bc2flag='2' and bc2.bz1date2 between @bdate and @edate
			insert into intra3.dbo.bc7 (nowno,pl1no,bb1no,bb1id,bb1name,bb1eng,bc1ser,bz1date2,bz1name,bc1ser2,bc1not) select @nowno,@pl1no,bb1no,bb1id,bb1name,bb1eng,bc1ser,bz1date2,bz1name,0,bc1not  from tempdb.#tmp3
			drop table #tmp3
		end
		else
		begin
			select bc2.*,bb1.bb1name,bb1.bb1eng into #tmp4 from bc2n as bc2,bb1 where bc2.bb1no=bb1.bb1no and bc2.pl1no=@pl1no and bc2.bc2flag='2' and bc2.bb1no between @bcode and @ecode and bc2.bz1date2 between @bdate and @edate
			insert into intra3.dbo.bc7 (nowno,pl1no,bb1no,bb1id,bb1name,bb1eng,bc1ser,bz1date2,bz1name,bc1ser2,bc1not) select @nowno,@pl1no,bb1no,bb1id,bb1name,bb1eng,bc1ser,bz1date2,bz1name,0,bc1not  from tempdb.#tmp4
			drop table #tmp4
		end
	end

END
go

