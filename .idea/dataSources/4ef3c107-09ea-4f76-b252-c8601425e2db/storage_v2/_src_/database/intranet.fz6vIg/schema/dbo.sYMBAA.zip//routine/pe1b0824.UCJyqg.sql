-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[pe1b0824] (@nowno char(9),@byy char(4),@bmm char(2),@bdate char(6),@edate char(6),@mdate datetime,@pl1no char(4))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	delete from intra3.dbo.pe1_B0824 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)

	set @bdate=@byy+'01'
	set @edate=@byy+@bmm
	set @mdate=@byy+'/'+'01'+'/'+'01' --取年月用
	insert into intra3.dbo.pe1_B0824 (nowno,pl1no,pe1no,m1,m2,m3,m4,m5,m6,m7,m8,m9,m10,m11,m12,mtotal,mavg) select @nowno,pl1no,pe1no,0,0,0,0,0,0,0,0,0,0,0,0,0,0 from sm3 where  pl1no in (select pl1no from intra3.dbo.dp1ch where nowno=@nowno) group by pl1no,pe1no order by pl1no,pe1no
	create table #tmp1 (pl1no char(4),pe1no char(5),mm char(2),mon1 decimal(12, 2),sm1month char(6))
	insert into #tmp1 (pl1no,pe1no,mm,mon1,sm1month) select pl1no,pe1no,right(sm1month,2) as mm,sum(sm1a+sm1b+sm1d+sm1e+sm1f+sm1g+sm1h+sm1i+sm1j+sm1k+sm1gmon+sm1m-sm1o-sm1u-sm1p-sm1w) as mon1,sm1month from sm3 where pl1no in (select pl1no from intra3.dbo.dp1ch where nowno=@nowno) and sm1month between @bdate and @edate group by pl1no,pe1no,sm1month
	---------------------------------------------------------------------------
	declare @max int,@i int,@t char(3),@t2 varchar(350)
	set @max=cast(@bmm as decimal(2,0)) --執行次數
	set @i=1
	WHILE @i <= @max
	BEGIN
		set @t = convert(char(2),@i) --欄位m1~m截止月
		set @t2='update intra3.dbo.pe1_b0824 set m'+@t+'=isnull((select mon1 from #tmp1 where '+convert(char(6),DATEADD(month,@i-1,@mdate),112)+'=sm1month and pl1no=intra3.dbo.pe1_b0824.pl1no and pe1no=intra3.dbo.pe1_b0824.pe1no),0)'
		exec (@t2)
		SET @i = @i + 1
	END
	update intra3.dbo.pe1_b0824 set mtotal= m1+m2+m3+m4+m5+m6+m7+m8+m9+m10+m11+m12
	update intra3.dbo.pe1_b0824 set mavg=round((mtotal/@max),2)
	update intra3.dbo.pe1_b0824 set nowno=@nowno 
	update intra3.dbo.pe1_b0824 set pe1name=usr.usrname from usr join intra3.dbo.pe1_b0824 ON usr.usrno=intra3.dbo.pe1_b0824.pe1no
	update intra3.dbo.pe1_b0824 set po2no=usr.po2no from usr join intra3.dbo.pe1_b0824 ON usr.usrno=intra3.dbo.pe1_b0824.pe1no--職務代號
	update intra3.dbo.pe1_b0824 set po2name=po2.po2name from po2 join intra3.dbo.pe1_b0824 ON po2.po2no=intra3.dbo.pe1_b0824.po2no--職務名稱
	update intra3.dbo.pe1_b0824 set pf1start=usr.pf1start from usr join intra3.dbo.pe1_b0824 ON usr.usrno=intra3.dbo.pe1_b0824.pe1no --到店日
	update intra3.dbo.pe1_b0824 set pf1ari=usr.pf1ari from usr join intra3.dbo.pe1_b0824 ON usr.usrno=intra3.dbo.pe1_b0824.pe1no --到職日
	update intra3.dbo.pe1_b0824 set pf1lef=usr.pf1lef from usr join intra3.dbo.pe1_b0824 ON usr.usrno=intra3.dbo.pe1_b0824.pe1no
	--select * from #tmp1
	drop table #tmp1
	delete from intra3.dbo.pe1_B0824 where nowno=@nowno and m1=0 and m2=0 and m3=0 and m4=0 and m5=0 and m6=0 and m7=0 and m8=0 and m9=0 and m10=0 and m11=0 and m12=0 and mavg=0
	select * from intra3.dbo.pe1_b0824 where nowno=@nowno order by pl1no,pe1no
END
go

