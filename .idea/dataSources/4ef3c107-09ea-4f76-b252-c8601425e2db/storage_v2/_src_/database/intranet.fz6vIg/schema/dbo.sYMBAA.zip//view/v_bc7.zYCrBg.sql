CREATE VIEW dbo.v_bc7
AS
SELECT          dbo.bc7.pl1no, dbo.bc7.bc5type, dbo.bc7.bc5id, dbo.bc7.bc7date, dbo.bc7.bc7name, dbo.bc7.bc7price, 
                            dbo.bc7.bc7memo, dbo.bc7.us1no, dbo.bc7.bc7idate, dbo.bc7.pl1no2, dbo.bc7.bc7rdate, dbo.bc7.bc7rmemo, 
                            dbo.bc7.in1date, dbo.bc7.bc5way, dbo.bc7.bz1name1, dbo.bc7.bc7out, dbo.bc7.bc7odate, dbo.bc7.bc7date2, 
                            dbo.bc7.su1name, dbo.bc5.bc5name, dbo.bc5.bc4no, dbo.bc5.bc6date, dbo.bc5.bc5sname, dbo.bc5.bc5model, 
                            dbo.bc5.bc5from, dbo.bc5.bc5memo, dbo.bc5.bc6price, dbo.bc5.bc5user, dbo.bc5.bz1name1 AS Expr1, 
                            dbo.bc5.bc5ok, dbo.bc4.bc4name
FROM              dbo.bc5 INNER JOIN
                            dbo.bc7 ON dbo.bc5.bc5id = dbo.bc7.bc5id AND dbo.bc5.pl1no = dbo.bc7.pl1no INNER JOIN
                            dbo.bc4 ON dbo.bc5.bc4no = dbo.bc4.bc4no
go

