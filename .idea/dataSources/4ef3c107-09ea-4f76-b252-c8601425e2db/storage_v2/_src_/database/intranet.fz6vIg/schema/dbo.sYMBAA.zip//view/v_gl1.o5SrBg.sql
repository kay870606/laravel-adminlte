CREATE VIEW dbo.v_gl1
AS
SELECT          dbo.gl1.pl1no, dbo.depcode.DP1NAME, dbo.ge1.ge1no, dbo.ge1.ge1no1, dbo.ge1.ge1name, dbo.gl1.gl1pi, 
                            dbo.gl1.bk1type, dbo.gl1.bk1type2, dbo.gl1.gl1memo, dbo.gl1.gl1date1, dbo.gl1.gl1mon1, dbo.gl1.gl1date2, 
                            dbo.gl1.gl1mon2, dbo.gl1.gl1date3, dbo.gl1.gl1mon3, dbo.gl1.gl1omon, dbo.gl1.gl1omon2, dbo.gl1.gl1pi1, 
                            dbo.gl1.gl1pi2, dbo.gl1.gl1pi3, dbo.gl1.gl1pi4, dbo.gl1.gl1pi5, dbo.gl1.gl1pi6, dbo.gl1.gl1pi8, dbo.gl1.gl1pi7, 
                            dbo.gl1.gl1pi9, dbo.gl1.gl1pia, dbo.gl1.gl1price1, dbo.gl1.gl1price3, dbo.gl1.gl1price21, dbo.gl1.gl1price2, 
                            dbo.gl1.gl1price23, dbo.gl1.gl1price22, dbo.gl1.gl1mon21, dbo.gl1.gl1mon22, dbo.gl1.gl1mon23, dbo.gl1.gl1jm, 
                            dbo.gl1.ge1bn, dbo.gl1.ge1bname, dbo.gl1.ge1ba, dbo.gl1.ge1bb, dbo.gl1.ge1bc, dbo.gl1.gl1edit, dbo.gl1.gl1bpi1, 
                            dbo.gl1.gl1prt, dbo.gl1.gl1bpi2, dbo.gl1.gl1bpi3, dbo.gl1.gl1bpi4, dbo.gl1.gl1bpi5, dbo.gl1.gl1bpi6, dbo.gl1.gl1bpi7, 
                            dbo.gl1.gl1bpi8, dbo.gl1.gl1bpi9, dbo.gl1.gl1bpia, dbo.depcode.dp1yn, dbo.depcode.dp1over, dbo.depcode.oy1over, 
                            dbo.depcode.oy1date, dbo.depcode.oy1month, dbo.depcode.dp1lun, dbo.depcode.dp1sort, dbo.depcode.dp1yn2, 
                            dbo.depcode.dp1date, dbo.depcode.dp1lun2, dbo.depcode.dp1lsort, dbo.ge1.po2no, dbo.ge1.usrno, 
                            dbo.depcode.dp1bn, dbo.ge1.ge1no2, dbo.depcode.pl1mon, dbo.depcode.pl1date, dbo.depcode.DP1NO, 
                            dbo.gl1.gl1num, dbo.depcode.bk1peo, dbo.depcode.bk1num, dbo.depcode.bk1name, dbo.depcode.bk1name2, 
                            dbo.depcode.bk1num2, dbo.depcode.bk1peo2, dbo.depcode.dp1no2, dbo.depcode.dp1lun3, dbo.gl1.gl1bpib, 
                            dbo.gl1.gl1pib
FROM              dbo.gl1 INNER JOIN
                            dbo.depcode ON dbo.gl1.pl1no = dbo.depcode.DP1NO INNER JOIN
                            dbo.ge1 ON dbo.gl1.ge1no = dbo.ge1.ge1no
go

exec sp_addextendedproperty 'MS_Description', '每股台幣金額', 'SCHEMA', 'dbo', 'VIEW', 'v_gl1', 'COLUMN', 'gl1omon'
go

exec sp_addextendedproperty 'MS_Description', '每股外幣金額', 'SCHEMA', 'dbo', 'VIEW', 'v_gl1', 'COLUMN', 'gl1omon2'
go

exec sp_addextendedproperty 'MS_Description', '股東股', 'SCHEMA', 'dbo', 'VIEW', 'v_gl1', 'COLUMN', 'gl1pi1'
go

exec sp_addextendedproperty 'MS_Description', '成長基金股', 'SCHEMA', 'dbo', 'VIEW', 'v_gl1', 'COLUMN', 'gl1pi2'
go

exec sp_addextendedproperty 'MS_Description', '外股', 'SCHEMA', 'dbo', 'VIEW', 'v_gl1', 'COLUMN', 'gl1pi3'
go

exec sp_addextendedproperty 'MS_Description', '處級股', 'SCHEMA', 'dbo', 'VIEW', 'v_gl1', 'COLUMN', 'gl1pi4'
go

exec sp_addextendedproperty 'MS_Description', '福利股', 'SCHEMA', 'dbo', 'VIEW', 'v_gl1', 'COLUMN', 'gl1pi5'
go

exec sp_addextendedproperty 'MS_Description', '抽籤股', 'SCHEMA', 'dbo', 'VIEW', 'v_gl1', 'COLUMN', 'gl1pi6'
go

exec sp_addextendedproperty 'MS_Description', '放棄股', 'SCHEMA', 'dbo', 'VIEW', 'v_gl1', 'COLUMN', 'gl1pi8'
go

exec sp_addextendedproperty 'MS_Description', '培訓股', 'SCHEMA', 'dbo', 'VIEW', 'v_gl1', 'COLUMN', 'gl1pi7'
go

exec sp_addextendedproperty 'MS_Description', '異動股數', 'SCHEMA', 'dbo', 'VIEW', 'v_gl1', 'COLUMN', 'gl1pi9'
go

exec sp_addextendedproperty 'MS_Description', '幹部股', 'SCHEMA', 'dbo', 'VIEW', 'v_gl1', 'COLUMN', 'gl1pia'
go

exec sp_addextendedproperty 'MS_Description', '繳款單股金額一', 'SCHEMA', 'dbo', 'VIEW', 'v_gl1', 'COLUMN', 'gl1price1'
go

exec sp_addextendedproperty 'MS_Description', '繳款單股金額三', 'SCHEMA', 'dbo', 'VIEW', 'v_gl1', 'COLUMN', 'gl1price3'
go

exec sp_addextendedproperty 'MS_Description', '海外單股金額一', 'SCHEMA', 'dbo', 'VIEW', 'v_gl1', 'COLUMN', 'gl1price21'
go

exec sp_addextendedproperty 'MS_Description', '繳款單股金額二', 'SCHEMA', 'dbo', 'VIEW', 'v_gl1', 'COLUMN', 'gl1price2'
go

exec sp_addextendedproperty 'MS_Description', '海外單股金額三', 'SCHEMA', 'dbo', 'VIEW', 'v_gl1', 'COLUMN', 'gl1price23'
go

exec sp_addextendedproperty 'MS_Description', '海外單股金額二', 'SCHEMA', 'dbo', 'VIEW', 'v_gl1', 'COLUMN', 'gl1price22'
go

exec sp_addextendedproperty 'MS_Description', '海外金額一', 'SCHEMA', 'dbo', 'VIEW', 'v_gl1', 'COLUMN', 'gl1mon21'
go

exec sp_addextendedproperty 'MS_Description', '海外金額二', 'SCHEMA', 'dbo', 'VIEW', 'v_gl1', 'COLUMN', 'gl1mon22'
go

exec sp_addextendedproperty 'MS_Description', '海外金額三', 'SCHEMA', 'dbo', 'VIEW', 'v_gl1', 'COLUMN', 'gl1mon23'
go

exec sp_addextendedproperty 'MS_Description', '外幣幣別', 'SCHEMA', 'dbo', 'VIEW', 'v_gl1', 'COLUMN', 'gl1jm'
go

exec sp_addextendedproperty 'MS_Description', '分行', 'SCHEMA', 'dbo', 'VIEW', 'v_gl1', 'COLUMN', 'ge1bn'
go

exec sp_addextendedproperty 'MS_Description', '銀行名稱', 'SCHEMA', 'dbo', 'VIEW', 'v_gl1', 'COLUMN', 'ge1bname'
go

exec sp_addextendedproperty 'MS_Description', '戶名', 'SCHEMA', 'dbo', 'VIEW', 'v_gl1', 'COLUMN', 'ge1ba'
go

exec sp_addextendedproperty 'MS_Description', '帳號', 'SCHEMA', 'dbo', 'VIEW', 'v_gl1', 'COLUMN', 'ge1bb'
go

exec sp_addextendedproperty 'MS_Description', '身份字號', 'SCHEMA', 'dbo', 'VIEW', 'v_gl1', 'COLUMN', 'ge1bc'
go

exec sp_addextendedproperty 'MS_Description', '異動旗標', 'SCHEMA', 'dbo', 'VIEW', 'v_gl1', 'COLUMN', 'gl1edit'
go

exec sp_addextendedproperty 'MS_Description', '股東股', 'SCHEMA', 'dbo', 'VIEW', 'v_gl1', 'COLUMN', 'gl1bpi1'
go

exec sp_addextendedproperty 'MS_Description', '不顯示', 'SCHEMA', 'dbo', 'VIEW', 'v_gl1', 'COLUMN', 'gl1prt'
go

exec sp_addextendedproperty 'MS_Description', '成長基金股', 'SCHEMA', 'dbo', 'VIEW', 'v_gl1', 'COLUMN', 'gl1bpi2'
go

exec sp_addextendedproperty 'MS_Description', '外股', 'SCHEMA', 'dbo', 'VIEW', 'v_gl1', 'COLUMN', 'gl1bpi3'
go

exec sp_addextendedproperty 'MS_Description', '處級股', 'SCHEMA', 'dbo', 'VIEW', 'v_gl1', 'COLUMN', 'gl1bpi4'
go

exec sp_addextendedproperty 'MS_Description', '福利股', 'SCHEMA', 'dbo', 'VIEW', 'v_gl1', 'COLUMN', 'gl1bpi5'
go

exec sp_addextendedproperty 'MS_Description', '抽籤股', 'SCHEMA', 'dbo', 'VIEW', 'v_gl1', 'COLUMN', 'gl1bpi6'
go

exec sp_addextendedproperty 'MS_Description', '培訓股', 'SCHEMA', 'dbo', 'VIEW', 'v_gl1', 'COLUMN', 'gl1bpi7'
go

exec sp_addextendedproperty 'MS_Description', '放棄股', 'SCHEMA', 'dbo', 'VIEW', 'v_gl1', 'COLUMN', 'gl1bpi8'
go

exec sp_addextendedproperty 'MS_Description', '異動股數', 'SCHEMA', 'dbo', 'VIEW', 'v_gl1', 'COLUMN', 'gl1bpi9'
go

exec sp_addextendedproperty 'MS_Description', '幹部股', 'SCHEMA', 'dbo', 'VIEW', 'v_gl1', 'COLUMN', 'gl1bpia'
go

