-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[lu1ch](@nowno char(9),@pe1no char(5),@fucno char(5))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

delete from intra3.dbo.lu1ch where idate<CONVERT(nvarchar(30), GETDATE(), 111)
delete from intra3.dbo.lu1ch where (nowno=@nowno or fucno=@fucno) and (pe1no=@pe1no or idate<CONVERT(nvarchar(30), GETDATE(), 111))

insert into intra3.dbo.lu1ch (nowno,dp1lun,lu1dno,lu1no,lu1name,dp1no,dp1no2,dp1name,dp1over,dp1yn2,pe1no,fucno) select @nowno,dp1lun,(select lu1dno from lu1 where lu1no=dp1lun2)as lu1dno,dp1lun2,(select lu1name from lu1 where lu1no=dp1lun2)as lu1name,dp1no,dp1no2,dp1name,dp1over,dp1yn2,@pe1no,@fucno from depcode where dp1no in (select pl1no from intra3.dbo.dp1ch where nowno=@nowno) order by dp1lun,lu1dno,dp1lun2


END
go

