-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[ge1rep1] (@nowno char(9),@bcode char(5),@ecode char(5))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	delete from intra3.dbo.ge1d where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
		if(@bcode='' and @ecode='')
	begin
		insert into intra3.dbo.ge1d (nowno,ge1no,ge1name,ge1no1,pf1eng) select @nowno,ge1.ge1no,ge1.ge1name,ge1no1,(select pf1eng from usr where usrno=ge1.usrno) as pf1eng from ge1
	end
	else
	begin
		insert into intra3.dbo.ge1d (nowno,ge1no,ge1name,ge1no1,pf1eng) select @nowno,ge1.ge1no,ge1.ge1name,ge1no1,(select pf1eng from usr where usrno=ge1.usrno) as pf1eng from ge1 where ge1no between @bcode and @ecode
	end
	update intra3.dbo.ge1d set ge1no1=ge1no where ge1no1=''
	select * from intra3.dbo.ge1d where nowno=@nowno order by ge1no1

END
go

