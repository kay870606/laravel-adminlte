-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[be1_a0802] (@nowno char(9),@pl1no char(4),@bb1yyyy char(4))
	-- Add the parameters for the stored procedure here
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
delete from intra3.dbo.be1_A0302 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
  begin
    insert into intra3.dbo.be1_A0302 (nowno,bb1no) select @nowno,bb1no from intranet2.dbo.bd1 where pl1no=@pl1no and bb1yyyy=@bb1yyyy group by bb1no
  end
  create table #tmp (bb1no2 char(6),bb1name nvarchar(50),bb1eng nvarchar(50))
  insert into #tmp (bb1no2,bb1name,bb1eng) select bb1no,bb1name,bb1eng from bb1
  update intra3.dbo.be1_A0302 set bb1name=(select bb1name from #tmp where bb1no=bb1no2)
  update intra3.dbo.be1_A0302 set bb1eng=(select bb1eng from #tmp where bb1no=bb1no2)
  drop table #tmp
END
go

