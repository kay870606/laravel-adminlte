-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[getac5] (@pl1no char(4),@ac5month char(6),@ac5mon decimal(12,2))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	declare @mon1 decimal(12,2),@mon2 decimal(12,2),@mon3 decimal(12,2),@ac4no3 char(4)
	set @ac4no3='3000'
	
	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp
	end
	if (select object_id('tempdb..#tmp2'))is not null
	begin
		drop table #tmp2
	end
	delete from intra3.dbo.ac5t where pl1no=@pl1no and ac5month=@ac5month
	
	select * into #tmp from ac5 where ac5month=@ac5month and pl1no=@pl1no order by left(ac4no,1),ac4type,ac4no
	insert into tempdb.#tmp (ac5month,pl1no,ac4no,ac4name,ac4type,ac5mon,ac5emon,ac4edit,ac5note,ac5memo) values (@ac5month,@pl1no,'0000','上期結存','',@ac5mon,0,'','','')
	insert into tempdb.#tmp (ac5month,pl1no,ac4no,ac4name,ac4type,ac5mon,ac5emon,ac4edit,ac5note,ac5memo) values (@ac5month,@pl1no,'200 ','下月預估保留款','Y',0,0,'','','')
	select  *,
	    ac4no1=case left(ac4no,1)
				when '3' then '3'
				else '1'
				end,
		ac5mon2=case left(ac4no,1)
				when '2' then ac5mon+ac5emon
				else 0
				end,
		ac5mon3=case left(ac4no,1)
				when '3' then ac5mon+ac5emon
				else 0
				end
	 into #tmp2 from tempdb.#tmp where pl1no=@pl1no and ac5month=@ac5month order by left(ac4no,1),ac4type,ac4no
	 insert into intra3.dbo.ac5t (ac5month,pl1no,ac4no1,ac4no,ac4name,ac4edit,ac5note,ac4type,ac5mon,ac5mon2,ac5mon3,ac5memo,ac5date)select ac5month,pl1no,ac4no1,ac4no,ac4name,ac4edit,ac5note,ac4type,ac5mon+ac5emon,ac5mon2,ac5mon3,ac5memo,CASE ac5date WHEN NULL THEN '' ELSE CONVERT(varchar(2), month(ac5date)) + '/' + CONVERT(varchar(2), day(ac5date)) END AS aa   from tempdb.#tmp2
	 update intra3.dbo.ac5t set ac5date='' where ac5date is null
	 update intra3.dbo.ac5t set ac5mon2=0,ac5mon3=0 where left(ac4no,1)='1' and pl1no=@pl1no and ac5month=@ac5month
	 update intra3.dbo.ac5t set ac5mon=0,ac5mon3=0 where left(ac4no,1)='2' and pl1no=@pl1no and ac5month=@ac5month
	 update intra3.dbo.ac5t set ac5mon=0,ac5mon2=0 where left(ac4no,1)='3' and pl1no=@pl1no and ac5month=@ac5month
	 select @mon1=sum(ac5mon),@mon2=sum(ac5mon2),@mon3=sum(ac5mon3)  from intra3.dbo.ac5t where pl1no=@pl1no and ac5month=@ac5month
	 if not exists (select * from intra3.dbo.ac5t where pl1no=@pl1no and ac5month=@ac5month and ac4no='2008')
		 insert into intra3.dbo.ac5t (ac5month,pl1no,ac4no1,ac4no,ac4name,ac4type,ac5mon,ac5mon2,ac5mon3)values (@ac5month,@pl1no,'','2008','支票款-贈品費','',0,0,0)
	 if not exists (select * from intra3.dbo.ac5t where pl1no=@pl1no and ac5month=@ac5month and ac4no='2009')
		 insert into intra3.dbo.ac5t (ac5month,pl1no,ac4no1,ac4no,ac4name,ac4type,ac5mon,ac5mon2,ac5mon3)values (@ac5month,@pl1no,'','2009','支票款-機器設備','',0,0,0)
	 if not exists (select * from intra3.dbo.ac5t where pl1no=@pl1no and ac5month=@ac5month and ac4no='2010')
		 insert into intra3.dbo.ac5t (ac5month,pl1no,ac4no1,ac4no,ac4name,ac4type,ac5mon,ac5mon2,ac5mon3)values (@ac5month,@pl1no,'','2010','支票款-其他支出','',0,0,0)

	 if not exists (select * from intra3.dbo.ac5t where pl1no=@pl1no and ac5month=@ac5month and ac4no=@ac4no3)
		 insert into intra3.dbo.ac5t (ac5month,pl1no,ac4no1,ac4no,ac4name,ac4type,ac5mon,ac5mon2,ac5mon3)values (@ac5month,@pl1no,'3',@ac4no3,'股利發放','',0,0,0)
		
	 insert into intra3.dbo.ac5t (ac5month,pl1no,ac4no1,ac4no,ac4name,ac4type,ac5mon,ac5mon2,ac5mon3)values (@ac5month,@pl1no,'1','2ZZZ','                  小  計','Y',@mon1,@mon2,@mon1-@mon2)
	 insert into intra3.dbo.ac5t (ac5month,pl1no,ac4no1,ac4no,ac4name,ac4type,ac5mon3)values (@ac5month,@pl1no,'3','3ZZZ','                 本期結存','Y',@mon1-@mon2-@mon3)
	select * from intra3.dbo.ac5t where pl1no=@pl1no and ac5month=@ac5month order by left(ac4no,1),ac4type,ac4no
	drop table #tmp
	drop table #tmp2

END
go

