-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[in1_A0403](@nowno char(9),@bym1 char(6),@bym2 char(6),@dp1lun char(1))
	-- Add the parameters for the stored procedure here

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end

	delete from intra3.dbo.in1_A0403 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
	Insert into intra3.dbo.in1_A0403 (nowno,dp1lun2,pl1no,in1mon,in1pi) select @nowno,(select dp1lun2 from depcode where dp1no=in1pre.pl1no),pl1no,sum(in1mon),(select in1pi from in1pre as A where A.in1yy+A.in1mm=@bym2 and A.pl1no=in1pre.pl1no) from in1pre where in1yy+in1mm between @bym1 and @bym2 and pl1no in (select dp1no from depcode where dp1lun=@dp1lun) group by pl1no
	--Insert into intra3.dbo.in1_A0403 (nowno,dp1lun2,pl1no,in1mon,in1pi) select @nowno,(select dp1lun2 from depcode where dp1no=in1pre.pl1no),pl1no,0,0 from in1pre where in1yy=LEFT(@bym1,4) and pl1no in (select dp1no from depcode where dp1lun=@dp1lun) and pl1no not in (select pl1no from intra3.dbo.in1_A0403 as A where A.nowno=@nowno) group by pl1no
	--有營收就要抓
	Insert into intra3.dbo.in1_A0403 (nowno,dp1lun2,pl1no,in1mon,in1pi) select @nowno,(select dp1lun2 from depcode where dp1no=in1pre.pl1no),pl1no,sum(in1mon),0 from in1pre where in1yy=LEFT(@bym1,4) and pl1no in (select dp1no from depcode where dp1lun=@dp1lun) and pl1no not in (select pl1no from intra3.dbo.in1_A0403 as A where A.nowno=@nowno) group by pl1no
	update intra3.dbo.in1_A0403 set lu2no=(select lu2no from lu1 where lu1no=dp1lun2) where nowno=@nowno
  Update intra3.dbo.in1_A0403 set in1mon2 = in1mon3 
    from (select pl1no,sum(bk1cah+bk1oth2+bk1oth+bk1mon2+bk1mon3)AS in1mon3
            from  intranet2.dbo.in2 as in2 
			 WHERE LEFT(CONVERT(varchar,bk1date,112),6)  between @bym1 and @bym2
			GROUP BY pl1no) Grouped 
	where intra3.dbo.in1_A0403.pl1no = Grouped.pl1no and intra3.dbo.in1_A0403.nowno=@nowno

  Update intra3.dbo.in1_A0403 set gl3mon = gl3mon2
    from (select pl1no,sum(gl4mon2)AS gl3mon2
            from  gl4
			 WHERE gl3month between @bym1 and @bym2 and gl3t3040='3040'
			GROUP BY pl1no) Grouped 
	where intra3.dbo.in1_A0403.pl1no = Grouped.pl1no and intra3.dbo.in1_A0403.nowno=@nowno
    
END
go

