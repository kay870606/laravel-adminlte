CREATE VIEW dbo.v_sn7
AS
SELECT     dbo.sn7.sn7no, dbo.sn8.sn1no, dbo.sn8.pu1price, dbo.sn8.pt1pi, dbo.sn8.pt1price, dbo.sn8.pt1qty, dbo.sn8.pt1mon, dbo.sn8.sn8memo, dbo.sn8.sn5no, dbo.sn8.sn6id, dbo.sn7.sn7date, 
                      dbo.sn7.cu1no, dbo.sn7.cu1uno, dbo.sn7.cu1tl, dbo.sn7.sn7month, dbo.sn7.sx1no, dbo.sn7.sn7memo, dbo.sn7.sa1ctax, dbo.sn7.sn7mon, dbo.sn7.sa2tax, dbo.sn7.sn7total
FROM         dbo.sn7 INNER JOIN
                      dbo.sn8 ON dbo.sn7.sn7no = dbo.sn8.sn7no
go

