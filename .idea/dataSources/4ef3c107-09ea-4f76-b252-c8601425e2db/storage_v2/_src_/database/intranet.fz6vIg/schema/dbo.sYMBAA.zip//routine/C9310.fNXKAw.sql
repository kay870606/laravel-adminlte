-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[C9310](@nowno char(9),@ecode char(6),@bcode char(6),@pf1lun char(1),@gl3t3040 char(4))
	AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	declare @i int,@po3date1 datetime,@po3date2 datetime,@usrno char(5),@ge1no char(5),@po1no char(3),@po2no char(3),@gl1pi numeric(9, 4),@dep char(4),@dp1lun2 char(2),@gl3month char(6),@gl4mon decimal(15, 0),@ye1nn decimal(6, 3),@gl4mon2 decimal(15, 0)
	delete from intra3.dbo.c9310
insert into intra3.dbo.c9310 (nowno,dep,dp1lun2,usrno,usrname,po1no,po1name,po2no,po2name,pf1ari,pf1bth,pf1lun) select @nowno,v_pe1.dep,v_pe1.dp1lun2,v_pe1.usrno,usrname,post,po1name,po2no,po2name,pf1ari,pf1bth,pf1lun
from intranet.dbo.v_pe1 where ((po1no in (select po1no from intra3.dbo.po1ch where nowno=@nowno) or po2no in (select po2no from intra3.dbo.po2ch where nowno=@nowno))) and usrno in (select usrno from intranet.dbo.ge1 where usrno<>'') and pf1lef is null
	select @i=count(*) from intra3.dbo.c9310
if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
	--if(@pf1lun ='Y')
	--begin
	--delete from intra3.dbo.c9310 where pf1lun='Y' 
	--end
select *,ROW_NUMBER() over (order by id) as nn into #tmp from intra3.dbo.c9310 where nowno=@nowno
while @i>0
begin
  select @usrno=usrno,@po1no=po1no,@po2no=po2no from #tmp where nn=@i
  select @ge1no=ge1no from intranet.dbo.ge1 where usrno=@usrno
  if @ge1no is null
  begin
  delete from intra3.dbo.c9310 where usrno=@usrno 
  end
  else
  begin
  --select @gl1pi=sum(gl1pi) from intranet.dbo.v_gl1 where usrno=@usrno and dp1over<>'Y' group by usrno
  --含乾股
  select @gl1pi=sum(gl1pi+gl1bpib) from intranet.dbo.v_gl1 where usrno=@usrno and dp1over<>'Y' group by usrno
  select @ye1nn=sum(ye1nn) from intranet.dbo.ye1 where pe1no=@usrno group by pe1no
  select top 1 @po3date1=po3date from intranet.dbo.po3 where usrno=@usrno and post2=@po1no order by po3date
  select top 1 @po3date2=po3date from intranet.dbo.po3 where usrno=@usrno and po2no2=@po2no order by po3date
  if @gl3t3040='A'
  begin
	select @gl4mon=sum(gl4mon) from intranet.dbo.gl4 where ge1no=@usrno and gl3month between @bcode and @ecode group by ge1no
	select @gl4mon2=sum(gl4mon2) from intranet.dbo.gl4 where ge1no=@usrno and gl3month between @bcode and @ecode group by ge1no
  end
  else
  begin
	select @gl4mon=sum(gl4mon) from intranet.dbo.gl4 where ge1no=@usrno and gl3t3040=@gl3t3040 and gl3month between @bcode and @ecode group by ge1no
	select @gl4mon2=sum(gl4mon2) from intranet.dbo.gl4 where ge1no=@usrno and gl3t3040=@gl3t3040 and gl3month between @bcode and @ecode group by ge1no
  end
  if @po3date1 is not null OR @po3date2 is not null
  begin
     update intra3.dbo.c9310 set po3date1=@po3date1,po3date2=@po3date2,gl1pi=@gl1pi,gl4mon=@gl4mon,ge1no=@ge1no,ye1nn=@ye1nn,gl4mon2=@gl4mon2 where usrno=@usrno
  end
  end
  set @i=@i-1
  update intra3.dbo.c9310 set ye1nn=0 where ye1nn is null
  update intra3.dbo.c9310 set gl4mon=0 where gl4mon is null
  update intra3.dbo.c9310 set gl4mon2=0 where gl4mon2 is null
  update intra3.dbo.c9310 set po3date1=Default where po3date1 is null
  update intra3.dbo.c9310 set po3date2=Default where po3date2 is null
  update intra3.dbo.c9310 set gl1pi=0 where gl1pi is null
END
drop table #tmp
END
go

