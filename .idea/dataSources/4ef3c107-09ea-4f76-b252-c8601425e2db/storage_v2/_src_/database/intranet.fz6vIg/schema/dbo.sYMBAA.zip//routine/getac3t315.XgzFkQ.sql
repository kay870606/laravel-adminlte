-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[getac3t315] (@nowno char(9),@pl1no char(4),@dp1lun char(1),@byy char(4),@bcode char(8),@ecode char(8))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
	delete from intra3.dbo.ac3t314 where ac3idate<CONVERT(nvarchar(30), GETDATE(), 111)
	delete from intra3.dbo.ac3t314 where nowno=@nowno
	create table #tmp (ad1date datetime,ad1no char(8),ac2no char(4),ac2no2 char(6),ac2name nvarchar(50),ad1dc char(1),ad1dmon decimal(12, 2),ad1cmon decimal(12, 2),ad1memo nvarchar(200))
--	select ad1.ad1date,ad2.* into #tmp from ad1,ad2 where ad1.ad1no=ad2.ad1no and ad1.pl1no=@pl1no and ad2.pl1no=@pl1no and ad1.ad1no between @bcode and @ecode
   	insert into #tmp exec getad1g15 @nowno,@pl1no,@dp1lun,@byy,@bcode,@ecode

	insert into intra3.dbo.ac3t314 (nowno,pl1no,ad1no,ad1date,ac2no,ac2no2,ac2name,ad1dc,ad1dmon,ad1cmon,ad1memo) select @nowno,@pl1no,ad1no,ad1date,ac2no,ac2no2,ac2name,ad1dc,ad1dmon,ad1cmon,ad1memo from #tmp
	drop table #tmp
	select * from intra3.dbo.ac3t314 where nowno=@nowno order by ad1date,ad1no

END
go

