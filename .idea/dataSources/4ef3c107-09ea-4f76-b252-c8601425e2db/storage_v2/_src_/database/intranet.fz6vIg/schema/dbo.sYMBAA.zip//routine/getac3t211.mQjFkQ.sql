-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[getac3t211]  (@nowno char(9),@ac3yy char(4),@bmm char(2),@dp1lun char(1))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
delete from intra3.dbo.ac3t4 where nowno=@nowno
if @bmm='01'
begin
	--insert into intra3.dbo.ac3t4 (nowno,pl1no,pl1name,dp1lun2,lu1sort,ad1mon) select nowno,pl1no,dp1name,dp1lun2,lu1sort,(ac3m1c-ac3m1d) as ad1mon from intra3.dbo.ac3t where nowno=@nowno
	insert into intra3.dbo.ac3t4 (nowno,pl1no,pl1name,dp1lun2,lu1sort,ad1mon) select nowno,pl1no,dp1name,dp1lun2,lu1sort,ac3m1c as ad1mon from intra3.dbo.ac3t where nowno=@nowno
end
if @bmm='02'
begin
	--insert into intra3.dbo.ac3t4 (nowno,pl1no,pl1name,dp1lun2,lu1sort,ad1mon) select nowno,pl1no,dp1name,dp1lun2,lu1sort,(ac3m2c-ac3m2d) as ad1mon from intra3.dbo.ac3t where nowno=@nowno
	insert into intra3.dbo.ac3t4 (nowno,pl1no,pl1name,dp1lun2,lu1sort,ad1mon) select nowno,pl1no,dp1name,dp1lun2,lu1sort,ac3m2c as ad1mon from intra3.dbo.ac3t where nowno=@nowno
end
if @bmm='03'
begin
	--insert into intra3.dbo.ac3t4 (nowno,pl1no,pl1name,dp1lun2,lu1sort,ad1mon) select nowno,pl1no,dp1name,dp1lun2,lu1sort,(ac3m3c-ac3m3d) as ad1mon from intra3.dbo.ac3t where nowno=@nowno
	insert into intra3.dbo.ac3t4 (nowno,pl1no,pl1name,dp1lun2,lu1sort,ad1mon) select nowno,pl1no,dp1name,dp1lun2,lu1sort,ac3m3c as ad1mon from intra3.dbo.ac3t where nowno=@nowno
end
if @bmm='04'
begin
	--insert into intra3.dbo.ac3t4 (nowno,pl1no,pl1name,dp1lun2,lu1sort,ad1mon) select nowno,pl1no,dp1name,dp1lun2,lu1sort,(ac3m4c-ac3m4d) as ad1mon from intra3.dbo.ac3t where nowno=@nowno
	insert into intra3.dbo.ac3t4 (nowno,pl1no,pl1name,dp1lun2,lu1sort,ad1mon) select nowno,pl1no,dp1name,dp1lun2,lu1sort,ac3m4c as ad1mon from intra3.dbo.ac3t where nowno=@nowno
end
if @bmm='05'
begin
	--insert into intra3.dbo.ac3t4 (nowno,pl1no,pl1name,dp1lun2,lu1sort,ad1mon) select nowno,pl1no,dp1name,dp1lun2,lu1sort,(ac3m5c-ac3m5d) as ad1mon from intra3.dbo.ac3t where nowno=@nowno
	insert into intra3.dbo.ac3t4 (nowno,pl1no,pl1name,dp1lun2,lu1sort,ad1mon) select nowno,pl1no,dp1name,dp1lun2,lu1sort,ac3m5c as ad1mon from intra3.dbo.ac3t where nowno=@nowno
end
if @bmm='06'
begin
	--insert into intra3.dbo.ac3t4 (nowno,pl1no,pl1name,dp1lun2,lu1sort,ad1mon) select nowno,pl1no,dp1name,dp1lun2,lu1sort,(ac3m6c-ac3m6d) as ad1mon from intra3.dbo.ac3t where nowno=@nowno
	insert into intra3.dbo.ac3t4 (nowno,pl1no,pl1name,dp1lun2,lu1sort,ad1mon) select nowno,pl1no,dp1name,dp1lun2,lu1sort,ac3m6c as ad1mon from intra3.dbo.ac3t where nowno=@nowno
end
if @bmm='07'
begin
	--insert into intra3.dbo.ac3t4 (nowno,pl1no,pl1name,dp1lun2,lu1sort,ad1mon) select nowno,pl1no,dp1name,dp1lun2,lu1sort,(ac3m7c-ac3m7d) as ad1mon from intra3.dbo.ac3t where nowno=@nowno
	insert into intra3.dbo.ac3t4 (nowno,pl1no,pl1name,dp1lun2,lu1sort,ad1mon) select nowno,pl1no,dp1name,dp1lun2,lu1sort,ac3m7c as ad1mon from intra3.dbo.ac3t where nowno=@nowno
end
if @bmm='08'
begin
	--insert into intra3.dbo.ac3t4 (nowno,pl1no,pl1name,dp1lun2,lu1sort,ad1mon) select nowno,pl1no,dp1name,dp1lun2,lu1sort,(ac3m8c-ac3m8d) as ad1mon from intra3.dbo.ac3t where nowno=@nowno
	insert into intra3.dbo.ac3t4 (nowno,pl1no,pl1name,dp1lun2,lu1sort,ad1mon) select nowno,pl1no,dp1name,dp1lun2,lu1sort,ac3m8c as ad1mon from intra3.dbo.ac3t where nowno=@nowno
end
if @bmm='09'
begin
	--insert into intra3.dbo.ac3t4 (nowno,pl1no,pl1name,dp1lun2,lu1sort,ad1mon) select nowno,pl1no,dp1name,dp1lun2,lu1sort,(ac3m9c-ac3m9d) as ad1mon from intra3.dbo.ac3t where nowno=@nowno
	insert into intra3.dbo.ac3t4 (nowno,pl1no,pl1name,dp1lun2,lu1sort,ad1mon) select nowno,pl1no,dp1name,dp1lun2,lu1sort,ac3m9c as ad1mon from intra3.dbo.ac3t where nowno=@nowno
end
if @bmm='10'
begin
	--insert into intra3.dbo.ac3t4 (nowno,pl1no,pl1name,dp1lun2,lu1sort,ad1mon) select nowno,pl1no,dp1name,dp1lun2,lu1sort,(ac3m10c-ac3m10d) as ad1mon from intra3.dbo.ac3t where nowno=@nowno
	insert into intra3.dbo.ac3t4 (nowno,pl1no,pl1name,dp1lun2,lu1sort,ad1mon) select nowno,pl1no,dp1name,dp1lun2,lu1sort,ac3m10c as ad1mon from intra3.dbo.ac3t where nowno=@nowno
end
if @bmm='11'
begin
	--insert into intra3.dbo.ac3t4 (nowno,pl1no,pl1name,dp1lun2,lu1sort,ad1mon) select nowno,pl1no,dp1name,dp1lun2,lu1sort,(ac3m11c-ac3m11d) as ad1mon from intra3.dbo.ac3t where nowno=@nowno
	insert into intra3.dbo.ac3t4 (nowno,pl1no,pl1name,dp1lun2,lu1sort,ad1mon) select nowno,pl1no,dp1name,dp1lun2,lu1sort,ac3m11c as ad1mon from intra3.dbo.ac3t where nowno=@nowno
end
if @bmm='12'
begin
	--insert into intra3.dbo.ac3t4 (nowno,pl1no,pl1name,dp1lun2,lu1sort,ad1mon) select nowno,pl1no,dp1name,dp1lun2,lu1sort,(ac3m12c-ac3m12d) as ad1mon from intra3.dbo.ac3t where nowno=@nowno
	insert into intra3.dbo.ac3t4 (nowno,pl1no,pl1name,dp1lun2,lu1sort,ad1mon) select nowno,pl1no,dp1name,dp1lun2,lu1sort,ac3m12c as ad1mon from intra3.dbo.ac3t where nowno=@nowno
end


--2018/9/20 貞 監管費 4110 金額 不算借方改為扣除4110-5的借方金額
  Update intra3.dbo.ac3t4 set ad1mon = ad1mon-ad1dmonsub    
    from (select ad2.pl1no ,SUM(ad2.ad1dmon) AS ad1dmonsub
            from  intranet2.dbo.ad1c as ad1 INNER JOIN intranet2.dbo.ad2c as ad2 ON ad1.ad1no+ad1.pl1no = ad2.ad1no+ad2.pl1no
			 WHERE (YEAR(ad1.ad1date) = @ac3yy) AND (ad2.ad1yy = @ac3yy) and month(ad1.ad1date)=@bmm and ad2.ac2no='4110' and ad2.ac2no2='5' and ad1dmon<>0 
			GROUP BY MONTH(ad1.ad1date),ad2.pl1no, ad2.ac2no) Grouped 			
	where intra3.dbo.ac3t4.pl1no = Grouped.pl1no and intra3.dbo.ac3t4.ad1mon<>0
--

update intra3.dbo.ac3t4 set dp1pi=d.dp1pi,dp1pi2=d.dp1pi2 FROM intra3.dbo.ac3t4 INNER JOIN intranet.dbo.depcode AS d ON intra3.dbo.ac3t4.pl1no = d.DP1NO
if (select object_id('tempdb..#tmp3'))is not null
begin
	drop table #tmp3;
end
if (select object_id('tempdb..#tmp1'))is not null
begin
	drop table #tmp1;
end
--select pl1no,d.DP1NAME as pl1name,sum(bk1cah+bk1oth2+bk1oth+bk1mon3+bk1mon2) as bk1cah into #tmp3 from intranet2.dbo.in2 inner join intranet.dbo.depcode as d ON intranet2.dbo.in2.pl1no=d.dp1no where year(intranet2.dbo.in2.bk1date)=@ac3yy and month(intranet2.dbo.in2.bk1date)=@bmm and d.dp1lun=@dp1lun group by intranet2.dbo.in2.pl1no,d.DP1NAME
select pl1no,d.DP1NAME as pl1name,sum(bk1cah+bk1oth2+bk1oth+bk1mon3+bk1mon2) as bk1cah into #tmp3 from intranet2.dbo.in2 as in2 inner join intranet.dbo.depcode as d ON in2.pl1no=d.dp1no where year(in2.bk1date)=@ac3yy and month(in2.bk1date)=@bmm and in2.pl1no in (select pl1no from df1 where in2.bk1date>=df1bdate) and d.dp1lun=@dp1lun group by in2.pl1no,d.DP1NAME
select pl1no,d.DP1NAME as pl1name,sum(bk1cah+bk1oth2+bk1oth+bk1mon3+bk1mon2) as bk1cah into #tmp1 from intranet2.dbo.in2 as in2 inner join intranet.dbo.depcode as d ON in2.pl1no=d.dp1no where year(in2.bk1date)=@ac3yy and month(in2.bk1date)=@bmm and in2.pl1no not in (select pl1no from df1 ) and d.dp1lun=@dp1lun group by in2.pl1no,d.DP1NAME

update intra3.dbo.ac3t4 set in1mon=d.bk1cah from intra3.dbo.ac3t4 inner join #tmp3 as d ON intra3.dbo.ac3t4.pl1no=d.pl1no
update intra3.dbo.ac3t4 set in1mon=d.bk1cah from intra3.dbo.ac3t4 inner join #tmp1 as d ON intra3.dbo.ac3t4.pl1no=d.pl1no

insert into intra3.dbo.ac3t4 (nowno,pl1no,pl1name,in1mon,ad1mon) select @nowno,pl1no,pl1name,bk1cah,0 from #tmp3 where pl1no not in (select pl1no from intra3.dbo.ac3t where nowno=@nowno)
insert into intra3.dbo.ac3t4 (nowno,pl1no,pl1name,in1mon,ad1mon) select @nowno,pl1no,pl1name,bk1cah,0 from #tmp1 where pl1no not in (select pl1no from intra3.dbo.ac3t where nowno=@nowno)

--只抓有補貼的店
--delete from intra3.dbo.ac3t4 where pl1no not in (select pl1no from df1)

drop table #tmp3
drop table #tmp1
END
go

