-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[pe1_B0811] (@nowno char(9),@bcode char(4),@byy char(4),@ch1 char(1) ,@ch2 char(1))
AS
BEGIN
	SET NOCOUNT ON;

   delete from intra3.dbo.pe1_B0811 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
if @ch2<>'Y'
	insert into intra3.dbo.pe1_B0811 (nowno,dep,usrno,usrname,po2no) select @nowno,dep,usrno,usrname,po2no from usr where pf1lef is null and usrno<>'TY' and dep=@bcode order by usr.dep,usr.usrno
else
	insert into intra3.dbo.pe1_B0811(nowno,dep,usrno,usrname,po2no) select @nowno,dep,usrno,usrname,po2no from usr,depcode where usr.dep=depcode.dp1no  and usr.usrno<>'TY' and usr.pf1lef is null and usr.pf1lun<>'Y' and depcode.dp1lun<>'T' order by usr.dep,usr.usrno
if @ch1='Y'
begin
update intra3.dbo.pe1_B0811 set pm1=(select sm1mon from sm2 where pl1no=@bcode and pe1no=usrno and LEFT(sm1month,4)=@byy and RIGHT(sm1month,2)='01') where nowno=@nowno
update intra3.dbo.pe1_B0811 set pm2=(select sm1mon from sm2 where pl1no=@bcode and pe1no=usrno and LEFT(sm1month,4)=@byy and RIGHT(sm1month,2)='02') where nowno=@nowno
update intra3.dbo.pe1_B0811 set pm3=(select sm1mon from sm2 where pl1no=@bcode and pe1no=usrno and LEFT(sm1month,4)=@byy and RIGHT(sm1month,2)='03') where nowno=@nowno
update intra3.dbo.pe1_B0811 set pm4=(select sm1mon from sm2 where pl1no=@bcode and pe1no=usrno and LEFT(sm1month,4)=@byy and RIGHT(sm1month,2)='04') where nowno=@nowno
update intra3.dbo.pe1_B0811 set pm5=(select sm1mon from sm2 where pl1no=@bcode and pe1no=usrno and LEFT(sm1month,4)=@byy and RIGHT(sm1month,2)='05') where nowno=@nowno
update intra3.dbo.pe1_B0811 set pm6=(select sm1mon from sm2 where pl1no=@bcode and pe1no=usrno and LEFT(sm1month,4)=@byy and RIGHT(sm1month,2)='06') where nowno=@nowno
update intra3.dbo.pe1_B0811 set pm7=(select sm1mon from sm2 where pl1no=@bcode and pe1no=usrno and LEFT(sm1month,4)=@byy and RIGHT(sm1month,2)='07') where nowno=@nowno
update intra3.dbo.pe1_B0811 set pm8=(select sm1mon from sm2 where pl1no=@bcode and pe1no=usrno and LEFT(sm1month,4)=@byy and RIGHT(sm1month,2)='08') where nowno=@nowno
update intra3.dbo.pe1_B0811 set pm9=(select sm1mon from sm2 where pl1no=@bcode and pe1no=usrno and LEFT(sm1month,4)=@byy and RIGHT(sm1month,2)='09') where nowno=@nowno
update intra3.dbo.pe1_B0811 set pm10=(select sm1mon from sm2 where pl1no=@bcode and pe1no=usrno and LEFT(sm1month,4)=@byy and RIGHT(sm1month,2)='10') where nowno=@nowno
update intra3.dbo.pe1_B0811 set pm11=(select sm1mon from sm2 where pl1no=@bcode and pe1no=usrno and LEFT(sm1month,4)=@byy and RIGHT(sm1month,2)='11') where nowno=@nowno
update intra3.dbo.pe1_B0811 set pm12=(select sm1mon from sm2 where pl1no=@bcode and pe1no=usrno and LEFT(sm1month,4)=@byy and RIGHT(sm1month,2)='12') where nowno=@nowno
end
else
begin
update intra3.dbo.pe1_B0811 set pm1=(select sm1a+sm1b+sm1c+sm1d+sm1e+sm1f+sm1g+sm1h+sm1i+sm1j-sm1o from sm2 where pl1no=@bcode and sm2.pe1no=usrno and LEFT(sm1month,4)=@byy and RIGHT(sm1month,2)='01') where nowno=@nowno
update intra3.dbo.pe1_B0811 set pm2=(select sm1a+sm1b+sm1c+sm1d+sm1e+sm1f+sm1g+sm1h+sm1i+sm1j-sm1o from sm2 where pl1no=@bcode and sm2.pe1no=usrno and LEFT(sm1month,4)=@byy and RIGHT(sm1month,2)='02') where nowno=@nowno
update intra3.dbo.pe1_B0811 set pm3=(select sm1a+sm1b+sm1c+sm1d+sm1e+sm1f+sm1g+sm1h+sm1i+sm1j-sm1o from sm2 where pl1no=@bcode and sm2.pe1no=usrno and LEFT(sm1month,4)=@byy and RIGHT(sm1month,2)='03') where nowno=@nowno
update intra3.dbo.pe1_B0811 set pm4=(select sm1a+sm1b+sm1c+sm1d+sm1e+sm1f+sm1g+sm1h+sm1i+sm1j-sm1o from sm2 where pl1no=@bcode and sm2.pe1no=usrno and LEFT(sm1month,4)=@byy and RIGHT(sm1month,2)='04') where nowno=@nowno
update intra3.dbo.pe1_B0811 set pm5=(select sm1a+sm1b+sm1c+sm1d+sm1e+sm1f+sm1g+sm1h+sm1i+sm1j-sm1o from sm2 where pl1no=@bcode and sm2.pe1no=usrno and LEFT(sm1month,4)=@byy and RIGHT(sm1month,2)='05') where nowno=@nowno
update intra3.dbo.pe1_B0811 set pm6=(select sm1a+sm1b+sm1c+sm1d+sm1e+sm1f+sm1g+sm1h+sm1i+sm1j-sm1o from sm2 where pl1no=@bcode and sm2.pe1no=usrno and LEFT(sm1month,4)=@byy and RIGHT(sm1month,2)='06') where nowno=@nowno
update intra3.dbo.pe1_B0811 set pm7=(select sm1a+sm1b+sm1c+sm1d+sm1e+sm1f+sm1g+sm1h+sm1i+sm1j-sm1o from sm2 where pl1no=@bcode and sm2.pe1no=usrno and LEFT(sm1month,4)=@byy and RIGHT(sm1month,2)='07') where nowno=@nowno
update intra3.dbo.pe1_B0811 set pm8=(select sm1a+sm1b+sm1c+sm1d+sm1e+sm1f+sm1g+sm1h+sm1i+sm1j-sm1o from sm2 where pl1no=@bcode and sm2.pe1no=usrno and LEFT(sm1month,4)=@byy and RIGHT(sm1month,2)='08') where nowno=@nowno
update intra3.dbo.pe1_B0811 set pm9=(select sm1a+sm1b+sm1c+sm1d+sm1e+sm1f+sm1g+sm1h+sm1i+sm1j-sm1o from sm2 where pl1no=@bcode and sm2.pe1no=usrno and LEFT(sm1month,4)=@byy and RIGHT(sm1month,2)='09') where nowno=@nowno
update intra3.dbo.pe1_B0811 set pm10=(select sm1a+sm1b+sm1c+sm1d+sm1e+sm1f+sm1g+sm1h+sm1i+sm1j-sm1o from sm2 where pl1no=@bcode and sm2.pe1no=usrno and LEFT(sm1month,4)=@byy and RIGHT(sm1month,2)='10') where nowno=@nowno
update intra3.dbo.pe1_B0811 set pm11=(select sm1a+sm1b+sm1c+sm1d+sm1e+sm1f+sm1g+sm1h+sm1i+sm1j-sm1o from sm2 where pl1no=@bcode and sm2.pe1no=usrno and LEFT(sm1month,4)=@byy and RIGHT(sm1month,2)='11') where nowno=@nowno
update intra3.dbo.pe1_B0811 set pm12=(select sm1a+sm1b+sm1c+sm1d+sm1e+sm1f+sm1g+sm1h+sm1i+sm1j-sm1o from sm2 where pl1no=@bcode and sm2.pe1no=usrno and LEFT(sm1month,4)=@byy and RIGHT(sm1month,2)='12') where nowno=@nowno
end
update intra3.dbo.pe1_B0811 set pm1=0	where pm1 is null
update intra3.dbo.pe1_B0811 set pm2=0	where pm2 is null
update intra3.dbo.pe1_B0811 set pm3=0	where pm3 is null
update intra3.dbo.pe1_B0811 set pm4=0	where pm4 is null
update intra3.dbo.pe1_B0811 set pm5=0	where pm5 is null
update intra3.dbo.pe1_B0811 set pm6=0	where pm6 is null
update intra3.dbo.pe1_B0811 set pm7=0	where pm7 is null
update intra3.dbo.pe1_B0811 set pm8=0	where pm8 is null
update intra3.dbo.pe1_B0811 set pm9=0	where pm9 is null
update intra3.dbo.pe1_B0811 set pm10=0	where pm10 is null
update intra3.dbo.pe1_B0811 set pm11=0	where pm11 is null
update intra3.dbo.pe1_B0811 set pm12=0	where pm12 is null
END
go

