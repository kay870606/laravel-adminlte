-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[in1_A0311] (@nowno char(9),@bb1no char(6),@dp1lun char(1),@bym char(4))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    declare @n1 int,@n2 int,@yy char(4)

	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
delete from intra3.dbo.bb1ch where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)

if @dp1lun='A'
insert into intra3.dbo.bb1ch (nowno,pl1no,bb1no,bb1name,bb1eng,bb1r1,bb1r2) select @nowno,pl1no,bb1no,(select bb1name from intranet.dbo.bb1 where bb1no=@bb1no) as name,(select bb1eng from intranet.dbo.bb1 where bb1no=@bb1no) as eng,0,0 from intranet2.dbo.be1 where bh1ym=@bym and pl1no in (select DP1NO from intranet.dbo.depcode where bb1no=@bb1no) group by pl1no,bb1no order by pl1no
else
insert into intra3.dbo.bb1ch (nowno,pl1no,bb1no,bb1name,bb1eng,bb1r1,bb1r2) select @nowno,pl1no,bb1no,(select bb1name from intranet.dbo.bb1 where bb1no=@bb1no) as name,(select bb1eng from intranet.dbo.bb1 where bb1no=@bb1no) as eng,0,0 from intranet2.dbo.be1 where bh1ym=@bym and pl1no in (select DP1NO from intranet.dbo.depcode where dp1lun=@dp1lun and bb1no=@bb1no) group by pl1no,bb1no order by pl1no
--update intra3.dbo.bb1ch set pl1no=(select pl1no from intranet2.dbo.be1 where bb1no=bb1no) where nowno=@nowno
create table #tmp (byy char(4),bmm char(2),mon decimal(10, 0))
--insert into #tmp (byy,bmm,mon) select @byy,month(bk1date) as mm,sum() as mon from intranet2.dbo.be1
drop table #tmp

END
go

