-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
--create PROCEDURE [dbo].[sn5rep2] (@nowno char(9),@bdate datetime,@edate datetime,@bcode char(8),@ecode char(8),@pg char(1),@su1bcode char(8))
CREATE PROCEDURE [dbo].[sn5rep2] (@nowno char(9),@bdate datetime,@edate datetime,@bcode char(8),@ecode char(8),@pg char(1),@su1bcode char(8))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	delete from intra3.dbo.sn5rep2 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
	--insert into intra3.dbo.sn5rep2(nowno,cu1no,cu1name2,pt1no,pt1name,pt1qty,pt1price,pt1mon) select @nowno,cu1no,cu1name2,pt1no,pt1name,pt1qty,pt1price,pt1mon from v_sa1 where sa1date between @bdate and @edate


	if(@pg='1')--依交易資料
	begin
		if(@su1bcode='')--沒輸入廠商代號 就全印
		begin
			insert into intra3.dbo.sn5rep2(nowno,sn5no,sn5date,su1no,su1tl,pt1no,pt1name,pt1qty,pt1price,sx1no,su1uno,sn5mon) select @nowno,sn5no,sn5date,su1no,su1tl,sn1no,(select pt1name from kdstock5.dbo.pt1 where kdstock5.dbo.pt1.pt1no=v_sn5.sn1no),pt1qty,pt1price,sx1no,su1uno,(round(pt1price*pt1qty,0)) from v_sn5 where sn5date between @bdate and @edate
		end
		else--有輸入廠商代號
		begin
			insert into intra3.dbo.sn5rep2(nowno,sn5no,sn5date,su1no,su1tl,pt1no,pt1name,pt1qty,pt1price,sx1no,su1uno,sn5mon) select @nowno,sn5no,sn5date,su1no,su1tl,sn1no,(select pt1name from kdstock5.dbo.pt1 where kdstock5.dbo.pt1.pt1no=v_sn5.sn1no),pt1qty,pt1price,sx1no,su1uno,(round(pt1price*pt1qty,0)) from v_sn5 where sn5date between @bdate and @edate and su1no=@su1bcode
		end
	end

	else--pg2 依發票號碼
	begin
		if(@bcode='' and @ecode='')--如果沒有輸入 就全印
		begin
			insert into intra3.dbo.sn5rep2(nowno,sn5no,sn5date,su1no,su1tl,pt1no,pt1name,pt1qty,pt1price,sx1no,su1uno,sn5mon) select @nowno,sn5no,sn5date,su1no,su1tl,sn1no,(select pt1name from kdstock5.dbo.pt1 where kdstock5.dbo.pt1.pt1no=v_sn5.sn1no),pt1qty,pt1price,sx1no,su1uno,(round(pt1price*pt1qty,0)) from v_sn5 
		end
		else
		begin
			insert into intra3.dbo.sn5rep2(nowno,sn5no,sn5date,su1no,su1tl,pt1no,pt1name,pt1qty,pt1price,sx1no,su1uno,sn5mon) select @nowno,sn5no,sn5date,su1no,su1tl,sn1no,(select pt1name from kdstock5.dbo.pt1 where kdstock5.dbo.pt1.pt1no=v_sn5.sn1no),pt1qty,pt1price,sx1no,su1uno,(round(pt1price*pt1qty,0)) from v_sn5 where sx1no between @bcode and @ecode
		end
	end


	select * from intra3.dbo.sn5rep2 where nowno=@nowno --order by sn5date

END



go

