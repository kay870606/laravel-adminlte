-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[getad1g4] (@nowno char(9),@pl1no char(4),@ac3yy char(4),@dp1lun char(1))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	declare @ac1tyy char(4),@ac1cyy char(4),@ac1pyy char(4)
	declare @run1 varchar(300),@run2 varchar(250),@run varchar(650),@accok char(1)
	
	--set @pl1no='KG2'
	--select @accok=accok from intranet.dbo.depcode where dp1no=@pl1no
	select @ac1tyy=ac1tyy,@ac1cyy=ac1cyy,@ac1pyy=ac1pyy from intranet.dbo.ac1yy
	if @dp1lun='T'
	begin
	if @ac3yy<=@ac1tyy
		set @run1='SELECT MONTH(ad1.ad1date) AS mm,ad2.ac2no+ad2.ac2no2 as ac2no1, ad2.ac2no, ad2.ac2no2, SUM(ad2.ad1dmon) AS ad1dmon, SUM(ad2.ad1cmon) AS ad1cmon FROM  ad1'+@ac3yy+' as ad1 INNER JOIN ad2'+@ac3yy+' as ad2 ON ad1.ad1no = ad2.ad1no '
	else
		set @run1='SELECT MONTH(ad1.ad1date) AS mm,ad1.pl1no,ad2.ac2no+ad2.ac2no2 as ac2no1, ad2.ac2no, ad2.ac2no2, ad2.ad1dmon, ad2.ad1cmon FROM ad1 INNER JOIN ad2 ON ad1.ad1no = ad2.ad1no '
	
--	set @run2=' WHERE ad1.pl1no in (select pl1no from intra3.dbo.dp1ch where nowno='''+@nowno+''') AND (ad2.pl1no in (select pl1no from intra3.dbo.dp1ch where nowno='''+@nowno+''')) AND (YEAR(ad1.ad1date) = '+@ac3yy+') AND (ad2.ad1yy = '+@ac3yy+')'
	set @run2=' WHERE ad1.pl1no='''+@pl1no+''' AND ad2.pl1no='''+@pl1no+''' AND (YEAR(ad1.ad1date) = '+@ac3yy+') AND (ad2.ad1yy = '+@ac3yy+')'
	set @run=@run1+@run2
		exec (@run)
		--print @run
	end
	if @dp1lun='C'
	begin
	if @ac3yy<=@ac1cyy
		set @run1='SELECT MONTH(ad1.ad1date) AS mm,ad2.ac2no+ad2.ac2no2 as ac2no1, ad2.ac2no, ad2.ac2no2, SUM(ad2.ad1dmon) AS ad1dmon, SUM(ad2.ad1cmon) AS ad1cmon FROM  intranet2.dbo.ad1o'+@ac3yy+' as ad1 INNER JOIN intranet2.dbo.ad2o'+@ac3yy+' as ad2 ON ad1.ad1no = ad2.ad1no '
	else
		set @run1='SELECT MONTH(ad1.ad1date) AS mm,ad1.pl1no,ad2.ac2no+ad2.ac2no2 as ac2no1, ad2.ac2no, ad2.ac2no2, ad2.ad1dmon, ad2.ad1cmon FROM intranet2.dbo.ad1c as ad1 INNER JOIN intranet2.dbo.ad2c as ad2 ON ad1.ad1no = ad2.ad1no '
	
--	set @run2=' WHERE ad1.pl1no in (select pl1no from intra3.dbo.dp1ch where nowno='''+@nowno+''') AND (ad2.pl1no in (select pl1no from intra3.dbo.dp1ch where nowno='''+@nowno+''')) AND (YEAR(ad1.ad1date) = '+@ac3yy+') AND (ad2.ad1yy = '+@ac3yy+')'
	set @run2=' WHERE ad1.pl1no='''+@pl1no+''' AND ad2.pl1no='''+@pl1no+''' AND (YEAR(ad1.ad1date) = '+@ac3yy+') AND (ad2.ad1yy = '+@ac3yy+')'
	set @run=@run1+@run2
		exec (@run)
		--print @run
	end
	if @dp1lun='P'
	begin
	if @ac3yy<=@ac1pyy
		set @run1='SELECT MONTH(a1.ad1date) AS mm,a2.ac2no+ad2.ac2no2 as ac2no1, ad2.ac2no, ad2.ac2no2, SUM(ad2.ad1dmon) AS ad1dmon, SUM(ad2.ad1cmon) AS ad1cmon FROM  intranet2.dbo.ad1o'+@ac3yy+' as ad1 INNER JOIN intranet2.dbo.ad2o'+@ac3yy+' as ad2 ON ad1.ad1no = ad2.ad1no '
	else
		set @run1='SELECT MONTH(ad1.ad1date) AS mm,ad1.pl1no,ad2.ac2no+ad2.ac2no2 as ac2no1, ad2.ac2no, ad2.ac2no2, ad2.ad1dmon, ad2.ad1cmon FROM intranet2.dbo.ad1o as ad1 INNER JOIN intranet2.dbo.ad2o as ad2 ON ad1.ad1no = ad2.ad1no '
	
--	set @run2=' WHERE ad1.pl1no in (select pl1no from intra3.dbo.dp1ch where nowno='''+@nowno+''') AND (ad2.pl1no in (select pl1no from intra3.dbo.dp1ch where nowno='''+@nowno+''')) AND (YEAR(ad1.ad1date) = '+@ac3yy+') AND (ad2.ad1yy = '+@ac3yy+')'
	set @run2=' WHERE ad1.pl1no='''+@pl1no+''' AND ad2.pl1no='''+@pl1no+''' AND (YEAR(ad1.ad1date) = '+@ac3yy+') AND (ad2.ad1yy = '+@ac3yy+')'
	set @run=@run1+@run2
		exec (@run)
		--print @run
	end

END
go

