-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[in1q_C9004] (@byy char(4),@bmm char(2),@dp1lun char(1))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end

create table #tmp (in1date datetime,in1pi decimal(8, 3))
insert into #tmp (in1date,in1pi) select in1date,in1pi from in1q where year(in1date)=@byy and month(in1date)=@bmm and dp1lun=@dp1lun order by in1date
select sum(in1pi) as in1pi,sum(1) as n from #tmp 
--select * from #tmp order by in1date
drop table #tmp
END
go

