-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[getpo2fu33] (@pe1no char(5),@po2no char(3),@po2no2 char(3))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp
	end
	if (select object_id('tempdb..#tmp2'))is not null
	begin
		drop table #tmp2
	end
	select po2fu3.fu1no,fu3.fu1name,fu3.fu1name_c,fu3.fu1name_e,fu3.fu1name_a,fu3.fu1type,fu3.fu1sort into #tmp from po2fu3,fu3 where po2fu3.fu1no=fu3.fu1no and (po2fu3.po2no=@po2no or po2fu3.po2no=@po2no2) and fu3.fu1type='P' order by fu3.fu1sort,fu3.fu1no
	select rg5.fu1no,fu3.fu1name,fu3.fu1name_c,fu3.fu1name_e,fu3.fu1name_a,fu3.fu1type,fu3.fu1sort into #tmp2 from rg5,fu3 where rg5.fu1no=fu3.fu1no and rg5.pe1no=@pe1no and fu3.fu1type='P' order by fu3.fu1sort,rg5.fu1no
	insert into tempdb.#tmp (fu1no,fu1name,fu1name_c,fu1name_e,fu1name_a,fu1type,fu1sort) select fu1no,fu1name,fu1name_c,fu1name_e,fu1name_a,fu1type,fu1sort from tempdb.#tmp2
	select DISTINCT * from tempdb.#tmp as t order by t.fu1no
	drop table #tmp2
	drop table #tmp
END
go

