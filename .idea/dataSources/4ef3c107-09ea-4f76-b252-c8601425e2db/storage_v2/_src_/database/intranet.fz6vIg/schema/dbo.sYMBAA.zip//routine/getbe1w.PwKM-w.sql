-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[getbe1w] (@nowno char(9),@pl1no char(4),@bh1lst char(8))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	delete from intra3.dbo.be1w where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
	insert into intra3.dbo.be1w (nowno,pl1no,bh1lst,bb1no,bb1id2,bb1name,bb1eng,be1bdate,be1edate,be1price,be1memo,be1qty,be1qty2,bh1date,be1mac,be1omon,be1occ,bb1mon,su1name1,be1date,us1no,bd2number,bd2hnum,bd2pi,bd2type) select @nowno,@pl1no,@bh1lst,bb1no,bb1id2,(select bb1name from bb1 where bb1no=be1w.bb1no) as bb1name,(select bb1eng from bb1 where bb1no=be1w.bb1no) as bb1eng,be1bdate,be1edate,be1price,be1memo,be1qty,be1qty2,bh1date,be1mac,be1omon,be1occ,bb1mon,su1name1,be1date,us1no,bd2number,bd2hnum,bd2pi,bd2type from be1w where be1w.pl1no=@pl1no and be1w.bh1lst=@bh1lst
    select * from intra3.dbo.be1w where nowno=@nowno and bh1lst=@bh1lst and pl1no=@pl1no order by bb1no,bb1id2
END
go

