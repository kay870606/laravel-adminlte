CREATE VIEW dbo.v_ap1
AS
SELECT          dbo.ap1.ap1num, dbo.ap1.pl1no, dbo.ap1.ap1ym, dbo.su1.ecomp, dbo.ap1.ap1giv, dbo.ap1.ap1mac, dbo.ap1.ap1oth, 
                            dbo.ap1.ap1oth2, dbo.ap1.ap1no, dbo.ap1.ap1not, dbo.ap1.su1mon, dbo.depcode.DP1NAME, 
                            dbo.su1.su1mon AS Expr1, dbo.su1.su1name, dbo.su1.su1addr, dbo.su1.su1tl, dbo.ap1.su1no, dbo.ap1.ap1yn, 
                            dbo.depcode.dp1lun2, dbo.su1.su1lock
FROM              dbo.ap1 INNER JOIN
                            dbo.su1 ON dbo.ap1.su1no = dbo.su1.su1no INNER JOIN
                            dbo.depcode ON dbo.ap1.pl1no = dbo.depcode.DP1NO
go

