-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	取一個員工所負責的全部現場
-- =============================================
CREATE PROCEDURE [dbo].[getdp1ch] (@nowno char(9),@pe1no char(5),@fu1no char(5))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
delete from intra3.dbo.dp1ch where pl1idate<CONVERT(nvarchar(30), GETDATE(), 111)
create table #tmp (pl1no char(4),lu1no char(2),lu1sort char(2),dp1over1 char(1))
insert into #tmp (pl1no,lu1no,dp1over1) select dp1no,dp1lun2,dp1over from depcode where dp1lun2 in (select lu1no from rg5lu1 where pe1no=@pe1no)
insert into #tmp (pl1no) select pl1no from rg6 where pe1no=@pe1no and fu1no=@fu1no
insert into #tmp (pl1no) select pl1no from rg5pl1 where pe1no=@pe1no
delete from #tmp where pl1no in (select pl1no from rg5pl1d where pe1no=@pe1no)
update #tmp set lu1no=(select dp1lun2 from depcode where dp1no=pl1no) where lu1no is null
update #tmp set lu1sort=(select lu1sort from lu1 where lu1no=#tmp.lu1no)
DELETE FROM intra3.dbo.dp1ch where nowno=@nowno
insert into intra3.dbo.dp1ch (nowno,pl1no,dp1lun2,lu1sort,dp1over) select DISTINCT @nowno,pl1no,lu1no,lu1sort,dp1over1 from #tmp order by lu1sort,lu1no,pl1no
drop table #tmp;

END
go

