-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[pe1_B0511_3] (@nowno char(9),@byy char(4),@bmm char(2),@bmm2 char(2),@pl1no char(4),@pe1no char(5))	
AS
BEGIN

	SET NOCOUNT ON;
	delete from intra3.dbo.pe1_B0511_3 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
	if @pe1no <>''
	begin
	insert into intra3.dbo.pe1_B0511_3 (nowno,pe1no,pe1name,pf1ari) select @nowno,usrno,usrname,pf1ari from usr where usrno=@pe1no and pf1lef is null and (dep=@pl1no or dp1no=@pl1no)
	end
	else
	begin
	insert into intra3.dbo.pe1_B0511_3 (nowno,pe1no,pe1name,pf1ari) select @nowno,usrno,usrname,pf1ari from usr where usrno in(select pe1no from ph1 where pl1no=@pl1no  and sm1month between @byy+@bmm and @byy+@bmm2) and pf1lef is null and (dep=@pl1no or dp1no=@pl1no)
	end

	update intra3.dbo.pe1_B0511_3 set intra3.dbo.pe1_B0511_3 .ph1D=t2.ph1hr,intra3.dbo.pe1_B0511_3 .ph1D2=t2.count2
		from  (SELECT SUM(ph1hrs) AS ph1hr, count(*) as count2,pe1no from ph1 where hl1no='D' and sm1month between @byy+@bmm and @byy+@bmm2 and pl1no=@pl1no  GROUP BY pe1no)  as t2
		where t2.pe1no  = intra3.dbo.pe1_B0511_3.pe1no  and intra3.dbo.pe1_B0511_3.nowno=@nowno 
	update intra3.dbo.pe1_B0511_3 set intra3.dbo.pe1_B0511_3 .ph1B=t2.ph1hr,intra3.dbo.pe1_B0511_3 .ph1B2=t2.count2
		from  (SELECT SUM(ph1hrs) AS ph1hr, count(*) as count2,pe1no from ph1 where hl1no='B' and sm1month between @byy+@bmm and @byy+@bmm2 and pl1no=@pl1no  GROUP BY pe1no)  as t2
		where t2.pe1no  = intra3.dbo.pe1_B0511_3.pe1no  and intra3.dbo.pe1_B0511_3.nowno=@nowno 
	update intra3.dbo.pe1_B0511_3 set intra3.dbo.pe1_B0511_3 .ph1C=t2.ph1hr,intra3.dbo.pe1_B0511_3 .ph1C2=t2.count2
		from  (SELECT SUM(ph1hrs) AS ph1hr, count(*) as count2,pe1no from ph1 where hl1no='C' and sm1month between @byy+@bmm and @byy+@bmm2 and pl1no=@pl1no  GROUP BY pe1no)  as t2
		where t2.pe1no  = intra3.dbo.pe1_B0511_3.pe1no  and intra3.dbo.pe1_B0511_3.nowno=@nowno     

	update intra3.dbo.pe1_B0511_3 set intra3.dbo.pe1_B0511_3 .ph1I=t2.count2
		from  (SELECT count(*) as count2,pe1no from ph1 where hl1no='I' and sm1month between @byy+@bmm and @byy+@bmm2 and pl1no=@pl1no  GROUP BY pe1no)  as t2
		where t2.pe1no  = intra3.dbo.pe1_B0511_3.pe1no  and intra3.dbo.pe1_B0511_3.nowno=@nowno     
	update intra3.dbo.pe1_B0511_3 set intra3.dbo.pe1_B0511_3 .ph1G=t2.count2
		from  (SELECT count(*) as count2,pe1no from ph1 where hl1no='G' and sm1month between @byy+@bmm and @byy+@bmm2 and pl1no=@pl1no  GROUP BY pe1no)  as t2
		where t2.pe1no  = intra3.dbo.pe1_B0511_3.pe1no  and intra3.dbo.pe1_B0511_3.nowno=@nowno     
	update intra3.dbo.pe1_B0511_3 set intra3.dbo.pe1_B0511_3.ph1H=t2.count2
		from  (SELECT count(*) as count2,pe1no from ph1 where hl1no='H' and sm1month between @byy+@bmm and @byy+@bmm2 and pl1no=@pl1no  GROUP BY pe1no)  as t2
		where t2.pe1no  = intra3.dbo.pe1_B0511_3.pe1no  and intra3.dbo.pe1_B0511_3.nowno=@nowno     
	update intra3.dbo.pe1_B0511_3 set intra3.dbo.pe1_B0511_3.ph1R=t2.count2
		from  (SELECT count(*) as count2,pe1no from ph1 where hl1no='R' and sm1month between @byy+@bmm and @byy+@bmm2 and pl1no=@pl1no  GROUP BY pe1no)  as t2
		where t2.pe1no  = intra3.dbo.pe1_B0511_3.pe1no  and intra3.dbo.pe1_B0511_3.nowno=@nowno     
	update intra3.dbo.pe1_B0511_3 set ph1G=ph1G+ph1R where nowno=@nowno     
END
go

