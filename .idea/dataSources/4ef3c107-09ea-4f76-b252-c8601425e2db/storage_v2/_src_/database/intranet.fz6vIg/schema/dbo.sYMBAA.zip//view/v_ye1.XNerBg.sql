CREATE VIEW dbo.v_ye1
AS
SELECT          pe1no, SUM(ye1nn) AS ye1nn
FROM              dbo.ye1
GROUP BY   pe1no
go

