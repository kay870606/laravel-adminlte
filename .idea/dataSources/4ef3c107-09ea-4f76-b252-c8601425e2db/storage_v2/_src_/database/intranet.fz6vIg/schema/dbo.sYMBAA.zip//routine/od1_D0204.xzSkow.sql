-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[od1_D0204] (@nowno char(9))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

delete from intra3.dbo.od1_D0204 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
--delete from intra3.dbo.od1_D0204_2 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
insert into intra3.dbo.od1_D0204 (nowno,od1no,od1date,pl1no,pl1name) select @nowno,od1no,left(od1date,16),pl1no,(select DP1NAME from intranet.dbo.depcode where DP1NO=uorder.pl1no) from intranet.dbo.uorder group by od1no,left(od1date,16),pl1no order by od1no
--insert into intra3.dbo.od1_D0204_2 (nowno,od1no,od1date,pt1no,pt1name,pt1qty) select @nowno,od1no,left(od1date,16),pt1no,pt1name,pt1qty from intranet.dbo.uorder
END
go

