CREATE VIEW dbo.v_gl3
AS
SELECT          dbo.gl3.pl1no, dbo.gl3.gl3month, dbo.gl3.gl3mon, dbo.gl3.gl3mon2, dbo.gl3.gl3type, dbo.gl3.gl3pi, dbo.gl3.gl3lock, 
                            dbo.depcode.DP1NAME, dbo.depcode.dp1yn, dbo.depcode.dp1over, dbo.depcode.dp1lun, dbo.depcode.dp1yn2, 
                            dbo.depcode.dp1lun2, dbo.depcode.dp1lun3, dbo.gl3.gl3t3040
FROM              dbo.gl3 INNER JOIN
                            dbo.depcode ON dbo.gl3.pl1no = dbo.depcode.DP1NO
go

