-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[bb1_C8001] (@nowno char(9),@dp1lun char(1),@byy char(4),@byy2 char(4),@bmm char(2),@t3040 char(50),@dp1type char(1))
	-- Add the parameters for the stored procedure here
AS
BEGIN
	SET NOCOUNT ON;
	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
	if (select object_id('tempdb..#tmp2'))is not null
	begin
		drop table #tmp2;
	end
	
	delete from intra3.dbo.bb1C8001 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111);
	CREATE TABLE #tmp (pl1no char(4),byy char(4),gl4mon2 decimal(12, 0) );  --原幣
	CREATE TABLE #tmp2 (pl1no char(4),byy char(4),smon decimal(12, 0));
	
	declare @run varchar(450);
	set @run ='insert into #tmp (byy,pl1no,gl4mon2) select left(gl3month,4)as yy,pl1no,sum(gl4mon2) as gl4mon2 from gl4 where pl1no in (select dp1no from depcode where dp1lun='''+@dp1lun+''') and left(gl3month,4) in ('''+@byy2+''','''+@byy+''') and right(gl3month,2) between ''01'' and '''+@bmm+''' and gl3t3040 in ('+@t3040+') and pl1no in(select dp1no from depcode where dp1lun='''+@dp1lun+'''';
	if (@dp1type='1')  	
	begin  --不含衛星點	
	 set @run= @run+' and dp1yn2<>''Y'') group by gl3t3040,pl1no,left(gl3month,4)';	  
	 --insert into #tmp (byy,pl1no,gl4mon2) select left(gl3month,4)as yy,pl1no,sum(gl4mon2) as gl4mon2 from gl4 where pl1no in (select dp1no from depcode where dp1lun='C') and left(gl3month,4) in (@byy,@byy2) and right(gl3month,2) between '01' and @bmm and gl3t3040 in (@t3040) and pl1no in(select dp1no from depcode where dp1lun=@dp1lun and dp1yn2<>'Y') group by pl1no,gl3t3040,left(gl3month,4) order by yy,pl1no  --3040
	 insert into #tmp2 (byy,pl1no,smon) select year(bk1date)as yy,pl1no,sum(bk1cah+bk1oth2+bk1opn+bk1mon2+bk1mon3) as smon from intranet2.dbo.in2 where year(bk1date) in (@byy,@byy2) and month(bk1date) between '01' and @bmm and pl1no in (select dp1no from depcode where dp1lun=@dp1lun and  dp1yn2<>'Y') group by pl1no,year(bk1date)  --營收
	end
	else
	 begin
	  set @run= @run+') group by gl3t3040,pl1no,left(gl3month,4)';	  
	 --insert into #tmp (byy,pl1no,gl4mon2) select left(gl3month,4)as yy,pl1no,sum(gl4mon2) as gl4mon2 from gl4 where pl1no in (select dp1no from depcode where dp1lun=@dp1lun) and left(gl3month,4) in (@byy,@byy2) and right(gl3month,2) between '01' and @bmm and gl3t3040 in (@t3040) and pl1no in(select dp1no from depcode where dp1lun=@dp1lun) group by pl1no,gl3t3040,left(gl3month,4) order by yy,pl1no  --3040
	 insert into #tmp2 (byy,pl1no,smon) select year(bk1date)as yy,pl1no,sum(bk1cah+bk1oth2+bk1opn+bk1mon2+bk1mon3) as smon from intranet2.dbo.in2 where year(bk1date) in (@byy,@byy2) and month(bk1date) between '01' and @bmm and pl1no in (select dp1no from depcode where dp1lun=@dp1lun) group by pl1no,year(bk1date)  --營收
	end

	exec (@run)

	insert into intra3.dbo.bb1C8001 (nowno,pl1no) select @nowno,pl1no from #tmp group by pl1no ;
	insert into intra3.dbo.bb1C8001 (nowno,pl1no) select @nowno,pl1no from #tmp2 where  NOT EXISTS (SELECT pl1no FROM  #tmp WHERE pl1no=#tmp2.pl1no)  group by pl1no ;

	--UPDATE intra3.dbo.bb1C8001 SET in1mon =(select smon from #tmp2 where byy=@byy2 and pl1no=intra3.dbo.bb1C8001.pl1no)  WHERE nowno = @nowno;
	--UPDATE intra3.dbo.bb1C8001 SET in1mon2 =(select smon from #tmp2 where byy=@byy and pl1no=intra3.dbo.bb1C8001.pl1no)  WHERE nowno = @nowno;
	--UPDATE intra3.dbo.bb1C8001 SET gl4mon =(select gl4mon2 from #tmp where byy=@byy2 and pl1no=intra3.dbo.bb1C8001.pl1no)  WHERE nowno = @nowno;
	--UPDATE intra3.dbo.bb1C8001 SET gl4mon2 =(select gl4mon2 from #tmp where byy=@byy and pl1no=intra3.dbo.bb1C8001.pl1no)  WHERE nowno = @nowno;
    
	UPDATE t1 SET t1.in1mon = t2.smon FROM intra3.dbo.bb1C8001 AS t1 INNER JOIN #tmp2 AS t2 ON t1.pl1no = t2.pl1no WHERE t1.nowno = @nowno and t2.byy=@byy2;
	UPDATE t1 SET t1.in1mon2 = t2.smon FROM intra3.dbo.bb1C8001 AS t1 INNER JOIN #tmp2 AS t2 ON t1.pl1no = t2.pl1no WHERE t1.nowno = @nowno and t2.byy=@byy;
	UPDATE t1 SET t1.gl4mon = t2.gl4mon2 FROM intra3.dbo.bb1C8001 AS t1 INNER JOIN #tmp AS t2 ON t1.pl1no = t2.pl1no WHERE t1.nowno = @nowno and t2.byy=@byy2;
	UPDATE t1 SET t1.gl4mon2 = t2.gl4mon2 FROM intra3.dbo.bb1C8001 AS t1 INNER JOIN #tmp AS t2 ON t1.pl1no = t2.pl1no WHERE t1.nowno = @nowno and t2.byy=@byy;

	UPDATE t1 SET t1.pl1name = t2.dp1name,t1.dp1yn2 = t2.dp1yn2,t1.dp1over = t2.dp1over,t1.lu1no=t2.dp1lun2 FROM intra3.dbo.bb1C8001 AS t1 left JOIN intranet.dbo.depcode AS t2 ON t1.pl1no = t2.dp1no WHERE t1.nowno = @nowno;
	UPDATE t1 SET t1.lu1dno = t2.lu2no  FROM intra3.dbo.bb1C8001 AS t1 INNER JOIN intranet.dbo.lu1 AS t2 ON t1.lu1no = t2.lu1no WHERE t1.nowno = @nowno;
	UPDATE intra3.dbo.bb1C8001 SET lu1dname=(select lu2name from intranet.dbo.lu2 where lu2no=intra3.dbo.bb1C8001.lu1dno);
	drop table #tmp;
	drop table #tmp2;
	select * from intra3.dbo.bb1C8001 where nowno=@nowno order by lu1dno,lu1no,pl1no;
END
go

