-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[bb1_C9301] (@nowno char(9),@bcode char(5),@ecode char(5),@bpos char(1))

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	delete from intra3.dbo.bb1C9301 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
--insert into intra3.dbo.bb1C9301 (nowno,ge1no,ge1name,pl1no,pl1name,gl1pi,gl1memo,dp1lun2) select @nowno,ge1no,(select ge1name from ge1 where ge1no=gl1.ge1no) AS ge1name ,pl1no,(select dp1name from depcode where dp1no=gl1.pl1no) AS pl1name,gl1pi,gl1memo,(select dp1lun2 from depcode where dp1no=gl1.pl1no) AS dp1lun2 from gl1 where ge1no BETWEEN @bcode and @ecode
	if @bpos='1'
		insert into intra3.dbo.bb1C9301 (nowno,ge1no,ge1name,pl1no,pl1name,gl1pi,gl1memo,dp1lun2,dp1lun,gl1omon,gl1omon2) select @nowno,ge1no,(select ge1name from ge1 where ge1no=gl1.ge1no) AS ge1name ,pl1no,(select dp1name from depcode where dp1no=gl1.pl1no) AS pl1name,gl1pi,gl1memo,(select dp1lun2 from depcode where dp1no=gl1.pl1no) AS dp1lun2,(select dp1lun from depcode where dp1no=gl1.pl1no) AS dp1lun,gl1omon,gl1omon2 from gl1 where ge1no BETWEEN @bcode and @ecode
	else
		insert into intra3.dbo.bb1C9301 (nowno,ge1no,ge1name,pl1no,pl1name,gl1pi,gl1memo,dp1lun2,dp1lun,gl1omon,gl1omon2) select @nowno,ge1no,(select ge1name from ge1 where ge1no=intra3.dbo.ge1ch.ge1no)as ge1name,pl1no,(select dp1name from depcode where pl1no=dp1no)as pl1name,(gl1pi1+gl1pi4+gl1pia+gl1pi2+gl1pi3+gl1pi5+gl1pi6+gl1pi7+gl1pi8)as gl1pi,(select gl1memo from gl1 where ge1no=intra3.dbo.ge1ch.ge1no and pl1no=intra3.dbo.ge1ch.pl1no)as gl1memo,(select dp1lun2 from depcode where dp1no=pl1no)as dp1lun2,(select dp1lun from depcode where DP1NO=pl1no)as dp1lun,(select gl1omon from gl1 where ge1no=intra3.dbo.ge1ch.ge1no and pl1no=intra3.dbo.ge1ch.pl1no),(select gl1omon2 from gl1 where ge1no=intra3.dbo.ge1ch.ge1no and pl1no=intra3.dbo.ge1ch.pl1no) from intra3.dbo.ge1ch where ge1no between @bcode and @ecode order by pl1no
END
go

