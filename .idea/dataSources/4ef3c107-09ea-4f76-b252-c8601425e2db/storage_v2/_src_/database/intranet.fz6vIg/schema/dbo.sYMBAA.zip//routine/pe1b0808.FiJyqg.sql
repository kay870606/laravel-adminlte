-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[pe1b0808] (@nowno char(9),@bcode char(4),@ecode char(4),@aa char(1),@ee char(1),@dp1type char(1),@dp1ch char(1))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
delete from intra3.dbo.pe1b0808 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)

if @aa='Y'  --不印已結束現場
begin
	if @bcode <>'' and @ecode<>''
		insert into intra3.dbo.pe1b0808 (nowno,lu1.lu1name,d.dp1no,d.dp1name,d.pl1date,d.dp1date,d.dp1bn) select @nowno,lu1.lu1name,d.dp1no,d.dp1name,d.pl1date,d.dp1date,d.dp1bn from depcode as d inner join lu1  ON d.dp1lun2=lu1.lu1no where dp1no between @bcode and @ecode and d.dp1over<>'Y' order by dp1no
	else
		insert into intra3.dbo.pe1b0808 (nowno,lu1.lu1name,d.dp1no,d.dp1name,d.pl1date,d.dp1date,d.dp1bn) select @nowno,lu1.lu1name,d.dp1no,d.dp1name,d.pl1date,d.dp1date,d.dp1bn from depcode as d inner join lu1  ON d.dp1lun2=lu1.lu1no where d.dp1over<>'Y' order by dp1no
end
else
begin
	if @bcode <>'' and @ecode<>''
		insert into intra3.dbo.pe1b0808 (nowno,lu1.lu1name,d.dp1no,d.dp1name,d.pl1date,d.dp1date,d.dp1bn) select @nowno,lu1.lu1name,d.dp1no,d.dp1name,d.pl1date,d.dp1date,d.dp1bn from depcode as d inner join lu1  ON d.dp1lun2=lu1.lu1no where dp1no between @bcode and @ecode order by dp1no
	else
		insert into intra3.dbo.pe1b0808 (nowno,lu1.lu1name,d.dp1no,d.dp1name,d.pl1date,d.dp1date,d.dp1bn) select @nowno,lu1.lu1name,d.dp1no,d.dp1name,d.pl1date,d.dp1date,d.dp1bn from depcode as d inner join lu1  ON d.dp1lun2=lu1.lu1no order by dp1no
end

/*if @ee='Y'  --印出開店日期
insert into intra3.dbo.pe1b0808 (nowno,lu1.lu1name,d.dp1no,d.dp1name,d.pl1date,d.dp1date,d.dp1bn) select @nowno,lu1.lu1name,d.dp1no,d.dp1name,d.pl1date,d.dp1date,d.dp1bn from depcode as d inner join lu1  ON d.dp1lun2=lu1.lu1no where dp1no between @bcode and @ecode and d.dp1date<>'Y' order by dp1no
else
insert into intra3.dbo.pe1b0808 (nowno,lu1.lu1name,d.dp1no,d.dp1name,d.pl1date,d.dp1date,d.dp1bn) select @nowno,lu1.lu1name,d.dp1no,d.dp1name,d.pl1date,d.dp1date,d.dp1bn from depcode as d inner join lu1  ON d.dp1lun2=lu1.lu1no where dp1no between @bcode and @ecode order by dp1no
*/
if @dp1type='2'
begin
  delete from intra3.dbo.pe1b0808 where dp1no in (select dp1no from depcode where dp1yn2='Y')
end
if @dp1type='3'
begin
  delete from intra3.dbo.pe1b0808 where dp1no in (select dp1no from depcode where dp1yn<>'Y' OR dp1yn2<>'Y')
end
if @dp1ch='2'
delete from intra3.dbo.pe1b0808 where dp1no in (select dp1no from depcode where dp1lun='P') 
if @dp1ch='3'
delete from intra3.dbo.pe1b0808 where dp1no in (select dp1no from depcode where dp1lun='C')
if @dp1ch='4'
delete from intra3.dbo.pe1b0808 where dp1no in (select dp1no from depcode where dp1lun='P' OR dp1lun='C')
if @dp1ch='5'
delete from intra3.dbo.pe1b0808 where dp1no in (select dp1no from depcode where dp1lun='P' OR dp1lun='T')
if @dp1ch='6'
delete from intra3.dbo.pe1b0808 where dp1no in (select dp1no from depcode where dp1lun='C' OR dp1lun='T')
END
go

