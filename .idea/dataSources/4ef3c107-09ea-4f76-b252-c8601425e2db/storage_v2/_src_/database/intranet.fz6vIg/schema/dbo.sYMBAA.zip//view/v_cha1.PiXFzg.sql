CREATE VIEW dbo.v_cha1
AS
SELECT          dbo.cha1.pe1no, dbo.cha1.pe1no2, dbo.usr.usrname
FROM              dbo.cha1 INNER JOIN
                            dbo.usr ON dbo.cha1.pe1no2 = dbo.usr.usrno
go

