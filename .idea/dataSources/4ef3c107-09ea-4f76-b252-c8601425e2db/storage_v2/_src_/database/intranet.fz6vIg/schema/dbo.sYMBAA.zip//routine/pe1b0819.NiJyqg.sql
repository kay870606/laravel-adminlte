-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[pe1b0819] (@nowno char(9),@yy char(4),@mm char(2),@bcode char(4),@ecode char(4))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

delete from intra3.dbo.pe1_b0819 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
if @bcode='' and @ecode=''
begin
	insert into intra3.dbo.pe1_B0819 (nowno,pl1no,sm1a,sm1b,sm1c,sm1d,sm1e,sm1f,sm1j,sm1peo) select @nowno,pl1no,sum(sm1a) as sm1a,sum(sm1b) as sm1b,sum(sm1c) as sm1c,sum(sm1d) as sm1d,sum(sm1e) as sm1e,sum(sm1f) as sm1f,sum(sm1j) as sm1j,sum(1) as sm1peo from sm2 where left(sm1month,4)=@yy and right(sm1month,2)=@mm group by sm1month,pl1no
end
else
begin
	insert into intra3.dbo.pe1_B0819 (nowno,pl1no,sm1a,sm1b,sm1c,sm1d,sm1e,sm1f,sm1j,sm1peo) select @nowno,pl1no,sum(sm1a) as sm1a,sum(sm1b) as sm1b,sum(sm1c) as sm1c,sum(sm1d) as sm1d,sum(sm1e) as sm1e,sum(sm1f) as sm1f,sum(sm1j) as sm1j,sum(1) as sm1peo from sm2 where left(sm1month,4)=@yy and right(sm1month,2)=@mm and pe1no between @bcode and @ecode group by sm1month,pl1no
end
update intra3.dbo.pe1_b0819 set dp1lun2=(select dp1lun2 from depcode where dp1no=pl1no) where nowno=@nowno
select * from intra3.dbo.pe1_b0819 where nowno=@nowno order by dp1lun2,pl1no
END
go

