-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[be1_A0812] (@nowno char(9),@yymm1 char(4),@yymm2 char(4))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    declare @n int,@yy char(2)

	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
	if (select object_id('tempdb..#tmp2'))is not null
	begin
		drop table #tmp2;
	end
delete from intra3.dbo.be1_A0312 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
delete from intra3.dbo.be1_A0312_2 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)

select pl1no,bh1ym,bb1no,left(bb1no,1) as no2,sum(be1qty*be1price) as mon into #tmp from intranet2.dbo.be1 where bh1ym between @yymm1 and @yymm2 and pl1no in (select pl1no from intra3.dbo.dp1ch where nowno=@nowno) group by pl1no,bb1no,bh1ym order by pl1no,bh1ym
insert into intra3.dbo.be1_A0312 (nowno,pl1no,pl1name,bh1ym) select @nowno,pl1no,(select dp1name from depcode where dp1no=#tmp.pl1no) as pl1name,bh1ym from #tmp group by pl1no,bh1ym order by pl1no,pl1name,bh1ym
select pl1no as dp1no,bh1ym as bh1ym2,no2,sum(mon) as mon into #tmp2 from #tmp group by pl1no,bh1ym,no2 order by pl1no,bh1ym,no2
update intra3.dbo.be1_A0312 set lu1no=(select dp1lun2 from intranet.dbo.depcode where dp1no=pl1no) where nowno=@nowno

update intra3.dbo.be1_A0312 set m1=(select mon from #tmp2 where dp1no=pl1no and bh1ym2=bh1ym and no2='1')
update intra3.dbo.be1_A0312 set m2=(select mon from #tmp2 where dp1no=pl1no and bh1ym2=bh1ym and no2='2')
update intra3.dbo.be1_A0312 set m3=(select mon from #tmp2 where dp1no=pl1no and bh1ym2=bh1ym and no2='3')
update intra3.dbo.be1_A0312 set m4=(select mon from #tmp2 where dp1no=pl1no and bh1ym2=bh1ym and no2='4')
update intra3.dbo.be1_A0312 set m5=(select mon from #tmp2 where dp1no=pl1no and bh1ym2=bh1ym and no2='5')
update intra3.dbo.be1_A0312 set m6=(select mon from #tmp2 where dp1no=pl1no and bh1ym2=bh1ym and no2='6')
update intra3.dbo.be1_A0312 set m7=(select mon from #tmp2 where dp1no=pl1no and bh1ym2=bh1ym and no2='7')
update intra3.dbo.be1_A0312 set m11=(select mon from #tmp2 where dp1no=pl1no and bh1ym2=bh1ym and no2='0')
update intra3.dbo.be1_A0312 set m77=(select mon from #tmp2 where dp1no=pl1no and bh1ym2=bh1ym and no2='8')
update intra3.dbo.be1_A0312 set m99=(select mon from #tmp2 where dp1no=pl1no and bh1ym2=bh1ym and no2='9')

--insert into intra3.dbo.be1_A0312 (nowno,lu1no,pl1no,pl1name) select @nowno,dp1lun2,dp1no,dp1name from intranet2.dbo.depcode where DP1NO in (select pl1no from intranet2.dbo.be1 where bh1ym>=@yymm1 and bh1ym<=@yymm2)
--create table #tmp3 (pl1no char(4),bh1ym char(4),bb1no char(6),mon decimal(15, 0))
--insert into #tmp3 (pl1no,bb1no,mon) select pl1no,bb1no,sum(be1qty*be1price) from intranet2.dbo.be1 where bh1ym>=@yymm1 and bh1ym<=@yymm2 group by pl1no,bb1no
update intra3.dbo.be1_A0312 set m1=0 where m1 is null
update intra3.dbo.be1_A0312 set m2=0 where m2 is null
update intra3.dbo.be1_A0312 set m3=0 where m3 is null
update intra3.dbo.be1_A0312 set m4=0 where m4 is null
update intra3.dbo.be1_A0312 set m5=0 where m5 is null
update intra3.dbo.be1_A0312 set m6=0 where m6 is null
update intra3.dbo.be1_A0312 set m7=0 where m7 is null
update intra3.dbo.be1_A0312 set m11=0 where m11 is null
update intra3.dbo.be1_A0312 set m77=0 where m77 is null
update intra3.dbo.be1_A0312 set m99=0 where m99 is null
-----------------------------------------------------------------不分月份
insert into intra3.dbo.be1_A0312_2 (nowno,lu1no,pl1no,pl1name,m1,m2,m3,m5,m6,m7,m4,m11,m77,m99) select @nowno,lu1no,pl1no,pl1name,sum(m1),sum(m2),sum(m3),sum(m5),sum(m6),sum(m7),sum(m4),sum(m11),sum(m77),sum(m99) from intra3.dbo.be1_A0312 group by nowno,lu1no,pl1no,pl1name
update intra3.dbo.be1_A0312_2 set m1=0 where m1 is null
update intra3.dbo.be1_A0312_2 set m2=0 where m2 is null
update intra3.dbo.be1_A0312_2 set m3=0 where m3 is null
update intra3.dbo.be1_A0312_2 set m4=0 where m4 is null
update intra3.dbo.be1_A0312_2 set m5=0 where m5 is null
update intra3.dbo.be1_A0312_2 set m6=0 where m6 is null
update intra3.dbo.be1_A0312_2 set m7=0 where m7 is null
update intra3.dbo.be1_A0312_2 set m11=0 where m11 is null
update intra3.dbo.be1_A0312_2 set m77=0 where m77 is null
update intra3.dbo.be1_A0312_2 set m99=0 where m99 is null
drop table #tmp
drop table #tmp2

END
go

