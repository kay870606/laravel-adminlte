-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[getbc3b] (@nowno char(9),@pl1no char(4),@bcode char(6),@ecode char(6),@bdate Datetime,@edate Datetime)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
	if (select object_id('tempdb..#tmp2'))is not null
	begin
		drop table #tmp2;
	end
	if (select object_id('tempdb..#tmp3'))is not null
	begin
		drop table #tmp3;
	end
	if (select object_id('tempdb..#tmp4'))is not null
	begin
		drop table #tmp4;
	end
	delete from intra3.dbo.bc3 where idate<CONVERT(nvarchar(30), GETDATE(), 111)
	delete from intra3.dbo.bc3 where nowno=@nowno
	if @bdate='' and @edate=''
	begin
		if @bcode='' and @ecode=''
		begin
			select bc3.*,bb1.bb1name,bb1.bb1eng into #tmp from bc3n as bc3,bb1 where bc3.bb1no=bb1.bb1no and bc3.pl1no=@pl1no and bc3.bc3flag='B'
			insert into intra3.dbo.bc3 (nowno,pl1no,bb1no,bb1id,bb1name,bb1eng,bc1ser,bc3date2,bc1name,bc3memo) select @nowno,@pl1no,bb1no,bb1id,bb1name,bb1eng,bc1ser,bc3date2,bc1name,bc3memo  from tempdb.#tmp
			drop table #tmp
		end
		else
		begin
			select bc3.*,bb1.bb1name,bb1.bb1eng into #tmp2 from bc3n as bc3,bb1 where bc3.bb1no=bb1.bb1no and bc3.pl1no=@pl1no and bc3.bb1no between @bcode and @ecode and bc3.bc3flag='B'
			insert into intra3.dbo.bc3 (nowno,pl1no,bb1no,bb1id,bb1name,bb1eng,bc1ser,bc3date2,bc1name,bc3memo) select @nowno,@pl1no,bb1no,bb1id,bb1name,bb1eng,bc1ser,bc3date2,bc1name,bc3memo  from tempdb.#tmp2
			drop table #tmp2
		end
	end
	else
	begin
		if @bcode='' and @ecode=''
		begin
			select bc3.*,bb1.bb1name,bb1.bb1eng into #tmp3 from bc3n as bc3,bb1 where bc3.bb1no=bb1.bb1no and bc3.pl1no=@pl1no and bc3.bc3flag='B' and bc3date2 between @bdate and @edate
			insert into intra3.dbo.bc3 (nowno,pl1no,bb1no,bb1id,bb1name,bb1eng,bc1ser,bc3date2,bc1name,bc3memo) select @nowno,@pl1no,bb1no,bb1id,bb1name,bb1eng,bc1ser,bc3date2,bc1name,bc3memo  from tempdb.#tmp3
			drop table #tmp3
		end
		else
		begin
			select bc3.*,bb1.bb1name,bb1.bb1eng into #tmp4 from bc3n as bc3,bb1 where bc3.bb1no=bb1.bb1no and bc3.pl1no=@pl1no and bc3.bb1no between @bcode and @ecode and bc3.bc3flag='B' and bc3date2 between @bdate and @edate
			insert into intra3.dbo.bc3 (nowno,pl1no,bb1no,bb1id,bb1name,bb1eng,bc1ser,bc3date2,bc1name,bc3memo) select @nowno,@pl1no,bb1no,bb1id,bb1name,bb1eng,bc1ser,bc3date2,bc1name,bc3memo  from tempdb.#tmp4
			drop table #tmp4
		end
	end
END
go

