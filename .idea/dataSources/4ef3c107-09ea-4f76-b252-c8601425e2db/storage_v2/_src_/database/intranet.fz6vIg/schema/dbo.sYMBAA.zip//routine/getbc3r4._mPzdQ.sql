-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[getbc3r4] (@nowno char(9),@pl1no varchar(10),@byy char(4),@bmm char(2))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	declare @in1month char(4),@cc nchar(10),@run varchar(450)
	
	if (select object_id('tempdb..#tmp2'))is not null
	begin
		drop table #tmp2;
	end
	select @in1month=in1month from sy3
	
	if @byy<=@in1month
	begin
		set @run='select MONTH(bk1date),(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) from intranet.dbo.in2'+@byy+' as in2 where pl1no='''+@pl1no+''' and YEAR(bk1date)='+@byy+' and MONTH(bk1date)='+@bmm
	end
	else
	begin
		set @run='select MONTH(bk1date),(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) from intranet2.dbo.in2 where pl1no='''+@pl1no+''' and YEAR(bk1date)='+@byy+' and MONTH(bk1date)='+@bmm
	end
	delete from intra3.dbo.bc3r51 where nowno=@nowno or in1idate<CONVERT(nvarchar(30), GETDATE(), 111)
	delete from intra3.dbo.bc3r52 where nowno=@nowno or in1idate<CONVERT(nvarchar(30), GETDATE(), 111)
	create table #tmp (in1month int,in1mon decimal(10,0))
	--create table #tmp2 (in1month int,in1mon decimal(10,0))
--	insert into #tmp (in1month,in1mon) select MONTH(bk1date),(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) from intranet2.dbo.in2 where pl1no=@pl1no and YEAR(bk1date)=@byy and MONTH(bk1date)<=@bmm
	insert into #tmp (in1month,in1mon) exec (@run)

	select in1month,SUM(in1mon) as in1mon into #tmp2 from #tmp group by in1month
	insert into intra3.dbo.bc3r51 (nowno,pl1no,in1month,in1mon) select @nowno,@pl1no,in1month,in1mon from tempdb.#tmp2
	drop table #tmp
	drop table #tmp2
	select * from intra3.dbo.bc3r51 where nowno=@nowno and pl1no=@pl1no order by in1month

END
go

