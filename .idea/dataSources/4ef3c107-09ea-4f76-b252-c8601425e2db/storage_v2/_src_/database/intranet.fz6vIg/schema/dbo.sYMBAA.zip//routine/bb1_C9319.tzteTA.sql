-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[bb1_C9319]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	delete from intra3.dbo.ge1ch2
	
	insert into intra3.dbo.ge1ch2 (ge1no,ge1name,po1no,po1name,po2no,po2name,dp1lun,pl1no,usrno) select ge1no,ge1name,(select post from usr where usrno=ge1no)as po1no,(select po1name from postcode where po1no in(select post from usr where usrno=ge1no) )as po1name,(select po2no from po2 where po2no in (select po2no from usr where usrno=ge1no))as po2no,(select po2name from po2 where po2no in (select po2no from usr where usrno=ge1no))as po2name,(select dp1lun from depcode where dp1no in (select dep from usr where usrno=ge1no))as dp1lun,(select dep from usr where usrno=ge1no)as pl1no,usrno from ge1
END
go

