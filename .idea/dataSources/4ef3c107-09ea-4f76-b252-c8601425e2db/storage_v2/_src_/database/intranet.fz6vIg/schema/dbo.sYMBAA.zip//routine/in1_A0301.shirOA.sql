-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[in1_A0117] (@byy char(4),@pl1no char(4))
AS
BEGIN
	declare @eyy char(4),@nyy char(4),@edate char(10)
set @eyy=CAST( (CAST(@byy as int)-1) as char(4)) /* 前一年度 */
set @nyy=SUBSTRING( CONVERT(char(10),getdate(),111),1,4) /*--今年度--*/
	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
	if (select object_id('tempdb..#tmp2'))is not null
	begin
		drop table #tmp2;
	end
if @byy=@nyy
begin
  set @edate=@byy+SUBSTRING( CONVERT(char(10),getdate(),111),5,4)+'01'
  --select @edate
  create table #tmp (yy char(4),mm char(2),mon decimal(12, 0))
  insert into #tmp (yy,mm,mon) select year(bk1date) as yy,SUBSTRING( CONVERT(char(10),bk1date,111),6,2) as mm,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon from intranet2.dbo.in2 where year(bk1date)=@byy and bk1date<@edate and pl1no=@pl1no group by year(bk1date),SUBSTRING( CONVERT(char(10),bk1date,111),6,2)
  insert into #tmp (yy,mm,mon) select year(bk1date) as yy,SUBSTRING( CONVERT(char(10),bk1date,111),6,2) as mm,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon from intranet2.dbo.in2 where year(bk1date)=@eyy and pl1no=@pl1no group by year(bk1date),SUBSTRING( CONVERT(char(10),bk1date,111),6,2)
  select #tmp.* from #tmp order by yy,mm
  drop table #tmp
end
else
begin
  create table #tmp2 (yy char(4),mm char(2),pl1no char(4),mon decimal(12, 0))
  insert into #tmp2 (yy,mm,mon) select year(bk1date) as yy,SUBSTRING( CONVERT(char(10),bk1date,111),6,2) as mm,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon from intranet2.dbo.in2 where year(bk1date)=@byy and pl1no=@pl1no group by year(bk1date),SUBSTRING( CONVERT(char(10),bk1date,111),6,2)
  insert into #tmp2 (yy,mm,mon) select year(bk1date) as yy,SUBSTRING( CONVERT(char(10),bk1date,111),6,2) as mm,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon from intranet2.dbo.in2 where year(bk1date)=@eyy and pl1no=@pl1no group by year(bk1date),SUBSTRING( CONVERT(char(10),bk1date,111),6,2)
  select * from #tmp2 order by yy,mm
  drop table #tmp2
end
END
go

