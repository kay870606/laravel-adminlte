-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[in1_A0119] (@byy char(4),@dp1lun2 char(2),@bdate1 char(10),@bdate2 char(10),@edate1 char(10),@edate2 char(10))
AS
BEGIN
	declare @eyy char(4),@nyy char(4),@edate char(10)

set @eyy=CAST( (CAST(@byy as int)-1) as char(4)) /* 前一年度 */
set @nyy=SUBSTRING( CONVERT(char(10),getdate(),111),1,4) /*--今年度--*/

	SET NOCOUNT ON;
	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
	if (select object_id('tempdb..#tmp2'))is not null
	begin
		drop table #tmp2;
	end
  --set @edate=@eyy+SUBSTRING( CONVERT(char(10),getdate(),111),5,4)+'01'
  --set @edate2=@byy+SUBSTRING( CONVERT(char(10),getdate(),111),5,4)+'01'
  create table #tmp (yy char(4),pl1no char(4),mon decimal(12, 0))
  insert into #tmp (yy,pl1no,mon) select year(bk1date),pl1no,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon from intranet2.dbo.in2 where year(bk1date)=@byy  and bk1date between @edate1 and @edate2 and pl1no in (select dp1no from depcode where dp1lun2=@dp1lun2) group by year(bk1date),pl1no
  --前一年度
  insert into #tmp (yy,pl1no,mon) select year(bk1date),pl1no,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon from intranet2.dbo.in2 where year(bk1date)=@eyy and bk1date between @bdate1 and @bdate2 and pl1no in (select dp1no from depcode where dp1lun2=@dp1lun2) group by year(bk1date),pl1no
  select #tmp.*,d.pl1date,d.dp1date,d.dp1no2 from #tmp,depcode as d where #tmp.pl1no=d.dp1no order by pl1no
--  select #tmp.*,'' as dp1no2,null as pl1date,null as dp1date  from #tmp order by pl1no
  drop table #tmp
--end
--else
--begin
--  create table #tmp2 (yy char(4),pl1no char(4),mon decimal(12, 0))
--  insert into #tmp2 (yy,pl1no,mon) select year(bk1date),pl1no,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon from intranet2.dbo.in2 where year(bk1date)=@byy and bk1date between @edate1 and @edate2 and pl1no in (select dp1no from intranet.dbo.depcode where dp1lun2=@dp1lun2) group by year(bk1date),pl1no
--  --前一年度
--  insert into #tmp2 (yy,pl1no,mon) select year(bk1date),pl1no,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon from intranet2.dbo.in2 where year(bk1date)=@eyy and bk1date between @bdate1 and @bdate2 and pl1no in (select dp1no from intranet.dbo.depcode where dp1lun2=@dp1lun2) group by year(bk1date),pl1no
--  select #tmp2.*,d.pl1date,d.dp1date,d.dp1no2 from #tmp2,depcode as d where #tmp2.pl1no=d.dp1no order by pl1no
--  drop table #tmp2
--end
END
go

