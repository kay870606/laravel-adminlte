-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[ap1_C7015] (@nowno char(9),@bcode char(4),@ecode char(4),@ap1ym char(5))

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

 delete from intra3.dbo.ap1_C7015 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
 if @bcode='' and @ecode=''
 begin 
    insert into intra3.dbo.ap1_C7015 (nowno,su1no,ecomp,su1mon,su1tl,su1name,su1addr) select DISTINCT @nowno,ap1.su1no,ap1.ecomp,su1.su1mon,su1.su1tl,su1.su1name,su1.su1addr from intranet.dbo.ap1,intranet.dbo.su1 where ap1.su1no=su1.su1no and ap1.ap1ym = @ap1ym
 end
 else
 begin
   insert into intra3.dbo.ap1_C7015 (nowno,su1no,ecomp,su1mon,su1tl,su1name,su1addr) select DISTINCT @nowno,ap1.su1no,ap1.ecomp,su1.su1mon,su1.su1tl,su1.su1name,su1.su1addr from intranet.dbo.ap1,intranet.dbo.su1 where ap1.su1no=su1.su1no and ap1.ap1ym = @ap1ym and ap1.su1no between @bcode and @ecode
 end
END
go

