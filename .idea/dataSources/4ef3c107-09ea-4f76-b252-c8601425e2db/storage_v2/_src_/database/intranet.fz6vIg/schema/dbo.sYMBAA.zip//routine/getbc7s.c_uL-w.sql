-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[getbc7s] (@nowno char(9),@pl1no varchar(10),@bcode varchar(11),@ecode varchar(11),@bdate datetime,@edate datetime,@bc5type char(1))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
	if (select object_id('tempdb..#tmp2'))is not null
	begin
		drop table #tmp2;
	end
	delete from intra3.dbo.bc7s where idate<CONVERT(nvarchar(30), GETDATE(), 111)
	delete from intra3.dbo.bc7s where nowno=@nowno
	if @bcode=''
	begin
	   insert into intra3.dbo.bc7s (nowno,pl1no,bc5type,bc5id,bc7date,bc7name,bc7price,bc7memo,bc7idate,pl1no2,bc7rdate,bc7rmemo,bc5name,bc6date,bc6price,bc4no,bc5sname1) select @nowno,pl1no,bc5type,bc5id,bc7date,bc7name,bc7price,bc7memo,bc7idate,pl1no2,bc7rdate,bc7rmemo, bc5name, bc6date ,bc6price,bc4no,bc5sname from intranet.dbo.v_bc7 where pl1no=@pl1no and bc5type=@bc5type
	end
	else
	begin
	   insert into intra3.dbo.bc7s (nowno,pl1no,bc5type,bc5id,bc7date,bc7name,bc7price,bc7memo,bc7idate,pl1no2,bc7rdate,bc7rmemo,bc5name,bc6date,bc6price,bc4no,bc5sname1) select @nowno,pl1no,bc5type,bc5id,bc7date,bc7name,bc7price,bc7memo,bc7idate,pl1no2,bc7rdate,bc7rmemo, bc5name, bc6date, bc6price,bc4no,bc5sname from intranet.dbo.v_bc7 where pl1no=@pl1no and bc4no between @bcode and @ecode and bc5type=@bc5type
	   --insert into intra3.dbo.bc7s (nowno,pl1no,bc5type,bc5id,bc7date,bc7name,bc7price,bc7memo,bc7idate,pl1no2,bc7rdate,bc7rmemo,bc5name,bc6date,bc6price) select @nowno,pl1no,bc5type,bc5id,bc7date,bc7name,bc7price,bc7memo,bc7idate,pl1no2,bc7rdate,bc7rmemo,(select bc5name from bc5 where bc5id=bc7.bc5id and bc5.pl1no=@pl1no) as bc5name,(select bc6date from bc5 where bc5id=bc7.bc5id and bc5.pl1no=@pl1no) as bc6date,(select bc6price from bc5 where bc5id=bc7.bc5id and bc5.pl1no=@pl1no) as bc6price from intranet.dbo.bc7 as bc7 where pl1no=@pl1no and bc5type=@bc5type
	end
--	update intra3.dbo.bc7s set bc4no=(select bc4no from bc5 where pl1no=bc7s.pl1no and bc5id=bc7s.bc5id)
	create table #tmp (dp1no char(4),bc4no char(2),bc5id2 char(11))
	create table #tmp2 (bc4no2 char(2),bc4name char(70))
	insert into #tmp (dp1no,bc4no,bc5id2) select pl1no,bc4no,bc5id from bc5 where pl1no=@pl1no
	insert into #tmp2 (bc4no2,bc4name) select bc4no,bc4name from bc4
	update intra3.dbo.bc7s set bc4no=#tmp.bc4no from #tmp join intra3.dbo.bc7s ON bc5id2 = bc5id
	update intra3.dbo.bc7s set bc4name=#tmp2.bc4name from #tmp2 join intra3.dbo.bc7s ON bc4no2=bc4no
	drop table #tmp
	drop table #tmp2
END
go

