-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[pt1_D0402] (@nowno char(9),@byyyy char(4),@byyy char(3),@byy char(2),@bmm char(2),@eyyyy char(4),@eyyy char(3),@eyy char(2),@emm char(2),@bpos char(1))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
	if (select object_id('tempdb..#tmp2'))is not null
	begin
		drop table #tmp2;
	end
	if (select object_id('tempdb..#tmp3'))is not null
	begin
		drop table #tmp3;
	end
	if (select object_id('tempdb..#tmp4'))is not null
	begin
		drop table #tmp4;
	end
	if (select object_id('tempdb..#tmpN'))is not null
	begin
		drop table #tmpN;
	end
	if (select object_id('tempdb..#tmp5'))is not null
	begin
		drop table #tmp5;
	end


	create table #tmp (pl1no2 char(4),giftno_2 char(8),gift_2 char(50),cost_2 decimal(8, 1))
	create table #tmp2 (pl1no3 char(4),giftno_3 char(8),msum_3 decimal(12, 0))
	create table #tmp3 (id int,pt2no char(1),pt2name char(24))
	create table #tmpN (giftno char(8),gift char(50))

	create table #tmp4 (pl1no char(4),giftno char(13),gift char(50),cost decimal(9, 2),msum decimal(12, 0),date char(6))

	insert into #tmp4 (pl1no,giftno,date,msum) select pl1no,giftno,CONVERT(char(6),date,112),SUM(usestorage) AS msum from intranet4.dbo.todayrep where pl1no in (select dp1no from depcode where dp1lun='T') and usestorage<>0 and date between @byyyy+@bmm+'01' and DATEADD(DAY,-1,DATEADD(month,1,@eyyyy+@emm+'01')) group by pl1no,giftno,date
	insert into #tmpN (giftno,gift) select giftno,gift from intranet4.dbo.stock where date between @byyyy+@bmm and @eyyyy+@emm group by giftno,gift
	update #tmp4 set gift=#tmpN.gift from #tmpN where #tmpN.giftno=#tmp4.giftno
	update #tmp4 set cost=(select cost from intranet4.dbo.stock where pl1no in (select dp1no from depcode where dp1lun='T') and date between @byyyy+@bmm and @eyyyy+@emm and giftno=#tmp4.giftno and date=#tmp4.date and pl1no=#tmp4.pl1no group by giftno,cost,date)
	delete from #tmp4 where cost is null or cost=0
	create table #tmp5 (pl1no char(4),giftno char(13),kindno char(1),beuse decimal(12, 0))
	
	insert into #tmp5 (giftno,kindno,beuse) select giftno,kindno,sum(beuse) from intranet4.dbo.mstock where date between @byyyy+@bmm and @eyyyy+@emm group by giftno,kindno

if @bpos='1' or @bpos='2'
	begin
		delete from intra3.dbo.pt1_D0402 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)		
		insert into intra3.dbo.pt1_D0402 (nowno,giftno,msum) select @nowno,giftno,SUM(msum) from #tmp4 group by giftno
		update intra3.dbo.pt1_D0402 set giftname=#tmp4.gift from #tmp4 where intra3.dbo.pt1_D0402.giftno=#tmp4.giftno and nowno=@nowno
		update intra3.dbo.pt1_D0402 set cost=(select AVG(#tmp4.cost) from #tmp4 where intra3.dbo.pt1_D0402.giftno=#tmp4.giftno and nowno=@nowno group by giftno)
		update intra3.dbo.pt1_D0402 set mon=round(msum*cost,0)

	update intra3.dbo.pt1_D0402 set spend1=spend1t
    from (select giftno ,sum(beuse) spend1t
      from intranet4.dbo.mstock as t where date=@byyyy+@bmm and kindno='B' group by giftno) Grouped 		
	where intra3.dbo.pt1_D0402.giftno = Grouped.giftno and nowno=@nowno
	update intra3.dbo.pt1_D0402 set spend=spendt
    from (select giftno ,sum(beuse) spendt
      from intranet4.dbo.mstock as t where date=@byyyy+@bmm and kindno<>'B' group by giftno) Grouped 		
	where intra3.dbo.pt1_D0402.giftno = Grouped.giftno and nowno=@nowno
	update intra3.dbo.pt1_D0402 set spend=0 where spend is null and nowno=@nowno
	update intra3.dbo.pt1_D0402 set spend1=0 where spend1 is null and nowno=@nowno
	update intra3.dbo.pt1_D0402 set mon=ROUND((msum+spend1+spend)*cost,0) where nowno=@nowno
	end
else if @bpos='3'
	begin
		delete from intra3.dbo.pt1_D0402 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)	
		insert into intra3.dbo.pt1_D0402 (nowno,giftno,msum) select @nowno,giftno,SUM(msum) from #tmp4 where left(#tmp4.gift,4)='TOMS' group by giftno
		update intra3.dbo.pt1_D0402 set giftname=#tmp4.gift from #tmp4 where intra3.dbo.pt1_D0402.giftno=#tmp4.giftno and nowno=@nowno
		update intra3.dbo.pt1_D0402 set cost=(select AVG(#tmp4.cost) from #tmp4 where intra3.dbo.pt1_D0402.giftno=#tmp4.giftno and left(#tmp4.gift,4)='TOMS' and nowno=@nowno group by giftno)
		update intra3.dbo.pt1_D0402 set mon=round(msum*cost,0)

			update intra3.dbo.pt1_D0402 set spend1=spend1t
    from (select giftno ,sum(beuse) spend1t
      from intranet4.dbo.mstock as t where date=@byyyy+@bmm and kindno='B' group by giftno) Grouped 		
	where intra3.dbo.pt1_D0402.giftno = Grouped.giftno and nowno=@nowno
	update intra3.dbo.pt1_D0402 set spend=spendt
    from (select giftno ,sum(beuse) spendt
      from intranet4.dbo.mstock as t where date=@byyyy+@bmm and kindno<>'B' group by giftno) Grouped 		
	where intra3.dbo.pt1_D0402.giftno = Grouped.giftno and nowno=@nowno
	update intra3.dbo.pt1_D0402 set spend=0 where spend is null and nowno=@nowno
	update intra3.dbo.pt1_D0402 set spend1=0 where spend1 is null and nowno=@nowno
	update intra3.dbo.pt1_D0402 set mon=ROUND((msum+spend1+spend)*cost,0) where nowno=@nowno
	end
else if @bpos='4'
	begin
		delete from intra3.dbo.pt1_D0402_4 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)	
		insert into intra3.dbo.pt1_D0402_4(nowno,pt2no,pt2name) select @nowno,pt2no,pt2name from pt2 where len(pt2no)=1 order by pt2no
		update intra3.dbo.pt1_D0402_4 set pt1qty=ISNULL((select sum(msum) from #tmp4 where SUBSTRING(giftno,3,1)=intra3.dbo.pt1_D0402_4.pt2no and nowno=@nowno group by SUBSTRING(giftno,3,1)),0)
		update intra3.dbo.pt1_D0402_4 set mtotal=ISNULL((select sum(msum) from #tmp4 ),0) where nowno=@nowno
		update intra3.dbo.pt1_D0402_4 set pt1pi=round(pt1qty/mtotal*100,2) where nowno=@nowno and mtotal<>0

	update intra3.dbo.pt1_D0402_4 set spend1=spend1t
    from (select SUBSTRING(giftno,3,1) as pt2no ,sum(beuse) spend1t
      from intranet4.dbo.mstock as t where date=@byyyy+@bmm and kindno='B' group by SUBSTRING(giftno,3,1)) Grouped 		
	where intra3.dbo.pt1_D0402_4.pt2no = Grouped.pt2no and nowno=@nowno
	update intra3.dbo.pt1_D0402_4 set spend=spendt
    from (select SUBSTRING(giftno,3,1) as pt2no ,sum(beuse) spendt
      from intranet4.dbo.mstock as t where date=@byyyy+@bmm and kindno<>'B' group by SUBSTRING(giftno,3,1)) Grouped 		
	where intra3.dbo.pt1_D0402_4.pt2no = Grouped.pt2no and nowno=@nowno
	update intra3.dbo.pt1_D0402_4 set spend=0 where spend is null and nowno=@nowno
	update intra3.dbo.pt1_D0402_4 set spend1=0 where spend1 is null and nowno=@nowno

	end
else if @bpos='5' --********
	begin
		delete from intra3.dbo.pt1_D0402_4 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)		
		insert into intra3.dbo.pt1_D0402_4(nowno,pt2no,pt2name) select @nowno,pt2no,pt2name from pt2 where len(pt2no)=1 order by pt2no		
		update intra3.dbo.pt1_D0402_4 set pt1qty=ISNULL((select sum(msum) from #tmp4 where SUBSTRING(giftno,3,1)=intra3.dbo.pt1_D0402_4.pt2no and nowno=@nowno group by SUBSTRING(giftno,3,1)),0)
		update intra3.dbo.pt1_D0402_4 set pt1sum=ISNULL((select sum(msum*cost) from #tmp4 where SUBSTRING(giftno,3,1)=intra3.dbo.pt1_D0402_4.pt2no and nowno=@nowno group by SUBSTRING(giftno,3,1)),0)
		update intra3.dbo.pt1_D0402_4 set mtotal=ISNULL((select sum(msum*cost) from #tmp4 ),0) where nowno=@nowno
		update intra3.dbo.pt1_D0402_4 set pt1pi=round(pt1sum/mtotal*100,2) where nowno=@nowno and mtotal<>0

	update intra3.dbo.pt1_D0402_4 set spend1=spend1t
    from (select SUBSTRING(giftno,3,1) as pt2no ,sum(beuse) spend1t
      from intranet4.dbo.mstock as t where date=@byyyy+@bmm and kindno='B' group by SUBSTRING(giftno,3,1)) Grouped 		
	where intra3.dbo.pt1_D0402_4.pt2no = Grouped.pt2no and nowno=@nowno
	update intra3.dbo.pt1_D0402_4 set spend=spendt
    from (select SUBSTRING(giftno,3,1) as pt2no ,sum(beuse) spendt
      from intranet4.dbo.mstock as t where date=@byyyy+@bmm and kindno<>'B' group by SUBSTRING(giftno,3,1)) Grouped 		
	where intra3.dbo.pt1_D0402_4.pt2no = Grouped.pt2no and nowno=@nowno
	update intra3.dbo.pt1_D0402_4 set spend=0 where spend is null and nowno=@nowno
	update intra3.dbo.pt1_D0402_4 set spend1=0 where spend1 is null and nowno=@nowno
	end
else if @bpos='6' or @bpos='7'
	begin
		delete from intra3.dbo.pt1_D0402_4 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
		declare @n int
		set @n=1
		while @n<=10
		begin
			insert into #tmp3 (pt2no,pt2name) select pt2no,pt2name from intranet.dbo.pt2 where len(pt2no)=1 order by pt2no
			set @n=@n+1
		end	
		insert into #tmp3 (id,pt2no,pt2name) select row_number()OVER(order by pt2no) AS no2,pt2no,pt2name from #tmp3 group by pt2no,pt2name order by pt2no
		insert into #tmp2 (pl1no3,giftno_3,msum_3) select pl1no,giftno, SUM(usestorage) AS msum from intranet4.dbo.todayrep where pl1no in (select dp1no from intranet2.dbo.depcode where dp1lun='T') and year(date)>=@byyyy and month(date)>=@bmm and year(date)>=@eyyyy and month(date)>=@emm group by pl1no,giftno
		insert into #tmp (pl1no2,giftno_2,gift_2,cost_2) select pl1no,giftno,gift,cost from intranet4.dbo.stock where pl1no in (select dp1no from intranet2.dbo.depcode where dp1lun='T') and date>=@byyyy+@bmm and date<=@eyyyy+@emm group by pl1no,giftno,gift,cost

		set @n=1
		while @n<=(select COUNT(pt2no) from #tmp3 where id is not null)
		begin
			if @bpos='6'
				insert into intra3.dbo.pt1_D0402_4(nowno,giftno,giftname,pt1qty,pt1sum) select top 10 @nowno,giftno_2,gift_2,sum(msum_3)as pt1qty,ROUND(sum(cost_2*msum_3),0)as pt1sum from #tmp join #tmp2 on pl1no2=pl1no3 and giftno_2= giftno_3 where SUBSTRING(giftno_2,3,1)=(select pt2no from #tmp3 where id is not null and id=@n) group by giftno_2,gift_2 order by SUBSTRING(giftno_2,3,1),pt1qty desc
			else if @bpos='7'
				insert into intra3.dbo.pt1_D0402_4(nowno,giftno,giftname,pt1qty,pt1sum) select top 10 @nowno,giftno_2,gift_2,sum(msum_3)as pt1qty,ROUND(sum(cost_2*msum_3),0)as pt1sum from #tmp join #tmp2 on pl1no2=pl1no3 and giftno_2= giftno_3 where SUBSTRING(giftno_2,3,1)=(select pt2no from #tmp3 where id is not null and id=@n) group by giftno_2,gift_2 order by SUBSTRING(giftno_2,3,1),pt1sum desc
			set @n=@n+1
		end

		update intra3.dbo.pt1_D0402_4 set pt2no=SUBSTRING(giftno,3,1) where nowno=@nowno


	update intra3.dbo.pt1_D0402_4 set spend1=spend1t
    from (select giftno ,sum(beuse) spend1t
      from intranet4.dbo.mstock as t where date=@byyyy+@bmm and kindno='B' group by giftno) Grouped 		
	where intra3.dbo.pt1_D0402_4.giftno = Grouped.giftno and nowno=@nowno
	update intra3.dbo.pt1_D0402_4 set spend=spendt
    from (select giftno ,sum(beuse) spendt
      from intranet4.dbo.mstock as t where date=@byyyy+@bmm and kindno<>'B' group by giftno) Grouped 		
	where intra3.dbo.pt1_D0402_4.giftno = Grouped.giftno and nowno=@nowno
	update intra3.dbo.pt1_D0402_4 set spend=0 where spend is null and nowno=@nowno
	update intra3.dbo.pt1_D0402_4 set spend1=0 where spend1 is null and nowno=@nowno

	end
--drop table #tmp6;

END
drop table #tmp;
drop table #tmp2;
drop table #tmp3;
drop table #tmp4;
drop table #tmpN;
drop table #tmp5;
go

