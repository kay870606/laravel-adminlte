CREATE VIEW dbo.v_usr1_4
AS
SELECT     dbo.depcode.DP1NAME, dbo.depcode.dp1lun, dbo.pw3.pw1a, dbo.pw3.pw1b, dbo.pw3.pw1c, dbo.pw3.pw1d, dbo.pw3.pw1e, dbo.pw3.pw1f, dbo.pw3.pw1g, dbo.pw3.pw1h, dbo.pw3.pw1i, 
                      dbo.pw3.pw1j, dbo.pw3.pw1k, dbo.pw3.pw1l, dbo.pw3.pw1m, dbo.pw3.pw1n, dbo.pw3.pw1o, dbo.pw3.pw1p, dbo.pw3.pw1q, dbo.pw3.pw1r, dbo.pw3.pw1s, dbo.pw3.pw1t, dbo.pw3.pw1u, 
                      dbo.pw3.pw1v, dbo.pw3.pw1w, dbo.pw3.pw1x, dbo.pw3.pw1y, dbo.pw3.pw1z, dbo.pw3.pw1memo, dbo.pw3.pw1dmon, dbo.pw3.pw1hmon, dbo.pw3.pl1no, dbo.pw3.pw1tdate, dbo.pw3.pw1test, 
                      dbo.pe1.usrno, dbo.pe1.pf1lef, dbo.pe1.pf1start, dbo.pe1.pf1chdate, dbo.pe1.pf1hr, dbo.pe1.pf1hr2, dbo.usr.usrname, dbo.usr.post, dbo.usr.dep, dbo.usr.po2no, dbo.usr.pf1id, dbo.usr.pf1sup, 
                      dbo.usr.pf1inm, dbo.usr.pf1ari, dbo.usr.pf1nno, dbo.usr.pf1type, dbo.usr.pf1all, dbo.usr.pf1otime, dbo.usr.pf1lun, dbo.usr.dp3name, dbo.usr.pf1leave, dbo.usr.pf1umon, dbo.usr.pf1umon2, 
                      dbo.usr.pe1lay
FROM         dbo.pe1 INNER JOIN
                      dbo.pw3 ON dbo.pe1.usrno = dbo.pw3.pe1no AND dbo.pe1.pl1no = dbo.pw3.pl1no INNER JOIN
                      dbo.depcode ON dbo.pe1.dep = dbo.depcode.DP1NO INNER JOIN
                      dbo.usr ON dbo.pe1.usrno = dbo.usr.usrno
go

