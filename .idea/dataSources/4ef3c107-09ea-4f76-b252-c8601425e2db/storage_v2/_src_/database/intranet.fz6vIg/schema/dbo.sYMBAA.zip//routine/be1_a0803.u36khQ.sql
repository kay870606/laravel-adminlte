-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[be1_a0803] (@pl1no char(4),@bh1ym2 char(6))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
declare @yy char(4),@mm char(2)
set @yy=left(@bh1ym2,4)
set @mm=RIGHT(@bh1ym2,2)
	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
create table #tmp (bb1idd char(11),bd1m1 char(4),bd1m2 char(4),bd1m3 char(4),bd1m4 char(4),bd1m5 char(4),bd1m6 char(4),bd1m7 char(4),bd1m8 char(4),bd1m9 char(4),bd1m10 char(4),bd1m11 char(4),bd1m12 char(4))
insert into #tmp (bb1idd,bd1m1,bd1m2,bd1m3,bd1m4,bd1m5,bd1m6,bd1m7,bd1m8,bd1m9,bd1m10,bd1m11,bd1m12) select bb1id,bd1m1,bd1m2,bd1m3,bd1m4,bd1m5,bd1m6,bd1m7,bd1m8,bd1m9,bd1m10,bd1m11,bd1m12 from intranet2.dbo.bd1 where pl1no=@pl1no and bb1yyyy=@yy
if @mm='01'
  update intranet2.dbo.be1 set bi1range=(select bd1m1 from #tmp where bb1idd=bb1id) where pl1no=@pl1no and bh1ym2=@bh1ym2 and be1bad <>'Y'
if @mm='02'
  update intranet2.dbo.be1 set bi1range=(select bd1m2  from #tmp where bb1idd=bb1id) where pl1no=@pl1no and bh1ym2=@bh1ym2 and be1bad <>'Y'
if @mm='03'
  update intranet2.dbo.be1 set bi1range=(select bd1m3  from #tmp where bb1idd=bb1id) where pl1no=@pl1no and bh1ym2=@bh1ym2 and be1bad <>'Y'
if @mm='04'
  update intranet2.dbo.be1 set bi1range=(select bd1m4  from #tmp where bb1idd=bb1id) where pl1no=@pl1no and bh1ym2=@bh1ym2 and be1bad <>'Y'
if @mm='05'
  update intranet2.dbo.be1 set bi1range=(select bd1m5  from #tmp where bb1idd=bb1id) where pl1no=@pl1no and bh1ym2=@bh1ym2 and be1bad <>'Y'
if @mm='06'
  update intranet2.dbo.be1 set bi1range=(select bd1m6  from #tmp where bb1idd=bb1id) where pl1no=@pl1no and bh1ym2=@bh1ym2 and be1bad <>'Y'
if @mm='07'
  update intranet2.dbo.be1 set bi1range=(select bd1m7  from #tmp where bb1idd=bb1id) where  pl1no=@pl1no and bh1ym2=@bh1ym2 and be1bad <>'Y'
if @mm='08'
  update intranet2.dbo.be1 set bi1range=(select bd1m8  from #tmp where bb1idd=bb1id) where  pl1no=@pl1no and bh1ym2=@bh1ym2 and be1bad <>'Y'
if @mm='09'
  update intranet2.dbo.be1 set bi1range=(select bd1m9  from #tmp where bb1idd=bb1id) where  pl1no=@pl1no and bh1ym2=@bh1ym2 and be1bad <>'Y'
if @mm='10'
  update intranet2.dbo.be1 set bi1range=(select bd1m10  from #tmp where bb1idd=bb1id) where pl1no=@pl1no and bh1ym2=@bh1ym2 and be1bad <>'Y'
if @mm='11'
  update intranet2.dbo.be1 set bi1range=(select bd1m11  from #tmp where bb1idd=bb1id) where pl1no=@pl1no and bh1ym2=@bh1ym2 and be1bad <>'Y'
if @mm='12'
  update intranet2.dbo.be1 set bi1range=(select bd1m12  from #tmp where bb1idd=bb1id) where pl1no=@pl1no and bh1ym2=@bh1ym2 and be1bad <>'Y'
  drop table #tmp
END
go

