-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[pe1_B0812_1] (@nowno char(9),@dp3name char(50),@edate datetime)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	delete from intra3.dbo.pe1_B0812_1
 insert into  intra3.dbo.pe1_B0812_1 (nowno,dep,pe1no,usrname,pf1id,pf1bth,pf1ari,pw1a,n1,pf1gnd,n2,pf1nno,mmon,pf1gover)
 select @nowno,dep,usrno,usrname,pf1id,pf1bth,pf1ari,0,0,pf1gnd,0,pf1nno,0,pf1gover from usr where dp3name=@dp3name AND pf1lef is NULL AND dep in (select dp1no from depcode where dp1over <> 'Y') order by dep,usrname
 update intra3.dbo.pe1_B0812_1 set pw1a=(select pw1a from pw1 where pw1.pe1no=pe1no) where dep='TOP'
--update intra3.dbo.pe1_B0812_1 set pw1a=(select pw1a from pw2 where pw2.pe1no=pe1_B0812_1.pe1no AND pw2.pl1no=dep) where dep<>'TOP'
update intra3.dbo.pe1_B0812_1 set pw1a=pw2.pw1a from intra3.dbo.pe1_B0812_1 inner join pw2 ON intra3.dbo.pe1_B0812_1.pe1no=pw2.pe1no where dep<>'TOP'
END
go

