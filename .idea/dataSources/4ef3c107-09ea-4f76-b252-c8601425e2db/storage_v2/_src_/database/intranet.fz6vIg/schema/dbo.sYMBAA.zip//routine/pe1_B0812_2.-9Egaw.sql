-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[pe1_B0812_2] (@nowno char(9),@pl1no char(4),@edate datetime)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	delete from intra3.dbo.pe1_B0812_2 where nowno=@nowno
	insert into intra3.dbo.pe1_B0812_2 (nowno,pl1no,dp3name,pe1no,usrname,pf1id,pf1bth,pf1ari,po1no,po1name,po2no,po2name,pw1a,n1,pf1gnd,n2,pf1nno,mmon,pf1gover)
	 select @nowno,dep,dp3name,usrno,usrname,pf1id,pf1bth,pf1ari,post,(select po1name from postcode where po1no=usr.post) as po1name,po2no,(select po2name from po2 where po2no=usr.po2no) as po2name,0,0,pf1gnd,0,pf1nno,0,pf1gover from usr where dep=@pl1no AND pf1lef is NULL AND dep in (select dp1no from depcode where dp1over <> 'Y')
	 update intra3.dbo.pe1_B0812_2 set pw1a=(select pw1a from pw1 where pe1no=pe1no) where pl1no='TOP'
	 --update intra3.dbo.pe1_B0812_2 set pw1a=(select pw1a from pw2 where pe1no=pe1no AND pl1no=pl1no) where pl1no<>'TOP'
	 update intra3.dbo.pe1_B0812_2 set pw1a=pw2.pw1a from intra3.dbo.pe1_B0812_2 inner join pw2 ON intra3.dbo.pe1_B0812_2.pe1no=pw2.pe1no where intra3.dbo.pe1_B0812_2.pl1no<>'TOP'
END
go

