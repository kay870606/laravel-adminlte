-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[be1_a0805] (@nowno char(9),@pl1no char(4),@yymm char(4))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	delete from intra3.dbo.be1_a0305 where nowno=@nowno
	insert into intra3.dbo.be1_A0305 (nowno,pl1no,bb1no,bb1name,be1price,bd1rel,bh1num,bi1range) select  @nowno,pl1no,bb1no,(select bb1name from bb1 where bb1no=intranet2.dbo.be1.bb1no) as bb1name,be1price,bh1mac,sum(be1qty) as bh1num,bi1range from intranet2.dbo.be1 where pl1no=@pl1no and left(bh1lst,4)=@yymm and be1bad<>'Y' group by pl1no,bb1no,be1price,bh1mac,bi1range
	update intra3.dbo.be1_A0305 set bh1mon=be1price*bh1num,bh1cal= (be1price*bh1num/bd1rel)/((cast(right(bi1range,2) as decimal)-cast(left(bi1range,2)as decimal)+1)) where nowno=@nowno and pl1no=@pl1no
END
go

