-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
--create PROCEDURE [dbo].[sn7rep1] (@nowno char(9),@pg char(1),@bdate datetime,@edate datetime,@byy char(4),@eyy char(4),@bmm char(2),@emm char(2),@bcode char(10),@ecode char(10),@bch char(1))
CREATE PROCEDURE [dbo].[sn7rep1] (@nowno char(9),@pg char(1),@bdate datetime,@edate datetime,@byy char(4),@eyy char(4),@bmm char(2),@emm char(2),@bcode char(10),@ecode char(10),@bch char(1))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	declare @sx1n int
	select @sx1n=count(*) from intra3.dbo.sx1sele where nowno=@nowno--發票號碼多選

	delete from intra3.dbo.sn7rep1 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
	


	if(@pg='1')--依交易日期
	begin
		--insert into intra3.dbo.sn7rep1(nowno,sn7date,cu1no,cu1tl,pt1no,pt1name,pt1qty,pt1price,sx1no,cu1uno,sn7mon) select @nowno,sn7date,cu1no,cu1tl,sn1no,(select pt1name from kdstock5.dbo.pt1 where kdstock5.dbo.pt1.pt1no=v_sn7.sn1no),pt1qty,pt1price,sx1no,cu1uno,(round(pt1price*pt1qty,0)) from v_sn7 where sn7date between @bdate and @edate
		insert into intra3.dbo.sn7rep1(sn7date,sn7no,cu1no,pt1no,sx1no) select sn7date,sn7no,cu1no,sn1no,sx1no from v_sn7 where sn7date between @bdate and @edate group by sn7date,cu1no,sn1no,sx1no,sn7no
	end

	else--pg2 依發票號碼
	begin
		if(@sx1n!='')--如果有勾選sx1sele
		begin
			insert into intra3.dbo.sn7rep1(sn7date,sn7no,cu1no,pt1no,sx1no) select sn7date,sn7no,cu1no,sn1no,sx1no from v_sn7 where sn7month between @byy+@bmm and @eyy+@emm and sx1no in (select sx1no from intra3.dbo.sx1sele where nowno=@nowno) group by sn7date,cu1no,sn1no,sx1no,sn7no
		end
		else--如果沒有勾選
		begin
			if(@bcode='' and @ecode='')--如果都沒有輸入 就全印
			begin
				insert into intra3.dbo.sn7rep1(sn7date,sn7no,cu1no,pt1no,sx1no) select sn7date,sn7no,cu1no,sn1no,sx1no from v_sn7 where sn7month between @byy+@bmm and @eyy+@emm group by sn7date,cu1no,sn1no,sx1no,sn7no
			end
			else--如果有輸入發票號碼
			begin
				insert into intra3.dbo.sn7rep1(sn7date,sn7no,cu1no,pt1no,sx1no) select sn7date,sn7no,cu1no,sn1no,sx1no from v_sn7 where sn7month between @byy+@bmm and @eyy+@emm and sx1no between @bcode and @ecode group by sn7date,cu1no,sn1no,sx1no,sn7no
			end
		end
	end


	update intra3.dbo.sn7rep1 set nowno=@nowno
	update intra3.dbo.sn7rep1 set cu1tl=sn7.cu1tl from sn7 join intra3.dbo.sn7rep1 on intra3.dbo.sn7rep1.cu1no=sn7.cu1no--抬頭
	update intra3.dbo.sn7rep1 set pt1name=sn1.sn1name from sn1 join intra3.dbo.sn7rep1 on intra3.dbo.sn7rep1.pt1no=sn1.sn1no--產品名稱
	update intra3.dbo.sn7rep1 set pt1qty=sn8.pt1qty from sn8 join intra3.dbo.sn7rep1 on intra3.dbo.sn7rep1.pt1no=sn8.sn1no and intra3.dbo.sn7rep1.sn7no=sn8.sn7no--數量
	update intra3.dbo.sn7rep1 set pt1price=sn8.pt1price from sn8 join intra3.dbo.sn7rep1 on intra3.dbo.sn7rep1.pt1no=sn8.sn1no--單價
	update intra3.dbo.sn7rep1 set cu1uno=sn7.cu1uno from sn7 join intra3.dbo.sn7rep1 on intra3.dbo.sn7rep1.cu1no=sn7.cu1no--統一編號
	update intra3.dbo.sn7rep1 set sn7mon=(round(pt1price*pt1qty,0))--金額小計
	update intra3.dbo.sn7rep1 set cu1name=a.cu1name1 from kdstock5.dbo.cu1 as a where a.cu1no=intra3.dbo.sn7rep1.cu1no and nowno=@nowno
	

	select * from intra3.dbo.sn7rep1 where nowno=@nowno --order by sn5date

END



go

