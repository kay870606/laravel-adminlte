-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
--ALTER PROCEDURE [dbo].[pt1_D0403] (@nowno char(9),@byy3 char(4),@byy4 char(4),@bpos char(1))
CREATE PROCEDURE [dbo].[pt1_D0403] (@nowno char(9),@byyyymm char(6),@eyyyymm char(6),@bpos char(1))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	if @bpos='1'
		delete from intra3.dbo.pt1_D0403 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
	else
		delete from intra3.dbo.pt1_D0403_2 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)

	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
	if (select object_id('tempdb..#tmp2'))is not null
	begin
		drop table #tmp2;
	end
	
	create table #tmp (pl1no2 char(4),giftno_2 char(8),gift_2 char(50),msum_2 decimal(12, 0),mm char(6))
	create table #tmp2 (pl1no3 char(4),giftno_3 char(8),cost_3 decimal(8, 1))

	insert into #tmp (pl1no2,mm,giftno_2,gift_2,msum_2) select pl1no,month(date)as mm,giftno, gift, SUM(usestorage) AS msum from intranet4.dbo.todayrep where pl1no in (select dp1no from depcode where dp1lun='T') and CONVERT(varchar(6),date,112) between @byyyymm and @eyyyymm and usestorage<>0 group by pl1no,date,giftno,gift order by pl1no,date,giftno
	insert into #tmp2(pl1no3,giftno_3,cost_3) select pl1no,giftno, cost from intranet4.dbo.stock where pl1no in (select dp1no from depcode where dp1lun='T') and CONVERT(varchar(6),date,112) between @byyyymm and @eyyyymm and cost<>0 group by pl1no,giftno,cost order by pl1no,giftno

	if @bpos='1'
		select mm,pl1no2,ROUND(sum(msum_2*cost_3),0)as mon from #tmp join #tmp2 on pl1no2=pl1no3 and giftno_2=giftno_3 group by mm,pl1no2 order by pl1no2,mm
	else
		select mm,pl1no2,ROUND(sum(msum_2*cost_3),0)as mon2 from #tmp join #tmp2 on pl1no2=pl1no3 and giftno_2=giftno_3 where left(gift_2,4)='TOMS' group by mm,pl1no2 order by pl1no2,mm
END



--USE [intranet]
--GO
--/****** Object:  StoredProcedure [dbo].[pt1_D0403]    Script Date: 11/06/2018 16:47:53 ******/
--SET ANSI_NULLS ON
--GO
--SET QUOTED_IDENTIFIER ON
--GO
---- =============================================
---- Author:		<Author,,Name>
---- Create date: <Create Date,,>
---- Description:	<Description,,>
---- =============================================
--ALTER PROCEDURE [dbo].[pt1_D0403] (@nowno char(9),@byy3 char(4),@byy4 char(4),@bpos char(1))
--AS
--BEGIN
--	-- SET NOCOUNT ON added to prevent extra result sets from
--	-- interfering with SELECT statements.
--	SET NOCOUNT ON;
--	if @bpos='1'
--		delete from intra3.dbo.pt1_D0403 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
--	else
--		delete from intra3.dbo.pt1_D0403_2 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)

--	if (select object_id('tempdb..#tmp'))is not null
--	begin
--		drop table #tmp;
--	end
--	if (select object_id('tempdb..#tmp2'))is not null
--	begin
--		drop table #tmp2;
--	end
	
--	create table #tmp (pl1no2 char(4),giftno_2 char(8),gift_2 char(50),msum_2 decimal(12, 0),mm char(6))
--	create table #tmp2 (pl1no3 char(4),giftno_3 char(8),cost_3 decimal(8, 1))

--	insert into #tmp (pl1no2,mm,giftno_2,gift_2,msum_2) select pl1no,SUBSTRING(date,3,2)as mm,giftno, gift, SUM(usestorage) AS msum from intranet2.dbo.todayrep where pl1no in (select dp1no from depcode where dp1lun='T') and left(date,4) between @byy3 and @byy4 and usestorage<>0 group by pl1no,date,giftno,gift order by pl1no,date,giftno
--	insert into #tmp2(pl1no3,giftno_3,cost_3) select pl1no,giftno, cost from intranet2.dbo.stock where pl1no in (select dp1no from depcode where dp1lun='T') and date between @byy3 and @byy4 and cost<>0 group by pl1no,giftno,cost order by pl1no,giftno

--	if @bpos='1'
--		select mm,pl1no2,ROUND(sum(msum_2*cost_3),0)as mon from #tmp join #tmp2 on pl1no2=pl1no3 and giftno_2=giftno_3 group by mm,pl1no2 order by pl1no2,mm
--	else
--		select mm,pl1no2,ROUND(sum(msum_2*cost_3),0)as mon2 from #tmp join #tmp2 on pl1no2=pl1no3 and giftno_2=giftno_3 where left(gift_2,4)='TOMS' group by mm,pl1no2 order by pl1no2,mm
--END
go

