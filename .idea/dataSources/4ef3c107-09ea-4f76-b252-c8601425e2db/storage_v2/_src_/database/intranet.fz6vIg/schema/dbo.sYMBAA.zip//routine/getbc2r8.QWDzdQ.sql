-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[getbc2r8] (@nowno char(9),@pl1no char(4),@bcode char(6),@ecode char(6),@flag char(1),@date1 datetime,@date2 datetime)
AS
BEGIN
	---bc2flag='4'放倉庫,'5'=報廢
	SET NOCOUNT ON;

	delete from intra3.dbo.bc2r8 where idate<CONVERT(nvarchar(30), GETDATE(), 111)
	delete from intra3.dbo.bc2r8 where nowno=@nowno and bc2flag=@flag

	if (@date1 is null and @date2 is null)
	begin

	  if @bcode='' and @ecode=''
	  begin
		insert into intra3.dbo.bc2r8 (nowno,pl1no,bb1no,bb1id,bz1date2,bz1name,bc3date2,bc1not,bc1ser,bc2flag,bb1name,bb1eng) select @nowno,bc2.pl1no,bc2.bb1no,bc2.bb1id,bc2.bz1date2,bc2.bz1name,bc2.bc3date2,bc2.bc1not,bc2.bc1ser,bc2.bc2flag,bb1.bb1name,bb1.bb1eng from bc2n as bc2,bb1 where bc2.bb1no=bb1.bb1no and bc2.pl1no=@pl1no and bc2.bc2flag=@flag and bc2.by1name='' order by bc2.bb1no
	  end
	  else
     	begin
		insert into intra3.dbo.bc2r8 (nowno,pl1no,bb1no,bb1id,bz1date2,bz1name,bc3date2,bc1not,bc1ser,bc2flag,bb1name,bb1eng) select @nowno,bc2.pl1no,bc2.bb1no,bc2.bb1id,bc2.bz1date2,bc2.bz1name,bc2.bc3date2,bc2.bc1not,bc2.bc1ser,bc2.bc2flag,bb1.bb1name,bb1.bb1eng from bc2n as bc2,bb1 where bc2.bb1no=bb1.bb1no and bc2.pl1no=@pl1no and bc2.bb1no between @bcode and @ecode and bc2.bc2flag=@flag and bc2.by1name='' order by bc2.bb1no 
	     end
	  end
	else  
	  begin
	
	    if @bcode='' and @ecode=''
	    begin
		   insert into intra3.dbo.bc2r8 (nowno,pl1no,bb1no,bb1id,bz1date2,bz1name,bc3date2,bc1not,bc1ser,bc2flag,bb1name,bb1eng) select @nowno,bc2.pl1no,bc2.bb1no,bc2.bb1id,bc2.bz1date2,bc2.bz1name,bc2.bc3date2,bc2.bc1not,bc2.bc1ser,bc2.bc2flag,bb1.bb1name,bb1.bb1eng from bc2n as bc2,bb1 where bc2.bb1no=bb1.bb1no and bc2.pl1no=@pl1no and bc2.bc2flag=@flag and bc2.by1name='' and bz1date2 between @date1 and @date2 order by bc2.bb1no
	    end
      	else
	      begin
		  insert into intra3.dbo.bc2r8 (nowno,pl1no,bb1no,bb1id,bz1date2,bz1name,bc3date2,bc1not,bc1ser,bc2flag,bb1name,bb1eng) select @nowno,bc2.pl1no,bc2.bb1no,bc2.bb1id,bc2.bz1date2,bc2.bz1name,bc2.bc3date2,bc2.bc1not,bc2.bc1ser,bc2.bc2flag,bb1.bb1name,bb1.bb1eng from bc2n as bc2,bb1 where bc2.bb1no=bb1.bb1no and bc2.pl1no=@pl1no and bc2.bb1no between @bcode and @ecode and bc2.bc2flag=@flag and bc2.by1name='' and bz1date2 between @date1 and @date2 order by bc2.bb1no
	      end
      end

END
go

