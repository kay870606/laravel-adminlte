-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[pe1b0809] (@nowno char(9),@yy char(4),@pe1no char(5),@dbf char(3))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
delete from intra3.dbo.pe1_b0809 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
if @dbf='SM1'
   insert into intra3.dbo.pe1_b0809 (nowno,pl1no,sm1month,pe1no,sm1a,sm1b,sm1c,sm1d,sm1e,sm1f,sm1g,sm1h,sm1i,sm1j,sm1k,sm1l,sm1m,sm1n,sm1o,sm1p,sm1q,sm1r,sm1s,sm1t,sm1u,sm1v,sm1w,sm1x,sm1y,sm1z) select @nowno,pl1no,sm1month,@pe1no,sm1a,sm1b,sm1c,sm1d,sm1e,sm1f,sm1g,sm1h,sm1i,sm1j,sm1k,sm1l,sm1m,sm1n,sm1o,sm1p,sm1q,sm1r,sm1s,sm1t,sm1u,sm1v,sm1w,sm1x,sm1y,sm1z from sm1 where left(sm1month,4)=@yy and pe1no=@pe1no
if @dbf='SM2'
   insert into intra3.dbo.pe1_b0809 (nowno,pl1no,sm1month,pe1no,sm1a,sm1b,sm1c,sm1d,sm1e,sm1f,sm1g,sm1h,sm1i,sm1j,sm1k,sm1l,sm1m,sm1n,sm1o,sm1p,sm1q,sm1r,sm1s,sm1t,sm1u,sm1v,sm1w,sm1x,sm1y,sm1z) select @nowno,pl1no,sm1month,@pe1no,sm1a,sm1b,sm1c,sm1d,sm1e,sm1f,sm1g,sm1h,sm1i,sm1j,sm1k,sm1l,sm1m,sm1n,sm1o,sm1p,sm1q,sm1r,sm1s,sm1t,sm1u,sm1v,sm1w,sm1x,sm1y,sm1z from sm2 where left(sm1month,4)=@yy and pe1no=@pe1no
if @dbf='SM3'
   insert into intra3.dbo.pe1_b0809 (nowno,pl1no,sm1month,pe1no,sm1a,sm1b,sm1c,sm1d,sm1e,sm1f,sm1g,sm1h,sm1i,sm1j,sm1k,sm1l,sm1m,sm1n,sm1o,sm1p,sm1q,sm1r,sm1s,sm1t,sm1u,sm1v,sm1w,sm1x,sm1y,sm1z) select @nowno,pl1no,sm1month,@pe1no,sm1a,sm1b,sm1c,sm1d,sm1e,sm1f,sm1g,sm1h,sm1i,sm1j,sm1k,sm1l,sm1m,sm1n,sm1o,sm1p,sm1q,sm1r,sm1s,sm1t,sm1u,sm1v,sm1w,sm1x,sm1y,sm1z from sm3 where left(sm1month,4)=@yy and pe1no=@pe1no

END
go

