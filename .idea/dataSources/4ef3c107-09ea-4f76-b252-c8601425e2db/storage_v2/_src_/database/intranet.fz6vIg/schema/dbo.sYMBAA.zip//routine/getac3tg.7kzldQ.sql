-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[getac3tg] (@nowno char(9),@ac3yy char(4),@dp1lun char(1))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
declare @n int,@count int,@pl1no char(4)

set @count=1
delete from intra3.dbo.ac3t where nowno=@nowno
if (select object_id('tempdb..#tmp'))is not null
begin
	drop table #tmp;
end
if (select object_id('tempdb..#tmp2'))is not null
begin
	drop table #tmp2;
end
	
if (select object_id('tempdb..#tmp3'))is not null
begin
	drop table #tmp3;
end
if (select object_id('tempdb..#tmp4'))is not null
begin
	drop table #tmp4;
end
if (select object_id('tempdb..#tmp9'))is not null
begin
	drop table #tmp9;
end
select ROW_NUMBER() OVER(ORDER BY id) AS rowid,pl1no into #tmp9 from intra3.dbo.dp1ch where nowno=@nowno
select @n=COUNT(*) from intra3.dbo.dp1ch where nowno=@nowno

create table #tmp3 (mm char(2),pl1no char(4),ac2no1 char(10),ac2no char(4),ac2no2 char(6),ad1dmon decimal(12, 2),ad1cmon decimal(12, 2))
if (@dp1lun='T')
begin
	select @nowno as nowno,ac3num,pl1no,ac3yy,ac2no,ac2no2,ac2name,ac2eng,ac2type, ac3mb1,ac3mb2 into #tmp from ac3 where ac3yy=@ac3yy and pl1no in (select pl1no from intra3.dbo.dp1ch where nowno=@nowno) order by ac2no,ac2no2;
	insert into intra3.dbo.ac3t (nowno,ac3num,pl1no,dp1lun,ac3yy,ac2no1,ac2no,ac2no2,ac2name,ac2eng,ac2type,ac3mb1,ac3mb2) select nowno,ac3num,pl1no,@dp1lun,ac3yy,ac2no+ac2no2,ac2no,ac2no2,ac2name,ac2eng,ac2type,ac3mb1,ac3mb2 from tempdb.#tmp
	drop table #tmp
end
if (@dp1lun='C') or (@dp1lun='P')
begin
	select @nowno as nowno,ac3num,pl1no,ac3yy,ac2no,ac2no2,ac2name,ac2eng,ac2type, ac3mb1,ac3mb2 into #tmp2 from intranet2.dbo.ac3o where ac3yy=@ac3yy and pl1no in (select pl1no from intra3.dbo.dp1ch where nowno=@nowno) order by ac2no,ac2no2;
	insert into intra3.dbo.ac3t (nowno,ac3num,pl1no,dp1lun,ac3yy,ac2no1,ac2no,ac2no2,ac2name,ac2eng,ac2type,ac3mb1,ac3mb2) select nowno,ac3num,pl1no,@dp1lun,ac3yy,ac2no+ac2no2,ac2no,ac2no2,ac2name,ac2eng,ac2type,ac3mb1,ac3mb2 from tempdb.#tmp2
	drop table #tmp2
end
update intra3.dbo.ac3t set dp1lun2=(select dp1lun2 from depcode as d where d.dp1no=pl1no) where nowno=@nowno
--select * from tempdb.#tmp order by pl1no

/*while @count<=@n
begin
  select @pl1no=pl1no from tempdb.#tmp9 where rowid=@count
  insert into #tmp3 execute getad1g4 @nowno,@pl1no,@ac3yy,@dp1lun
  set @count=@count+1
end
*/
insert into #tmp3 (mm,pl1no,ac2no1,ac2no,ac2no2,ad1dmon,ad1cmon) select MONTH(ad1date) AS mm,pl1no,ac2no+ac2no2 as ac2no1,ac2no,ac2no2,sum(ad1dmon) as ad1dmon,sum(ad1cmon) as ad1cmon from intra3.dbo.ad2g3 where nowno=@nowno group by MONTH(ad1date),pl1no,ac2no,ac2no2
--execute getad1g3 @nowno,@ac3yy,@dp1lun
select pl1no,mm,ac2no,ac2no2,SUM(ad1dmon) as ad1dmon,SUM(ad1cmon) as ad1cmon into #tmp4 from #tmp3 group by pl1no,mm,ac2no,ac2no2
--select pl1no,mm,ac2no,ac2no2,ad1dmon,ad1cmon into #tmp4 from #tmp3
delete from intra3.dbo.ac3t2 where nowno=@nowno
insert into intra3.dbo.ac3t2 (nowno,pl1no,ac3yy,ac3mm,ac2no1,ac2no,ac2no2,ad1dmon,ad1cmon) select @nowno,pl1no,@ac3yy,mm,ac2no+ac2no2,ac2no,ac2no2,ad1dmon,ad1cmon from #tmp4
drop table #tmp3
drop table #tmp4
drop table #tmp9

END
go

