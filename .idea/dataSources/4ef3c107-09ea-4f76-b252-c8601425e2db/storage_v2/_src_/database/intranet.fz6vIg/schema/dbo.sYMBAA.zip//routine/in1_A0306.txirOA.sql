-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[in1_A0123] (@nowno char(9),@lu1no char(2),@byy char(4),@byy2 char(4),@byy3 char(4),@bmm int,@emm int,@mon21 int,@dp1over char(1),@dp1lun char(1))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    declare @n int,@yy char(4)

	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
--set @n=1
delete from intra3.dbo.in1_a0123 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)

--while @n<=12
--begin
  if @lu1no=''
  insert into intra3.dbo.in1_a0123 (nowno,lu1no,pl1no,pl1name,pin1_2,pin2_2,pin3_2,dp1over,dp1lun,dp1yn2) select @nowno,dp1lun2,dp1no,DP1NAME,0,0,0,dp1over,dp1lun,dp1yn2 from intranet.dbo.depcode
  else
  insert into intra3.dbo.in1_a0123 (nowno,lu1no,pl1no,pl1name,pin1_2,pin2_2,pin3_2,dp1over,dp1lun,dp1yn2) select @nowno,dp1lun2,dp1no,DP1NAME,0,0,0,dp1over,dp1lun,dp1yn2 from intranet.dbo.depcode where dp1lun2=@lu1no
  --set @n=@n+1
--end

if @dp1lun='A'
begin
	create table #tmp (yy char(4),dp1no char(4),mon decimal(12, 0))
	if @dp1over='Y'
	  begin
		set @yy=@byy
		insert into #tmp (yy,dp1no,mon) select @yy,pl1no,sum(bk1cah +bk1oth + bk1oth2 + bk1mon2 + bk1mon3) as mon from intranet2.dbo.in2 where year(bk1date)=@yy and month(bk1date) between @bmm and @emm and pl1no in (select pl1no from intra3.dbo.in1_a0123 where nowno=@nowno) group by pl1no
		set @yy=@byy2
		insert into #tmp (yy,dp1no,mon) select @yy,pl1no,sum(bk1cah +bk1oth + bk1oth2 + bk1mon2 + bk1mon3) as mon from intranet2.dbo.in2 where year(bk1date)=@yy and month(bk1date) between @bmm and @emm and pl1no in (select pl1no from intra3.dbo.in1_a0123 where nowno=@nowno) group by pl1no
		set @yy=@byy3
		insert into #tmp (yy,dp1no,mon) select @yy,pl1no,sum(bk1cah +bk1oth + bk1oth2 + bk1mon2 + bk1mon3) as mon from intranet2.dbo.in2 where year(bk1date)=@yy and month(bk1date) between @bmm and @emm and pl1no in (select pl1no from intra3.dbo.in1_a0123 where nowno=@nowno) group by pl1no
		update intra3.dbo.in1_a0123 set pin1_2=(select mon from #tmp where yy=@byy and dp1no=pl1no) where nowno=@nowno
		update intra3.dbo.in1_a0123 set pin2_2=(select mon from #tmp where yy=@byy2 and dp1no=pl1no) where nowno=@nowno
		update intra3.dbo.in1_a0123 set pin3_2=(select mon from #tmp where yy=@byy3 and dp1no=pl1no) where nowno=@nowno
		update intra3.dbo.in1_a0123 set pin1_2=0 where pin1_2 is null
		update intra3.dbo.in1_a0123 set pin2_2=0 where pin2_2 is null
		update intra3.dbo.in1_a0123 set pin3_2=0 where pin3_2 is null
		update intra3.dbo.in1_a0123 set pin1_2=pin1_2/@mon21,pin2_2=pin2_2/@mon21,pin3_2=pin3_2/@mon21 where nowno=@nowno
		delete from intra3.dbo.in1_a0123 where pin1_2=0 and pin2_2=0 and pin3_2=0 or pin3_2=0 
	  end
	else
	 begin
		set @yy=@byy
		insert into #tmp (yy,pl1no,mon) select @yy,pl1no,sum(bk1cah +bk1oth + bk1oth2 + bk1mon2 + bk1mon3) as mon from intranet2.dbo.in2 where year(bk1date)=@yy and pl1no in (select pl1no from intra3.dbo.in1_a0123 where nowno=@nowno) group by pl1no
		set @yy=@byy2
		insert into #tmp (yy,pl1no,mon) select @yy,pl1no,sum(bk1cah +bk1oth + bk1oth2 + bk1mon2 + bk1mon3) as mon from intranet2.dbo.in2 where year(bk1date)=@yy and pl1no in (select pl1no from intra3.dbo.in1_a0123 where nowno=@nowno) group by pl1no
		set @yy=@byy3
		insert into #tmp (yy,pl1no,mon) select @yy,pl1no,sum(bk1cah +bk1oth + bk1oth2 + bk1mon2 + bk1mon3) as mon from intranet2.dbo.in2 where year(bk1date)=@yy and pl1no in (select pl1no from intra3.dbo.in1_a0123 where nowno=@nowno) group by pl1no
		update intra3.dbo.in1_a0123 set pin1_2=(select mon from #tmp where yy=@byy and pl1no=in1_a0123.pl1no) where nowno=@nowno
		update intra3.dbo.in1_a0123 set pin2_2=(select mon from #tmp where yy=@byy2 and pl1no=in1_a0123.pl1no) where nowno=@nowno
		update intra3.dbo.in1_a0123 set pin3_2=(select mon from #tmp where yy=@byy3 and pl1no=in1_a0123.pl1no) where nowno=@nowno
		update intra3.dbo.in1_a0123 set pin1_2=0 where pin1_2 is null
		update intra3.dbo.in1_a0123 set pin2_2=0 where pin2_2 is null
		update intra3.dbo.in1_a0123 set pin3_2=0 where pin3_2 is null
		update intra3.dbo.in1_a0123 set pin1_2=pin1_2/@mon21,pin2_2=pin2_2/@mon21,pin3_2=pin3_2/@mon21 where nowno=@nowno
		delete from intra3.dbo.in1_a0123 where pin1_2=0 and pin2_2=0 and pin3_2=0
	 end
	 drop table #tmp
end
else
begin
	create table #tmp2 (yy char(4),dp1no char(4),mon decimal(12, 0))
	if @dp1over='Y'
	  begin
		set @yy=@byy
		insert into #tmp2 (yy,dp1no,mon) select @yy,pl1no,sum(bk1cah +bk1oth + bk1oth2 + bk1mon2 + bk1mon3) as mon from intranet2.dbo.in2 where year(bk1date)=@yy and pl1no in (select dp1no from depcode as d where d.dp1lun=@dp1lun) group by pl1no
		set @yy=@byy2
		insert into #tmp2 (yy,dp1no,mon) select @yy,pl1no,sum(bk1cah +bk1oth + bk1oth2 + bk1mon2 + bk1mon3) as mon from intranet2.dbo.in2 where year(bk1date)=@yy and pl1no in (select dp1no from depcode as d where d.dp1lun=@dp1lun) group by pl1no
		set @yy=@byy3
		insert into #tmp2 (yy,dp1no,mon) select @yy,pl1no,sum(bk1cah +bk1oth + bk1oth2 + bk1mon2 + bk1mon3) as mon from intranet2.dbo.in2 where year(bk1date)=@yy and pl1no in (select dp1no from depcode as d where d.dp1lun=@dp1lun) group by pl1no
		update intra3.dbo.in1_a0123 set pin1_2=(select mon from #tmp2 where yy=@byy and dp1no=pl1no) where nowno=@nowno
		update intra3.dbo.in1_a0123 set pin2_2=(select mon from #tmp2 where yy=@byy2 and dp1no=pl1no) where nowno=@nowno
		update intra3.dbo.in1_a0123 set pin3_2=(select mon from #tmp2 where yy=@byy3 and dp1no=pl1no) where nowno=@nowno
		update intra3.dbo.in1_a0123 set pin1_2=0 where pin1_2 is null
		update intra3.dbo.in1_a0123 set pin2_2=0 where pin2_2 is null
		update intra3.dbo.in1_a0123 set pin3_2=0 where pin3_2 is null
		update intra3.dbo.in1_a0123 set pin1_2=pin1_2/@mon21,pin2_2=pin2_2/@mon21,pin3_2=pin3_2/@mon21 where nowno=@nowno
		delete from intra3.dbo.in1_a0123 where pin1_2=0 and pin2_2=0 and pin3_2=0 or pin3_2=0 
	  end
	else
	  begin
		set @yy=@byy
		insert into #tmp2 (yy,dp1no,mon) select @yy,pl1no,sum(bk1cah +bk1oth + bk1oth2 + bk1mon2 + bk1mon3) as mon from intranet2.dbo.in2 where year(bk1date)=@yy and pl1no in (select dp1no from depcode as d where d.dp1lun=@dp1lun) group by pl1no
		set @yy=@byy2
		insert into #tmp2 (yy,dp1no,mon) select @yy,pl1no,sum(bk1cah +bk1oth + bk1oth2 + bk1mon2 + bk1mon3) as mon from intranet2.dbo.in2 where year(bk1date)=@yy and pl1no in (select dp1no from depcode as d where d.dp1lun=@dp1lun) group by pl1no
		set @yy=@byy3
		insert into #tmp2 (yy,dp1no,mon) select @yy,pl1no,sum(bk1cah +bk1oth + bk1oth2 + bk1mon2 + bk1mon3) as mon from intranet2.dbo.in2 where year(bk1date)=@yy and pl1no in (select dp1no from depcode as d where d.dp1lun=@dp1lun) group by pl1no
		update intra3.dbo.in1_a0123 set pin1_2=(select mon from #tmp2 where yy=@byy and dp1no=pl1no) where nowno=@nowno
		update intra3.dbo.in1_a0123 set pin2_2=(select mon from #tmp2 where yy=@byy2 and dp1no=pl1no) where nowno=@nowno
		update intra3.dbo.in1_a0123 set pin3_2=(select mon from #tmp2 where yy=@byy3 and dp1no=pl1no) where nowno=@nowno
		update intra3.dbo.in1_a0123 set pin1_2=0 where pin1_2 is null
		update intra3.dbo.in1_a0123 set pin2_2=0 where pin2_2 is null
		update intra3.dbo.in1_a0123 set pin3_2=0 where pin3_2 is null
		update intra3.dbo.in1_a0123 set pin1_2=pin1_2/@mon21,pin2_2=pin2_2/@mon21,pin3_2=pin3_2/@mon21 where nowno=@nowno
		delete from intra3.dbo.in1_a0123 where pin1_2=0 and pin2_2=0 and pin3_2=0 
	  end
	  drop table #tmp2
end
END
go

