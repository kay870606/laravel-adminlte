-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[pe1b0803] (@nowno char(9),@yy char(4),@pl1no char(4))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
delete from intra3.dbo.pe1_b0803 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
if @pl1no=''
begin
	insert into intra3.dbo.pe1_b0803 (nowno,pl1no,pe1no,usrname,pf1ari) select @nowno,dep,usrno,usrname,pf1ari from usr where dep in (select dp1no from depcode where dp1lun='T') and pf1lef is null order by dep,usrno
	select pl1no,pe1no,ph1date,hl1no,ph1hrs from ph1 where year(ph1date)=@yy and hl1no in ('B','C','I','G','H','R') order by pl1no,pe1no,ph1date
end
else
begin
	insert into intra3.dbo.pe1_b0803 (nowno,pl1no,pe1no,usrname,pf1ari) select @nowno,dep,usrno,usrname,pf1ari from usr where dep=@pl1no and pf1lef is null order by dep,usrno
	select pl1no,pe1no,ph1date,hl1no,ph1hrs from ph1 where pl1no=@pl1no and year(ph1date)=@yy and hl1no in ('B','C','I','G','H','R') order by pl1no,pe1no,ph1date
end
END
go

