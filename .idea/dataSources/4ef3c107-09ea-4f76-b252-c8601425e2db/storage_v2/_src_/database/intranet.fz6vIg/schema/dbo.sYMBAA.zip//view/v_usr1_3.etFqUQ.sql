CREATE VIEW dbo.v_usr1_3
AS
SELECT     dbo.depcode.DP1NAME, dbo.depcode.dp1lun, dbo.pw2.pw1a, dbo.pw2.pw1b, dbo.pw2.pw1w, dbo.pw2.pw1c, dbo.pw2.pw1d, dbo.pw2.pw1e, dbo.pw2.pw1f, dbo.pw2.pw1g, dbo.pw2.pw1h, 
                      dbo.pw2.pw1i, dbo.pw2.pw1j, dbo.pw2.pw1k, dbo.pw2.pw1l, dbo.pw2.pw1m, dbo.pw2.pw1n, dbo.pw2.pw1o, dbo.pw2.pw1p, dbo.pw2.pw1q, dbo.pw2.pw1r, dbo.pw2.pw1s, dbo.pw2.pw1t, dbo.pw2.pw1u, 
                      dbo.pw2.pw1v, dbo.pw2.pw1x, dbo.pw2.pw1y, dbo.pw2.pw1z, dbo.pw2.pw1memo, dbo.pw2.pw1dmon, dbo.pw2.pw1hmon, dbo.pw2.pw1hr, dbo.pw2.pl1no, dbo.pe1.usrno, dbo.pe1.pf1chdate, 
                      dbo.usr.usrname, dbo.usr.post, dbo.usr.dep, dbo.usr.po2no, dbo.usr.pf1id, dbo.usr.pf1sup, dbo.usr.pf1inm, dbo.usr.pf1ari, dbo.usr.pf1nno, dbo.usr.pf1type, dbo.usr.pf1all, dbo.usr.pf1otime, 
                      dbo.usr.pf1lun, dbo.usr.dp3name, dbo.usr.pf1leave, dbo.usr.pf1umon, dbo.usr.pf1umon2, dbo.pe1.pf1start, dbo.pe1.pf1hr, dbo.pe1.pf1hr2, dbo.pe1.pf1lef, dbo.usr.pf1yn4, dbo.usr.pf1yn5, 
                      dbo.usr.pe1lay
FROM         dbo.pe1 INNER JOIN
                      dbo.pw2 ON dbo.pe1.usrno = dbo.pw2.pe1no AND dbo.pe1.pl1no = dbo.pw2.pl1no INNER JOIN
                      dbo.depcode ON dbo.pe1.dep = dbo.depcode.DP1NO INNER JOIN
                      dbo.usr ON dbo.pe1.usrno = dbo.usr.usrno
go

