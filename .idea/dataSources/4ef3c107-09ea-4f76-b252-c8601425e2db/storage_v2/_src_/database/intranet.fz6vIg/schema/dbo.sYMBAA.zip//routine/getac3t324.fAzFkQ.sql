-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[getac3t324] (@nowno char(9),@pl1no varchar(10),@ac3yy char(4),@bmm char(2),@emm char(2),@dp1lun char(1))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	delete from intra3.dbo.ac3t324 where ad1idate<CONVERT(nvarchar(30), GETDATE(), 111)
	delete from intra3.dbo.ac3t324 where nowno=@nowno

	create table #tmp3 (ad1no char(8),ab1no char(2),ac2no char(4),ac2no2 char(6),ac2name nvarchar(50),ad1dc char(1),ad1dmon decimal(12, 2),ad1cmon decimal(12, 2),ad1memo nvarchar(200))
	insert into #tmp3 execute getab1 @nowno,@pl1no,@ac3yy,@bmm,@emm,@dp1lun
	select aa.*,ab1.ab1name into #tmp4 from #tmp3 as aa,intranet.dbo.ab1 where aa.ab1no=ab1.ab1no order by aa.ab1no,aa.ac2no,aa.ac2no2
	insert into intra3.dbo.ac3t324 (nowno,pl1no,ad1no,ab1no,ab1name,ac2no,ac2no2,ac2name,ad1dc,ad1dmon,ad1cmon,ad1memo) select @nowno,@pl1no,ad1no,ab1no,ab1name,ac2no,ac2no2,ac2name,ad1dc,ad1dmon,ad1cmon,ad1memo from #tmp4
	drop table #tmp3
	drop table #tmp4

END
go

