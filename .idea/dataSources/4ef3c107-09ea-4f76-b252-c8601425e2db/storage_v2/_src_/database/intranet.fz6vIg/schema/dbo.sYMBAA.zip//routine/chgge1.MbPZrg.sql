-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[chgge1] (@ono char(5),@nno char(5))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	update ge1 set ge1no=@nNo where ge1no=@oNo
	update gl1 set ge1no=@nNo where ge1no=@oNo
	update gl4 set ge1no=@nNo where ge1no=@oNo
	update gp1 set ge1no=@nNo where ge1no=@oNo
	update gp1 set ge1no2=@nNo where ge1no2=@oNo
	update gp2 set ge1no=@nNo where ge1no=@oNo
	update gp3 set ge1no=@nNo where ge1no=@oNo
	update gp4 set ge1no=@nNo where ge1no=@oNo
	update gs1 set ge1no=@nNo where ge1no=@oNo

END
go

