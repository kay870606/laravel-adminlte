-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[be1_A0808] (@nowno char(9),@pl1no char(4),@yymm char(4),@bcode char(8),@ecode char(8))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
delete from intra3.dbo.be1_A0308 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
if @bcode='' or @ecode=''
insert into intra3.dbo.be1_A0308 (nowno,pl1no,bh1lst,bb1no,bh1mac,be1bdate,be1edate,bb1not) select @nowno,@pl1no,bh1lst,bb1no,bh1mac,be1bdate,be1edate,bb1not from intranet2.dbo.be1 where pl1no=@pl1no and bh1ym=@yymm and be1bad='Y' order by bb1no
else
insert into intra3.dbo.be1_A0308 (nowno,pl1no,bh1lst,bb1no,bh1mac,be1bdate,be1edate,bb1not) select @nowno,@pl1no,bh1lst,bb1no,bh1mac,be1bdate,be1edate,bb1not from intranet2.dbo.be1 where pl1no=@pl1no and bh1ym=@yymm and bh1lst BETWEEN @bcode and @ecode and be1bad='Y' order by bb1no
update intra3.dbo.be1_A0308 set bb1name=(select bb1name from bb1 where bb1no=intra3.dbo.be1_A0308.bb1no) where nowno=@nowno
END
go

