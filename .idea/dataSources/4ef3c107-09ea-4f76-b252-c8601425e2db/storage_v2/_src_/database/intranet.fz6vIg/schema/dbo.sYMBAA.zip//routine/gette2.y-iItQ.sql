-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[gette2] (@nowno char(9),@byy char(4))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

delete from intra3.dbo.te1p
delete from intra3.dbo.te1c
insert into intra3.dbo.te1p (pe1no,pe1name,te3mm,te3mon) select DISTINCT pe1no,pe1name,0,0 from te1 where  te1yy=@byy and pe1no <>''
insert into intra3.dbo.te1c (pl1no,pe1no,pe1name,te0name) select DISTINCT pl1no,pe1no,pe1name,te0name from te1 where  te1yy=@byy and pe1no <>''
END
go

