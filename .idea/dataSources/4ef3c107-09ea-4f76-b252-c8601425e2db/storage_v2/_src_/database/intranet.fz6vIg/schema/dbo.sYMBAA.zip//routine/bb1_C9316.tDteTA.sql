-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[bb1_C9316] (@nowno char(9),@byymm char(6),@gl3t3040 char(4))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
	if (select object_id('tempdb..#tmp2'))is not null
	begin
		drop table #tmp2;
	end

create table #tmp (pl1no2 char(4),gl1pi2 decimal(10, 4))
create table #tmp2 (pl1no3 char(4),gl1pi3 decimal(10, 4))
if @gl3t3040='A'
begin
	insert into #tmp (pl1no2,gl1pi2) select pl1no,sum(gl1pi) as mon from gl4 where gl3month=@byymm and pl1no in (select dp1no from depcode where dp1lun='C') and ge1no in (select ge1no from ge1 where ge1mtype2='C') group by pl1no
	insert into #tmp2 (pl1no3,gl1pi3) select pl1no,sum(gl1pi) as mon from gl4 where gl3month=@byymm and pl1no in (select dp1no from depcode where dp1lun='C') and ge1no in (select ge1no from ge1 where ge1mtype2='T') group by pl1no
end
else
begin
	insert into #tmp (pl1no2,gl1pi2) select pl1no,sum(gl1pi) as mon from gl4 where gl3month=@byymm and gl3t3040=@gl3t3040 and pl1no in (select dp1no from depcode where dp1lun='C') and ge1no in (select ge1no from ge1 where ge1mtype2='C') group by pl1no
	insert into #tmp2 (pl1no3,gl1pi3) select pl1no,sum(gl1pi) as mon from gl4 where gl3month=@byymm and gl3t3040=@gl3t3040 and pl1no in (select dp1no from depcode where dp1lun='C') and ge1no in (select ge1no from ge1 where ge1mtype2='T') group by pl1no
end

update intra3.dbo.bb1c9316 set gl3mpi2=#tmp.gl1pi2 from #tmp join intra3.dbo.bb1c9316 on pl1no2=pl1no where nowno=@nowno
update intra3.dbo.bb1c9316 set gl3mpi=#tmp2.gl1pi3 from #tmp2 join intra3.dbo.bb1c9316 on pl1no3=pl1no where nowno=@nowno
drop table #tmp
drop table #tmp2
END
go

