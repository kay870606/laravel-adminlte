-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[getfi5] (@us1no char(5),@fi1group nvarchar(50))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp
	end
	select fi1group,fi1group2 into #tmp from fi5 where us1no=@us1no and fi1group like '%'+@fi1group+'%'
	insert into tempdb.#tmp (fi1group,fi1group2) select fi1group,fi1group2 from fi5p where pe1no=@us1no and fi1group like '%'+@fi1group+'%'
	select DISTINCT * from tempdb.#tmp
	drop table #tmp
END
go

