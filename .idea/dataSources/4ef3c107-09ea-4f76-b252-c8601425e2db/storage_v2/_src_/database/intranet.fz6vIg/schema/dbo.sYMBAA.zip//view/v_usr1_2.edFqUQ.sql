CREATE VIEW dbo.v_usr1_2
AS
SELECT     dbo.depcode.DP1NAME, dbo.depcode.dp1lun, dbo.pw1.pw1a, dbo.pw1.pw1b, dbo.pw1.pw1c, dbo.pw1.pw1d, dbo.pw1.pw1e, dbo.pw1.pw1f, dbo.pw1.pw1g, dbo.pw1.pw1h, dbo.pw1.pw1i, 
                      dbo.pw1.pw1j, dbo.pw1.pw1k, dbo.pw1.pw1l, dbo.pw1.pw1m, dbo.pw1.pw1n, dbo.pw1.pw1o, dbo.pw1.pw1p, dbo.pw1.pw1q, dbo.pw1.pw1r, dbo.pw1.pw1s, dbo.pw1.pw1t, dbo.pw1.pw1u, 
                      dbo.pw1.pw1v, dbo.pw1.pw1w, dbo.pw1.pw1x, dbo.pw1.pw1y, dbo.pw1.pw1z, dbo.pw1.pw1memo, dbo.pw1.pl1no, dbo.pe1.usrno, dbo.pe1.pf1chdate, dbo.usr.usrname, dbo.usr.post, dbo.usr.dep, 
                      dbo.usr.po2no, dbo.usr.pf1id, dbo.usr.pf1sup, dbo.usr.pf1inm, dbo.usr.pf1ari, dbo.usr.pf1all, dbo.usr.pf1lun, dbo.usr.pf1leave, dbo.usr.pf1nno, dbo.usr.dp3name, dbo.pe1.pf1start, dbo.pe1.pf1hr, 
                      dbo.pe1.pf1hr2, dbo.pe1.pf1lef, dbo.usr.pf1yn4, dbo.usr.pf1yn5, dbo.usr.pe1lay
FROM         dbo.pw1 INNER JOIN
                      dbo.pe1 ON dbo.pw1.pe1no = dbo.pe1.usrno AND dbo.pw1.pl1no = dbo.pe1.pl1no INNER JOIN
                      dbo.depcode ON dbo.pe1.dep = dbo.depcode.DP1NO INNER JOIN
                      dbo.usr ON dbo.pe1.usrno = dbo.usr.usrno
go

