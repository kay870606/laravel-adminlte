CREATE VIEW dbo.v_pe1
AS
SELECT          dbo.usr.usrno, dbo.usr.usrpwd, dbo.usr.usrname, dbo.usr.dep, dbo.usr.tel, dbo.po2.po2name, dbo.po2.po2eng, 
                            dbo.postcode.PO1NAME, dbo.postcode.po1eng, dbo.v_dp1.DP1NAME, dbo.v_dp1.dp1no2, dbo.v_dp1.oy1over, 
                            dbo.v_dp1.dp1over, dbo.v_dp1.dp1yn, dbo.v_dp1.oy1date, dbo.v_dp1.oy1month, dbo.v_dp1.dp1lun, 
                            dbo.v_dp1.lu1name, dbo.v_dp1.lu1sort, dbo.v_dp1.lu1lun, dbo.v_dp1.lu1dno, dbo.v_dp1.lu2no, dbo.usr.po2no, 
                            dbo.usr.pf1eng, dbo.usr.pf1id, dbo.usr.pf1nat, dbo.usr.pf1pse, dbo.usr.pf1sex, dbo.usr.pf1bld, dbo.usr.pf1bpc, 
                            dbo.usr.pf1add, dbo.usr.pf1ari, dbo.usr.pf1lef, dbo.usr.pf1start, dbo.usr.pf1inl, dbo.usr.pf1inm, dbo.usr.pf1gnd, 
                            dbo.usr.pf1gnl, dbo.usr.pf1gnm, dbo.usr.pf1inm2, dbo.usr.pf1bth, dbo.usr.pf1add1, dbo.usr.pf1add2, dbo.usr.pf1add3, 
                            dbo.usr.zp1no, dbo.usr.pf1hr, dbo.usr.pf1hr2, dbo.usr.pf1late, dbo.postcode.PO1NO, dbo.usr.pf1lun, dbo.usr.post, 
                            dbo.v_dp1.dp1lun2
FROM              dbo.usr INNER JOIN
                            dbo.v_dp1 ON dbo.usr.dep = dbo.v_dp1.DP1NO INNER JOIN
                            dbo.po2 ON dbo.usr.po2no = dbo.po2.po2no INNER JOIN
                            dbo.postcode ON dbo.usr.post = dbo.postcode.PO1NO
go

