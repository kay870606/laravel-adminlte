CREATE VIEW dbo.v_pl1
AS
SELECT          dbo.pl1.pl1no, dbo.pl1.pl1name, dbo.gl1.ge1no, dbo.gl1.gl1pi, dbo.gl1.bk1type, dbo.gl1.gl1memo, dbo.gl1.bk1type2, 
                            dbo.gl1.gl1date1, dbo.gl1.gl1mon1, dbo.gl1.gl1date2, dbo.gl1.gl1mon2, dbo.gl1.gl1date3, dbo.gl1.gl1mon3, 
                            dbo.gl1.gl1omon, dbo.gl1.gl1omon2, dbo.gl1.gl1pi2, dbo.gl1.gl1pi3, dbo.gl1.gl1pi1, dbo.gl1.gl1pi4, dbo.gl1.gl1pi6, 
                            dbo.gl1.gl1pi5, dbo.gl1.gl1pi7, dbo.gl1.gl1pi9, dbo.gl1.gl1pi8, dbo.gl1.gl1pia, dbo.gl1.gl1price1, dbo.gl1.gl1price2, 
                            dbo.gl1.gl1price3, dbo.gl1.gl1price21, dbo.gl1.gl1price22, dbo.gl1.gl1price23, dbo.gl1.gl1mon21, dbo.gl1.gl1mon22, 
                            dbo.gl1.gl1mon23, dbo.gl1.gl1jm, dbo.gl1.ge1bname, dbo.gl1.ge1bn, dbo.gl1.ge1ba, dbo.gl1.ge1bb, dbo.gl1.ge1bc, 
                            dbo.gl1.gl1prt, dbo.gl1.gl1edit, dbo.gl1.gl1bpi1, dbo.gl1.gl1bpi2, dbo.gl1.gl1bpi3, dbo.gl1.gl1bpi4, dbo.gl1.gl1bpi5, 
                            dbo.gl1.gl1bpi6, dbo.gl1.gl1bpi7, dbo.gl1.gl1bpi8, dbo.gl1.gl1bpi9, dbo.gl1.gl1bpia, dbo.ge1.ge1name, 
                            dbo.depcode.dp1no2, dbo.ge1.ge1no AS Expr2, dbo.ge1.usrno, dbo.depcode.dp1yn2, dbo.depcode.dp1over, 
                            dbo.depcode.dp1lun, dbo.depcode.dp1lun2, dbo.depcode.dp1bn, dbo.depcode.pl1date, dbo.lu1.lu1sort
FROM              dbo.ge1 INNER JOIN
                            dbo.gl1 ON dbo.ge1.ge1no = dbo.gl1.ge1no INNER JOIN
                            dbo.pl1 ON dbo.gl1.pl1no = dbo.pl1.pl1no INNER JOIN
                            dbo.depcode ON dbo.gl1.pl1no = dbo.depcode.DP1NO AND dbo.pl1.pl1name = dbo.depcode.DP1NAME INNER JOIN
                            dbo.lu1 ON dbo.depcode.dp1lun2 = dbo.lu1.lu1no
go

