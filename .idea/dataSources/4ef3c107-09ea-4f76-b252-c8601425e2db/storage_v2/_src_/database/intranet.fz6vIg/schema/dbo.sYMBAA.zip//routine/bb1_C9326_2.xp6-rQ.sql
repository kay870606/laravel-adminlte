-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[bb1_C9326_2] (@nowno char(9),@gl3month char(6))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end

--delete from gl7 where gl7ym=@gl3month or gl7idate<CONVERT(nvarchar(30), GETDATE(), 111)
--delete from gl7_2 where gl7ym=@gl3month or gl7_2idate<CONVERT(nvarchar(30), GETDATE(), 111)
delete from gl7 where gl7ym=@gl3month
delete from gl7_2 where gl7ym=@gl3month

create table #tmp (dp1lun3 char(3),pl1no char(4),ge1no char(5),gl4mon2 decimal(12, 0))
insert into #tmp (dp1lun3,pl1no,ge1no,gl4mon2) select (select dp1lun3 from depcode where dp1no=pl1no)as dp1lun3,pl1no,ge1no,gl4mon2 from gl4 where gl3month=@gl3month and pl1no in (select dp1no from depcode where dp1lun='C') order by ge1no,dp1lun3,pl1no

----grid 直式
--insert into gl7_2 (gl7ym,ge1no,lu1no,mon,ge1bname,ge1ba,ge1bb) select @gl3month,ge1no,dp1lun3,sum(gl4mon2),(select ge1bname from ge1bk2 where ge1no=#tmp.ge1no and lu1no=#tmp.dp1lun3),(select ge1ba from ge1bk2 where ge1no=#tmp.ge1no and lu1no=#tmp.dp1lun3),(select ge1bb from ge1bk2 where ge1no=#tmp.ge1no and lu1no=#tmp.dp1lun3) from #tmp group by dp1lun3,ge1no
insert into gl7_2 (gl7ym,ge1no,lu1no,mon,ge1bname,ge1ba,ge1bb) select @gl3month,ge1no,dp1lun3,sum(gl4mon2),(select top 1 ge1bname from ge1bk2 where ge1no=#tmp.ge1no and lu1no=#tmp.dp1lun3),(select top 1 ge1ba from ge1bk2 where ge1no=#tmp.ge1no and lu1no=#tmp.dp1lun3),(select top 1 ge1bb from ge1bk2 where ge1no=#tmp.ge1no and lu1no=#tmp.dp1lun3) from #tmp group by dp1lun3,ge1no

--把股東insert into
insert into intranet.dbo.gl7(gl7ym,ge1no) select @gl3month,ge1no from gl4 where gl3month=@gl3month and pl1no in (select dp1no from depcode where dp1lun='C') group by ge1no order by ge1no

select ge1no,dp1lun3,sum(gl4mon2)as gl7mon,(select ge1no1 from ge1 where ge1no=#tmp.ge1no)as ge1no1 from #tmp group by dp1lun3,ge1no order by ge1no1,dp1lun3

drop table #tmp

END
go

