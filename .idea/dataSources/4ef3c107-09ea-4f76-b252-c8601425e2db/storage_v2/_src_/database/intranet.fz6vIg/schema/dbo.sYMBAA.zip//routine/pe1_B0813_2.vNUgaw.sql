-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[pe1_B0813_2] (@nowno char(9),@pl1no char(4),@bdate datetime,@edate datetime)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	delete from intra3.dbo.pe1_B0813_2

--insert into intra3.dbo.pe1_B0813_2 (nowno,dp3name,pe1no,usrname,pf1id) 
 --select @nowno,dp3name,usrno,usrname,pf1id from usr where pf1yn4<>'Y' AND dep=@pl1no And dep in (select dp1no from depcode where dp1over <> 'Y')
insert into intra3.dbo.pe1_B0813_2 (nowno,pl1no,dp3name,pe1no,usrname,pf1id,pf1bth,pf1ari,pf1lef,pf1gnd,pf1gnl,pf1nno,pf1out_d,pf1out_e,mon2,mon7,mon5,pf1gover,pf1pmon) 
--pf1gnl= 退保日  pf1gnd 投保日
 select @nowno,dep,dp3name,usrno,usrname,pf1id,pf1bth,pf1ari,pf1lef,pf1gnd,pf1gnl,pf1nno,pf1out_d,pf1out_e,pf1pi,0,0,pf1gover,pf1pmon from usr where pf1yn4<>'Y' AND dep=@pl1no AND (pf1lef is NULL or (pf1lef is not null and pf1gnl>=@bdate)) AND pf1gnd<=@edate AND dep in (select dp1no from depcode where dp1over <> 'Y')
update intra3.dbo.pe1_B0813_2 set pw1a=(select pw1a from pw1 where pw1.pe1no=intra3.dbo.pe1_B0813_2.pe1no) where pl1no='TOP'
update intra3.dbo.pe1_B0813_2 set pw1a=(select pw1a from pw2 where pw2.pe1no=intra3.dbo.pe1_B0813_2.pe1no AND pw2.pl1no=@pl1no) where pl1no<>'TOP'
update intra3.dbo.pe1_B0813_2 set pw1a=0 where pw1a is null
END
go

