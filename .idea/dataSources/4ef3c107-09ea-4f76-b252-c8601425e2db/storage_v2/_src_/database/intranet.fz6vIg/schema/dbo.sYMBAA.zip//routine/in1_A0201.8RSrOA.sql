-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[in1_A0116] (@nowno char(9),@pl1no char(4),@byy char(4),@byy2 char(4),@byy3 char(4),@bmm char(2),@emm char(2),@mon21 int)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    declare @n int,@yy char(4)

	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
set @n=1
delete from intra3.dbo.in1_A0116 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
while @n<=12
begin
  insert into intra3.dbo.in1_A0116 (nowno,pl1no,in1mm,pin1,pin2,pin3) values (@nowno,@pl1no,@n,0,0,0)
  set @n=@n+1
end

create table #tmp (yy char(4),in1mm char(2),mon decimal(8, 0))
set @yy=@byy
insert into #tmp (yy,in1mm,mon) select @yy,month(bk1date) as mm,sum(bk1cah +bk1oth + bk1oth2 + bk1mon2 + bk1mon3) as mon from intranet2.dbo.in2 where pl1no=@pl1no and year(bk1date)=@yy group by month(bk1date)
set @yy=@byy2
insert into #tmp (yy,in1mm,mon) select @yy,month(bk1date) as mm,sum(bk1cah +bk1oth + bk1oth2 + bk1mon2 + bk1mon3) as mon from intranet2.dbo.in2 where pl1no=@pl1no and year(bk1date)=@yy group by month(bk1date)
set @yy=@byy3
insert into #tmp (yy,in1mm,mon) select @yy,month(bk1date) as mm,sum(bk1cah +bk1oth + bk1oth2 + bk1mon2 + bk1mon3) as mon from intranet2.dbo.in2 where pl1no=@pl1no and year(bk1date)=@yy group by month(bk1date)
update intra3.dbo.in1_A0116 set pin1=(select mon from #tmp where yy=@byy and in1mm=intra3.dbo.in1_A0116.in1mm) where nowno=@nowno
update intra3.dbo.in1_A0116 set pin2=(select mon from #tmp where yy=@byy2 and in1mm=intra3.dbo.in1_A0116.in1mm) where nowno=@nowno
update intra3.dbo.in1_A0116 set pin3=(select mon from #tmp where yy=@byy3 and in1mm=intra3.dbo.in1_A0116.in1mm) where nowno=@nowno
update intra3.dbo.in1_A0116 set pin1=0 where pin1 is null
update intra3.dbo.in1_A0116 set pin2=0 where pin2 is null
update intra3.dbo.in1_A0116 set pin3=0 where pin3 is null
update intra3.dbo.in1_A0116 set pin1=pin1/@mon21,pin2=pin2/@mon21,pin3=pin3/@mon21 where nowno=@nowno
--select * from intra3.dbo.in1_A0116
--select * from #tmp
drop table #tmp

END
go

