-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[in1_A0304] (@byy char(4),@pe1no char(5),@dp1lun char(1),@dp1yn2 char(1),@dp1over char(1),@bdate1 char(10),@bdate2 char(10),@edate1 char(10),@edate2 char(10))
AS
BEGIN
	declare @eyy char(4),@nyy char(4),@edate char(10)
set @eyy=CAST( (CAST(@byy as int)-1) as char(4)) /* 前一年度 */
set @nyy=SUBSTRING( CONVERT(char(10),getdate(),111),1,4) /*--今年度--*/

	SET NOCOUNT ON;
		if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
	if (select object_id('tempdb..#tmp2'))is not null
	begin
		drop table #tmp2;
	end
if @byy=@nyy
begin
  --set @edate=@eyy+SUBSTRING( CONVERT(char(10),getdate(),111),5,4)+'01'
  create table #tmp (yy char(4),pl1no char(4),mon decimal(12, 0),dp1lun2 char(2))
  if @dp1lun='A'  --------------------全部
  begin
	if @dp1yn2='Y'
		begin
		if @dp1over='Y'
			begin
				insert into #tmp (yy,pl1no,mon,dp1lun2) select year(bk1date),pl1no,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon,(select dp1lun2 from depcode as d where d.dp1no=pl1no) as dp1lun2 from intranet2.dbo.in2 where year(bk1date)=@byy and bk1date between @edate1 and @edate2 group by year(bk1date),pl1no order by dp1lun2
				insert into #tmp (yy,pl1no,mon,dp1lun2) select year(bk1date),pl1no,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon,(select dp1lun2 from depcode as d where d.dp1no=pl1no) as dp1lun2 from intranet2.dbo.in2 where year(bk1date)=@eyy and bk1date between @bdate1 and @bdate2 group by year(bk1date),pl1no order by dp1lun2
			end
		else
			begin
				insert into #tmp (yy,pl1no,mon,dp1lun2) select year(bk1date),pl1no,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon,(select dp1lun2 from depcode as d where d.dp1no=pl1no) as dp1lun2 from intranet2.dbo.in2 where year(bk1date)=@byy and bk1date between @edate1 and @edate2 and pl1no in (select dp1no from depcode where dp1over<>'Y') group by year(bk1date),pl1no order by dp1lun2
				insert into #tmp (yy,pl1no,mon,dp1lun2) select year(bk1date),pl1no,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon,(select dp1lun2 from depcode as d where d.dp1no=pl1no) as dp1lun2 from intranet2.dbo.in2 where year(bk1date)=@eyy and bk1date between @bdate1 and @bdate2 and pl1no in (select dp1no from depcode where dp1over<>'Y') group by year(bk1date),pl1no order by dp1lun2
			end
		end
	else
		begin
		if @dp1over='Y'
			begin
				insert into #tmp (yy,pl1no,mon,dp1lun2) select year(bk1date),pl1no,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon,(select dp1lun2 from depcode as d where d.dp1no=pl1no) as dp1lun2 from intranet2.dbo.in2 where year(bk1date)=@byy and bk1date between @edate1 and @edate2 and pl1no in (select dp1no from depcode where dp1yn2<>'Y') group by year(bk1date),pl1no order by dp1lun2
				insert into #tmp (yy,pl1no,mon,dp1lun2) select year(bk1date),pl1no,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon,(select dp1lun2 from depcode as d where d.dp1no=pl1no) as dp1lun2 from intranet2.dbo.in2 where year(bk1date)=@eyy and bk1date between @bdate1 and @bdate2 and pl1no in (select dp1no from depcode where dp1yn2<>'Y') group by year(bk1date),pl1no order by dp1lun2
			end
		else
			begin
				insert into #tmp (yy,pl1no,mon,dp1lun2) select year(bk1date),pl1no,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon,(select dp1lun2 from depcode as d where d.dp1no=pl1no) as dp1lun2 from intranet2.dbo.in2 where year(bk1date)=@byy and bk1date between @edate1 and @edate2 and pl1no in (select dp1no from depcode where dp1yn2<>'Y' and dp1over<>'Y') group by year(bk1date),pl1no order by dp1lun2
				insert into #tmp (yy,pl1no,mon,dp1lun2) select year(bk1date),pl1no,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon,(select dp1lun2 from depcode as d where d.dp1no=pl1no) as dp1lun2 from intranet2.dbo.in2 where year(bk1date)=@eyy and bk1date between @bdate1 and @bdate2 and pl1no in (select dp1no from depcode where dp1yn2<>'Y' and dp1over<>'Y') group by year(bk1date),pl1no order by dp1lun2
			end
		end
  end
  -----------------------------------------------國別
  else
  begin
	if @dp1yn2='Y'
		begin
		if @dp1over='Y'
			begin
				insert into #tmp (yy,pl1no,mon,dp1lun2) select year(bk1date),pl1no,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon,(select dp1lun2 from depcode as d where d.dp1no=pl1no) as dp1lun2 from intranet2.dbo.in2 where year(bk1date)=@byy and bk1date between @edate1 and @edate2 and pl1no in (select dp1no from depcode where dp1lun=@dp1lun) group by year(bk1date),pl1no order by dp1lun2
				insert into #tmp (yy,pl1no,mon,dp1lun2) select year(bk1date),pl1no,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon,(select dp1lun2 from depcode as d where d.dp1no=pl1no) as dp1lun2 from intranet2.dbo.in2 where year(bk1date)=@eyy and bk1date between @bdate1 and @bdate2 and pl1no in (select dp1no from depcode where dp1lun=@dp1lun) group by year(bk1date),pl1no order by dp1lun2
			end
		else
			begin
				insert into #tmp (yy,pl1no,mon,dp1lun2) select year(bk1date),pl1no,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon,(select dp1lun2 from depcode as d where d.dp1no=pl1no) as dp1lun2 from intranet2.dbo.in2 where year(bk1date)=@byy and bk1date between @edate1 and @edate2 and pl1no in (select dp1no from depcode where dp1lun=@dp1lun and dp1over<>'Y') group by year(bk1date),pl1no order by dp1lun2
				insert into #tmp (yy,pl1no,mon,dp1lun2) select year(bk1date),pl1no,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon,(select dp1lun2 from depcode as d where d.dp1no=pl1no) as dp1lun2 from intranet2.dbo.in2 where year(bk1date)=@eyy and bk1date between @bdate1 and @bdate2 and pl1no in (select dp1no from depcode where dp1lun=@dp1lun and dp1over<>'Y') group by year(bk1date),pl1no order by dp1lun2
			end
		end
	else
		begin
		if @dp1over='Y'
			begin
				insert into #tmp (yy,pl1no,mon,dp1lun2) select year(bk1date),pl1no,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon,(select dp1lun2 from depcode as d where d.dp1no=pl1no) as dp1lun2 from intranet2.dbo.in2 where year(bk1date)=@byy and bk1date between @edate1 and @edate2 and pl1no in (select dp1no from depcode where dp1lun=@dp1lun and dp1yn2<>'Y') group by year(bk1date),pl1no order by dp1lun2
				insert into #tmp (yy,pl1no,mon,dp1lun2) select year(bk1date),pl1no,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon,(select dp1lun2 from depcode as d where d.dp1no=pl1no) as dp1lun2 from intranet2.dbo.in2 where year(bk1date)=@eyy and bk1date between @bdate1 and @bdate2 and pl1no in (select dp1no from depcode where dp1lun=@dp1lun and dp1yn2<>'Y') group by year(bk1date),pl1no order by dp1lun2
			end
		else
			begin
				insert into #tmp (yy,pl1no,mon,dp1lun2) select year(bk1date),pl1no,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon,(select dp1lun2 from depcode as d where d.dp1no=pl1no) as dp1lun2 from intranet2.dbo.in2 where year(bk1date)=@byy and bk1date between @edate1 and @edate2 and pl1no in (select dp1no from depcode where dp1lun=@dp1lun and dp1yn2<>'Y' and dp1over<>'Y') group by year(bk1date),pl1no order by dp1lun2
				insert into #tmp (yy,pl1no,mon,dp1lun2) select year(bk1date),pl1no,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon,(select dp1lun2 from depcode as d where d.dp1no=pl1no) as dp1lun2 from intranet2.dbo.in2 where year(bk1date)=@eyy and bk1date between @bdate1 and @bdate2 and pl1no in (select dp1no from depcode where dp1lun=@dp1lun and dp1yn2<>'Y' and dp1over<>'Y') group by year(bk1date),pl1no order by dp1lun2
			end
		end
	end
  select yy,dp1lun2,sum(mon) as mon,(select lu1name from intranet.dbo.lu1 where lu1.lu1no=dp1lun2) as lu1name from #tmp where dp1lun2 is not null and dp1lun2 in (select lu1no from rg5lu1 where pe1no=@pe1no)  group by yy,dp1lun2 order by yy,dp1lun2
  drop table #tmp
end
else
begin
  create table #tmp2 (yy char(4),pl1no char(4),mon decimal(12, 0),dp1lun2 char(2))
  if @dp1lun='A'
  begin
	if @dp1yn2='Y'
	begin
		if @dp1over='Y'
			begin
				insert into #tmp2 (yy,pl1no,mon,dp1lun2) select year(bk1date),pl1no,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon,(select dp1lun2 from depcode as d where d.dp1no=pl1no) as dp1lun2 from intranet2.dbo.in2 where year(bk1date)=@byy and bk1date between @edate1 and @edate2 group by year(bk1date),pl1no order by dp1lun2
				insert into #tmp2 (yy,pl1no,mon,dp1lun2) select year(bk1date),pl1no,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon,(select dp1lun2 from depcode as d where d.dp1no=pl1no) as dp1lun2 from intranet2.dbo.in2 where year(bk1date)=@eyy and bk1date between @bdate1 and @bdate2 group by year(bk1date),pl1no order by dp1lun2
			end
		else
			begin
				insert into #tmp2 (yy,pl1no,mon,dp1lun2) select year(bk1date),pl1no,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon,(select dp1lun2 from depcode as d where d.dp1no=pl1no) as dp1lun2 from intranet2.dbo.in2 where year(bk1date)=@byy and bk1date between @edate1 and @edate2 and pl1no in (select dp1no from depcode where dp1over<>'Y') group by year(bk1date),pl1no order by dp1lun2
				insert into #tmp2 (yy,pl1no,mon,dp1lun2) select year(bk1date),pl1no,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon,(select dp1lun2 from depcode as d where d.dp1no=pl1no) as dp1lun2 from intranet2.dbo.in2 where year(bk1date)=@eyy and bk1date between @bdate1 and @bdate2 and pl1no in (select dp1no from depcode where dp1over<>'Y') group by year(bk1date),pl1no order by dp1lun2
			end
	end
	  else
	  begin
		if @dp1over='Y'
			begin
				insert into #tmp2 (yy,pl1no,mon,dp1lun2) select year(bk1date),pl1no,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon,(select dp1lun2 from depcode as d where d.dp1no=pl1no) as dp1lun2 from intranet2.dbo.in2 where year(bk1date)=@byy and bk1date between @edate1 and @edate2 and pl1no in (select dp1no from intranet.dbo.depcode where dp1yn2<>'Y') group by year(bk1date),pl1no order by dp1lun2
				insert into #tmp2 (yy,pl1no,mon,dp1lun2) select year(bk1date),pl1no,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon,(select dp1lun2 from depcode as d where d.dp1no=pl1no) as dp1lun2 from intranet2.dbo.in2 where year(bk1date)=@eyy and bk1date between @bdate1 and @bdate2 and pl1no in (select dp1no from intranet.dbo.depcode where dp1yn2<>'Y') group by year(bk1date),pl1no order by dp1lun2
			end
		else
			begin
				insert into #tmp2 (yy,pl1no,mon,dp1lun2) select year(bk1date),pl1no,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon,(select dp1lun2 from depcode as d where d.dp1no=pl1no) as dp1lun2 from intranet2.dbo.in2 where year(bk1date)=@byy and bk1date between @edate1 and @edate2 and pl1no in (select dp1no from intranet.dbo.depcode where dp1yn2<>'Y' and dp1over<>'Y') group by year(bk1date),pl1no order by dp1lun2
				insert into #tmp2 (yy,pl1no,mon,dp1lun2) select year(bk1date),pl1no,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon,(select dp1lun2 from depcode as d where d.dp1no=pl1no) as dp1lun2 from intranet2.dbo.in2 where year(bk1date)=@eyy and bk1date between @bdate1 and @bdate2 and pl1no in (select dp1no from intranet.dbo.depcode where dp1yn2<>'Y' and dp1over<>'Y') group by year(bk1date),pl1no order by dp1lun2
			end
	  end
  end
  --------------------------------------
  else
  begin
	if @dp1yn2='Y'
	  begin
		if @dp1over='Y'
		begin
			insert into #tmp2 (yy,pl1no,mon,dp1lun2) select year(bk1date),pl1no,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon,(select dp1lun2 from depcode as d where d.dp1no=pl1no) as dp1lun2 from intranet2.dbo.in2 where year(bk1date)=@byy and bk1date between @edate1 and @edate2 and pl1no in (select dp1no from intranet.dbo.depcode where dp1lun=@dp1lun ) group by year(bk1date),pl1no order by dp1lun2
			insert into #tmp2 (yy,pl1no,mon,dp1lun2) select year(bk1date),pl1no,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon,(select dp1lun2 from depcode as d where d.dp1no=pl1no) as dp1lun2 from intranet2.dbo.in2 where year(bk1date)=@eyy and bk1date between @bdate1 and @bdate2 and pl1no in (select dp1no from intranet.dbo.depcode where dp1lun=@dp1lun) group by year(bk1date),pl1no order by dp1lun2
		end
		else
		begin
			insert into #tmp2 (yy,pl1no,mon,dp1lun2) select year(bk1date),pl1no,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon,(select dp1lun2 from depcode as d where d.dp1no=pl1no) as dp1lun2 from intranet2.dbo.in2 where year(bk1date)=@byy and bk1date between @edate1 and @edate2 and pl1no in (select dp1no from intranet.dbo.depcode where dp1lun=@dp1lun and dp1over<>'Y') group by year(bk1date),pl1no order by dp1lun2
			insert into #tmp2 (yy,pl1no,mon,dp1lun2) select year(bk1date),pl1no,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon,(select dp1lun2 from depcode as d where d.dp1no=pl1no) as dp1lun2 from intranet2.dbo.in2 where year(bk1date)=@eyy and bk1date between @bdate1 and @bdate2 and pl1no in (select dp1no from intranet.dbo.depcode where dp1lun=@dp1lun and dp1over<>'Y') group by year(bk1date),pl1no order by dp1lun2
		end
	  end
	else
	  begin
	  if @dp1over='Y'
		begin
			insert into #tmp2 (yy,pl1no,mon,dp1lun2) select year(bk1date),pl1no,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon,(select dp1lun2 from depcode as d where d.dp1no=pl1no) as dp1lun2 from intranet2.dbo.in2 where year(bk1date)=@byy and bk1date between @edate1 and @edate2 and pl1no in (select dp1no from intranet.dbo.depcode where dp1lun=@dp1lun and dp1yn2<>'Y') group by year(bk1date),pl1no order by dp1lun2
			insert into #tmp2 (yy,pl1no,mon,dp1lun2) select year(bk1date),pl1no,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon,(select dp1lun2 from depcode as d where d.dp1no=pl1no) as dp1lun2 from intranet2.dbo.in2 where year(bk1date)=@eyy and bk1date between @bdate1 and @bdate2 and pl1no in (select dp1no from intranet.dbo.depcode where dp1lun=@dp1lun and dp1yn2<>'Y') group by year(bk1date),pl1no order by dp1lun2
		end
	  else
		begin
			insert into #tmp2 (yy,pl1no,mon,dp1lun2) select year(bk1date),pl1no,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon,(select dp1lun2 from depcode as d where d.dp1no=pl1no) as dp1lun2 from intranet2.dbo.in2 where year(bk1date)=@byy and bk1date between @edate1 and @edate2 and pl1no in (select dp1no from intranet.dbo.depcode where dp1lun=@dp1lun and dp1yn2<>'Y' and dp1over<>'Y') group by year(bk1date),pl1no order by dp1lun2
			insert into #tmp2 (yy,pl1no,mon,dp1lun2) select year(bk1date),pl1no,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon,(select dp1lun2 from depcode as d where d.dp1no=pl1no) as dp1lun2 from intranet2.dbo.in2 where year(bk1date)=@eyy and bk1date between @bdate1 and @bdate2 and pl1no in (select dp1no from intranet.dbo.depcode where dp1lun=@dp1lun and dp1yn2<>'Y' and dp1over<>'Y') group by year(bk1date),pl1no order by dp1lun2
		end
	  end
  end
  select yy,dp1lun2,sum(mon) as mon,(select lu1name from intranet.dbo.lu1 where lu1.lu1no=dp1lun2) as lu1name from #tmp2 where dp1lun2 is not null and dp1lun2 in (select lu1no from rg5lu1 where pe1no=@pe1no)  group by yy,dp1lun2 order by yy,dp1lun2
  drop table #tmp2
end

END
go

