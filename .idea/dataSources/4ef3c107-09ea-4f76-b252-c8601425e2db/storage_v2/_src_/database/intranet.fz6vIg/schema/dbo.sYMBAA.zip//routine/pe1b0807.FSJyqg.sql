-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[pe1b0807] (@nowno char(9),@byy char(4),@pl1no char(4))
AS
BEGIN
declare @yy char(3),@nyy int
	SET NOCOUNT ON;
set @yy=cast( (cast(@byy as int)-1911) as char(3))
set @nyy=cast(@byy as int)
delete from intra3.dbo.pe1_b0807 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
if @pl1no<>''
begin
	if @pl1no='TOP '
	begin
		insert into intra3.dbo.pe1_b0807 (nowno,pe1no,usrname,po1no,po2no,pf1ari,pl1no,pw1a) select @nowno,usr.usrno,usr.usrname,usr.post,usr.po2no,usr.pf1ari,pw1.pl1no,pw1.pw1a FROM usr,pw1 where usr.usrno=pw1.pe1no and usr.pf1lef is null  and usr.dep=@pl1no order by usr.po2no
		insert into intra3.dbo.pe1_b0807 (nowno,pe1no,usrname,po1no,po2no,pf1ari,pl1no,pw1a) select @nowno,usr.usrno,usr.usrname,usr.post,usr.po2no,usr.pf1ari,pw2.pl1no,pw2.pw1a FROM usr,pw2 where usr.usrno=pw2.pe1no and usr.pf1lef is null  and left(usr.dep,3)='TOP' and left(pw2.pl1no,3)='TOP' order by usr.po2no
	end
	else
	begin
		insert into intra3.dbo.pe1_b0807 (nowno,pe1no,usrname,po1no,po2no,pf1ari,pl1no,pw1a) select @nowno,usr.usrno,usr.usrname,usr.post,usr.po2no,usr.pf1ari,pw2.pl1no,pw2.pw1a FROM usr,pw2 where usr.usrno=pw2.pe1no and usr.pf1lef is null and usr.dep=@pl1no and pw2.pl1no=@pl1no order by usr.po2no
	end
end
else
begin
	insert into intra3.dbo.pe1_b0807 (nowno,pe1no,usrname,po1no,po2no,pf1ari,pl1no,pw1a) select @nowno,usr.usrno,usr.usrname,usr.post,usr.po2no,usr.pf1ari,pw1.pl1no,pw1.pw1a FROM usr,pw1 where usr.usrno=pw1.pe1no and usr.pf1lef is null  and usr.dep='TOP ' order by usr.po2no
	insert into intra3.dbo.pe1_b0807 (nowno,pe1no,usrname,po1no,po2no,pf1ari,pl1no,pw1a) select @nowno,usr.usrno,usr.usrname,usr.post,usr.po2no,usr.pf1ari,pw2.pl1no,pw2.pw1a FROM usr,pw2 where usr.usrno=pw2.pe1no and usr.pf1lef is null and usr.dep=pw2.pl1no and (usr.dep in (select dp1no from depcode where dp1lun='T') or usr.pf1lun<>'Y') order by usr.po2no
end
update intra3.dbo.pe1_b0807 set dp1lun2=(select dp1lun2 from depcode as d where d.dp1no=intra3.dbo.pe1_b0807.pl1no) where nowno=@nowno
update intra3.dbo.pe1_b0807 set po1name=(select po1name from postcode as p where p.po1no=intra3.dbo.pe1_b0807.po1no ) where nowno=@nowno
update intra3.dbo.pe1_b0807 set po2name=(select po2name from po2 as p where p.po2no=intra3.dbo.pe1_b0807.po2no ) where nowno=@nowno
if @nyy>0
begin
	update intra3.dbo.pe1_b0807 set km1add1=(select km1add1 from km1 where km1.usrno=pe1no and km1yy=@yy) where nowno=@nowno
	update intra3.dbo.pe1_b0807 set km1add2=(select km1add2 from km1 where km1.usrno=pe1no and km1yy=@yy) where nowno=@nowno
	update intra3.dbo.pe1_b0807 set km1sub=(select km1sub from km1 where km1.usrno=pe1no and km1yy=@yy) where nowno=@nowno
	update intra3.dbo.pe1_b0807 set km1add1=0 where km1add1 is null
	update intra3.dbo.pe1_b0807 set km1add2=0 where km1add2 is null
	update intra3.dbo.pe1_b0807 set km1sub=0 where km1sub is null
end
--delete from intra3.dbo.pe1_b0807 where nowno=@nowno and year(pf1ari)>@byy
--select * from intra3.dbo.pe1_b0807 where nowno=@nowno order by dp1lun2,pl1no,pe1no
END
go

