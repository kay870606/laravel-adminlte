CREATE VIEW dbo.on1rpt
AS
SELECT          dbo.on2.on1no, dbo.on2.on2memo, dbo.on2.on2pl1no, dbo.on2.on2type, dbo.on2.on2class, dbo.on2.on2memo2, 
                            dbo.usr.usrname, dbo.po2.po2name
FROM              dbo.on2 INNER JOIN
                            dbo.usr ON dbo.on2.on2pe1 = dbo.usr.usrno INNER JOIN
                            dbo.po2 ON dbo.on2.on2po2 = dbo.po2.po2no
go

