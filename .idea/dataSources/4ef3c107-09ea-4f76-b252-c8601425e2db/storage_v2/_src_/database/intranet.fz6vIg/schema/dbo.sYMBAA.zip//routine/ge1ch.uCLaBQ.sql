-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[ge1ch] (@type2 char(1),@pl1no char(4),@ge1no char(5),@ge1no2 char(5),@idate3 char(10))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	declare @gl1sum decimal(9, 4)

	if (select object_id('tempdb..#tmp1'))is not null
	begin
		drop table #tmp1;
	end
	if (select object_id('tempdb..#tmp2'))is not null
	begin
		drop table #tmp2;
	end
	if (select object_id('tempdb..#tmp3'))is not null
	begin
		drop table #tmp3;
	end
	if (select object_id('tempdb..#tmp4'))is not null
	begin
		drop table #tmp4;
	end
	if (select object_id('tempdb..#tmp5'))is not null
	begin
		drop table #tmp5;
	end
	
delete from intra3.dbo.ge1ch

--if @type2='5'  ------where 單店 單股東
---全部都用單店單股東
insert into intra3.dbo.ge1ch (ge1no,pl1no,gl1pi1,gl1pi4,gl1pia,gl1pi2,gl1pi3,gl1pi5,gl1pi6,gl1pi7,gl1pi8,gl1pib,nowno) select ge1no,pl1no,gl1bpi1,gl1bpi4,gl1bpia,gl1bpi2,gl1bpi3,gl1bpi5,gl1bpi6,gl1bpi7,gl1bpi8,gl1bpib,gl1num from gl1 where pl1no=@pl1no and ge1no in (@ge1no,@ge1no2)

--insert into intra3.dbo.ge1ch (ge1no,pl1no,gl1pi1,gl1pi4,gl1pia,gl1pi2,gl1pi3,gl1pi5,gl1pi6,gl1pi7,gl1pi8,gl1pib,nowno) select ge1no,pl1no,gl1bpi1,gl1bpi4,gl1bpia,gl1bpi2,gl1bpi3,gl1bpi5,gl1bpi6,gl1bpi7,gl1bpi8,gl1bpib,gl1num from gl1

-------------------股東轉售 (釋出)
create table #tmp1 (ge1no_1 char(5),pl1no_1 char(4),gp1type_1 char(1),gp1pi_1 decimal(9, 4))
if @type2='4'   ----給股數新增用的  股數新增時 可能是釋出股東 所以要 where ge1no=@ge1no
	insert into #tmp1 (ge1no_1,pl1no_1,gp1type_1,gp1pi_1) select ge1no,pl1no,gp1type,sum(gp1pi) as gp1pi from gp1 where pl1no=@pl1no and ge1no=@ge1no and gp1date>=@idate3 group by ge1no,pl1no,gp1type order by ge1no
if @type2='5'   ----給股數轉售用的  where ge1no in (@ge1no,@ge1no2) 2個股東可能都有釋出股數
	insert into #tmp1 (ge1no_1,pl1no_1,gp1type_1,gp1pi_1) select ge1no,pl1no,gp1type,sum(gp1pi) as gp1pi from gp1 where pl1no=@pl1no and ge1no in (@ge1no,@ge1no2) and gp1date>=@idate3 group by ge1no,pl1no,gp1type order by ge1no
if @type2='6'   ----不使用
	insert into #tmp1 (ge1no_1,pl1no_1,gp1type_1,gp1pi_1) select ge1no,pl1no,gp1type,sum(gp1pi) as gp1pi from gp1 where gp1date>=@idate3 group by ge1no,pl1no,gp1type order by ge1no
if @type2='7'   ----不使用
	insert into #tmp1 (ge1no_1,pl1no_1,gp1type_1,gp1pi_1) select ge1no,pl1no,gp1type,sum(gp1pi) as gp1pi from gp1 where ge1no=@ge1no and gp1date>=@idate3 group by ge1no,pl1no,gp1type order by ge1no
update intra3.dbo.ge1ch set gl1pi1=gl1pi1-gp1pi_1 from #tmp1 where gp1type_1='1' and intra3.dbo.ge1ch.ge1no=ge1no_1 and intra3.dbo.ge1ch.pl1no=pl1no_1
update intra3.dbo.ge1ch set gl1pi4=gl1pi4-gp1pi_1 from #tmp1 where gp1type_1='2' and intra3.dbo.ge1ch.ge1no=ge1no_1 and intra3.dbo.ge1ch.pl1no=pl1no_1
update intra3.dbo.ge1ch set gl1pia=gl1pia-gp1pi_1 from #tmp1 where gp1type_1='3' and intra3.dbo.ge1ch.ge1no=ge1no_1 and intra3.dbo.ge1ch.pl1no=pl1no_1
update intra3.dbo.ge1ch set gl1pi2=gl1pi2-gp1pi_1 from #tmp1 where gp1type_1='4' and intra3.dbo.ge1ch.ge1no=ge1no_1 and intra3.dbo.ge1ch.pl1no=pl1no_1
update intra3.dbo.ge1ch set gl1pi3=gl1pi3-gp1pi_1 from #tmp1 where gp1type_1='5' and intra3.dbo.ge1ch.ge1no=ge1no_1 and intra3.dbo.ge1ch.pl1no=pl1no_1
update intra3.dbo.ge1ch set gl1pi5=gl1pi5-gp1pi_1 from #tmp1 where gp1type_1='6' and intra3.dbo.ge1ch.ge1no=ge1no_1 and intra3.dbo.ge1ch.pl1no=pl1no_1
update intra3.dbo.ge1ch set gl1pi6=gl1pi6-gp1pi_1 from #tmp1 where gp1type_1='7' and intra3.dbo.ge1ch.ge1no=ge1no_1 and intra3.dbo.ge1ch.pl1no=pl1no_1
update intra3.dbo.ge1ch set gl1pi7=gl1pi7-gp1pi_1 from #tmp1 where gp1type_1='8' and intra3.dbo.ge1ch.ge1no=ge1no_1 and intra3.dbo.ge1ch.pl1no=pl1no_1
update intra3.dbo.ge1ch set gl1pi8=gl1pi8+gp1pi_1 from #tmp1 where gp1type_1='9' and intra3.dbo.ge1ch.ge1no=ge1no_1 and intra3.dbo.ge1ch.pl1no=pl1no_1
drop table #tmp1
-------------------股東轉售 (承購)
create table #tmp2 (ge1no_2 char(5),pl1no_2 char(4),gp1type_2 char(1),gp1pi_2 decimal(9, 4))
if @type2='4'  ----給股數新增用的  股數新增時 可能是承購股東 所以要 where ge1no2=@ge1no
	insert into #tmp2 (ge1no_2,pl1no_2,gp1type_2,gp1pi_2) select ge1no2,pl1no,gp1type2,sum(gp1pi)as gp1pi from gp1 where pl1no=@pl1no and ge1no2=@ge1no and gp1date>=@idate3 group by ge1no2,pl1no,gp1type2 order by ge1no2
if @type2='5'  ----給股數轉售用的  where ge1no2 in (@ge1no,@ge1no2) 2個股東可能都有承購股數
	insert into #tmp2 (ge1no_2,pl1no_2,gp1type_2,gp1pi_2) select ge1no2,pl1no,gp1type2,sum(gp1pi)as gp1pi from gp1 where pl1no=@pl1no and ge1no2 in (@ge1no2,@ge1no) and gp1date>=@idate3 group by ge1no2,pl1no,gp1type2 order by ge1no2
if @type2='6'----不使用
	insert into #tmp2 (ge1no_2,pl1no_2,gp1type_2,gp1pi_2) select ge1no2,pl1no,gp1type2,sum(gp1pi)as gp1pi from gp1 where gp1date>=@idate3 group by ge1no2,pl1no,gp1type2 order by ge1no2
if @type2='7'----不使用
	insert into #tmp2(ge1no_2,pl1no_2,gp1type_2,gp1pi_2) select ge1no2,pl1no,gp1type2,sum(gp1pi)as gp1pi from gp1 where ge1no2=@ge1no2 and gp1date>=@idate3 group by ge1no2,pl1no,gp1type2 order by ge1no2
update intra3.dbo.ge1ch set gl1pi1=gl1pi1+gp1pi_2 from #tmp2 where gp1type_2='1' and intra3.dbo.ge1ch.ge1no=ge1no_2 and intra3.dbo.ge1ch.pl1no=pl1no_2
update intra3.dbo.ge1ch set gl1pi4=gl1pi4+gp1pi_2 from #tmp2 where gp1type_2='2' and intra3.dbo.ge1ch.ge1no=ge1no_2 and intra3.dbo.ge1ch.pl1no=pl1no_2
update intra3.dbo.ge1ch set gl1pia=gl1pia+gp1pi_2 from #tmp2 where gp1type_2='3' and intra3.dbo.ge1ch.ge1no=ge1no_2 and intra3.dbo.ge1ch.pl1no=pl1no_2
update intra3.dbo.ge1ch set gl1pi2=gl1pi2+gp1pi_2 from #tmp2 where gp1type_2='4' and intra3.dbo.ge1ch.ge1no=ge1no_2 and intra3.dbo.ge1ch.pl1no=pl1no_2
update intra3.dbo.ge1ch set gl1pi3=gl1pi3+gp1pi_2 from #tmp2 where gp1type_2='5' and intra3.dbo.ge1ch.ge1no=ge1no_2 and intra3.dbo.ge1ch.pl1no=pl1no_2
update intra3.dbo.ge1ch set gl1pi5=gl1pi5+gp1pi_2 from #tmp2 where gp1type_2='6' and intra3.dbo.ge1ch.ge1no=ge1no_2 and intra3.dbo.ge1ch.pl1no=pl1no_2
update intra3.dbo.ge1ch set gl1pi6=gl1pi6+gp1pi_2 from #tmp2 where gp1type_2='7' and intra3.dbo.ge1ch.ge1no=ge1no_2 and intra3.dbo.ge1ch.pl1no=pl1no_2
update intra3.dbo.ge1ch set gl1pi7=gl1pi7+gp1pi_2 from #tmp2 where gp1type_2='8' and intra3.dbo.ge1ch.ge1no=ge1no_2 and intra3.dbo.ge1ch.pl1no=pl1no_2
update intra3.dbo.ge1ch set gl1pi8=gl1pi8+gp1pi_2 from #tmp2 where gp1type_2='9' and intra3.dbo.ge1ch.ge1no=ge1no_2 and intra3.dbo.ge1ch.pl1no=pl1no_2
drop table #tmp2
-------------------股東放棄 **不使用
/*create table #tmp3 (ge1no_3 char(5),pl1no_3 char(4),gp2type_3 char(1),gp2pi_3 decimal(9, 4))
--if @type2='2'
--	insert into #tmp3(ge1no_3,pl1no_3,gp2type_3,gp2pi_3) select ge1no,pl1no,gp2type,sum(gp2pi)as gp2pi from gp2 where pl1no=@pl1no and ge1no=@ge1no and gp2date>=@idate3 group by ge1no,pl1no,gp2type order by ge1no
if @type2='5'
	insert into #tmp3(ge1no_3,pl1no_3,gp2type_3,gp2pi_3) select ge1no,pl1no,gp2type,sum(gp2pi)as gp2pi from gp2 where pl1no=@pl1no and gp2date>=@idate3 group by ge1no,pl1no,gp2type order by ge1no
if @type2='6'
	insert into #tmp3(ge1no_3,pl1no_3,gp2type_3,gp2pi_3) select ge1no,pl1no,gp2type,sum(gp2pi)as gp2pi from gp2 where gp2date>=@idate3 group by ge1no,pl1no,gp2type order by ge1no	
if @type2='7'
	insert into #tmp3(ge1no_3,pl1no_3,gp2type_3,gp2pi_3) select ge1no,pl1no,gp2type,sum(gp2pi)as gp2pi from gp2 where ge1no=@ge1no and gp2date>=@idate3 group by ge1no,pl1no,gp2type order by ge1no
update intra3.dbo.ge1ch set gl1pi1=gl1pi1-gp2pi_3 from #tmp3 where gp2type_3='1' and intra3.dbo.ge1ch.ge1no=ge1no_3 and intra3.dbo.ge1ch.pl1no=pl1no_3
update intra3.dbo.ge1ch set gl1pi4=gl1pi4-gp2pi_3 from #tmp3 where gp2type_3='2' and intra3.dbo.ge1ch.ge1no=ge1no_3 and intra3.dbo.ge1ch.pl1no=pl1no_3
update intra3.dbo.ge1ch set gl1pia=gl1pia-gp2pi_3 from #tmp3 where gp2type_3='3' and intra3.dbo.ge1ch.ge1no=ge1no_3 and intra3.dbo.ge1ch.pl1no=pl1no_3
update intra3.dbo.ge1ch set gl1pi2=gl1pi2-gp2pi_3 from #tmp3 where gp2type_3='4' and intra3.dbo.ge1ch.ge1no=ge1no_3 and intra3.dbo.ge1ch.pl1no=pl1no_3
update intra3.dbo.ge1ch set gl1pi3=gl1pi3-gp2pi_3 from #tmp3 where gp2type_3='5' and intra3.dbo.ge1ch.ge1no=ge1no_3 and intra3.dbo.ge1ch.pl1no=pl1no_3
update intra3.dbo.ge1ch set gl1pi5=gl1pi5-gp2pi_3 from #tmp3 where gp2type_3='6' and intra3.dbo.ge1ch.ge1no=ge1no_3 and intra3.dbo.ge1ch.pl1no=pl1no_3
update intra3.dbo.ge1ch set gl1pi6=gl1pi6-gp2pi_3 from #tmp3 where gp2type_3='7' and intra3.dbo.ge1ch.ge1no=ge1no_3 and intra3.dbo.ge1ch.pl1no=pl1no_3
update intra3.dbo.ge1ch set gl1pi7=gl1pi7-gp2pi_3 from #tmp3 where gp2type_3='8' and intra3.dbo.ge1ch.ge1no=ge1no_3 and intra3.dbo.ge1ch.pl1no=pl1no_3
update intra3.dbo.ge1ch set gl1pi8=gl1pi8+gp2pi_3 from #tmp3 where intra3.dbo.ge1ch.ge1no=ge1no_3 and intra3.dbo.ge1ch.pl1no=pl1no_3
drop table #tmp3
*/
-------------------股東收回 **不使用
/*create table #tmp4 (ge1no_4 char(5),pl1no_4 char(4),gp3type_4 char(1),gp3pi_4 decimal(9, 4))
--if @type2='3'
--	insert into #tmp4(ge1no_4,pl1no_4,gp3type_4,gp3pi_4) select ge1no,pl1no,gp3type,sum(gp3pi)as gp3pi from gp3 where pl1no=@pl1no and ge1no=@ge1no and gp3date>=@idate3 group by pl1no,ge1no,gp3type order by ge1no
if @type2='5'
	insert into #tmp4(ge1no_4,pl1no_4,gp3type_4,gp3pi_4) select ge1no,pl1no,gp3type,sum(gp3pi)as gp3pi from gp3 where pl1no=@pl1no and gp3date>=@idate3 group by ge1no,pl1no,gp3type order by ge1no
if @type2='6'
	insert into #tmp4(ge1no_4,pl1no_4,gp3type_4,gp3pi_4) select ge1no,pl1no,gp3type,sum(gp3pi)as gp3pi from gp3 where gp3date>=@idate3 group by pl1no,ge1no,gp3type order by ge1no
if @type2='7'
	insert into #tmp4(ge1no_4,pl1no_4,gp3type_4,gp3pi_4) select ge1no,pl1no,gp3type,sum(gp3pi)as gp3pi from gp3 where ge1no=@ge1no and gp3date>=@idate3 group by pl1no,ge1no,gp3type order by ge1no
update intra3.dbo.ge1ch set gl1pi1=gl1pi1-gp3pi_4 from #tmp4 where gp3type_4='1' and intra3.dbo.ge1ch.ge1no=ge1no_4 and intra3.dbo.ge1ch.pl1no=pl1no_4
update intra3.dbo.ge1ch set gl1pi4=gl1pi4-gp3pi_4 from #tmp4 where gp3type_4='2' and intra3.dbo.ge1ch.ge1no=ge1no_4 and intra3.dbo.ge1ch.pl1no=pl1no_4
update intra3.dbo.ge1ch set gl1pia=gl1pia-gp3pi_4 from #tmp4 where gp3type_4='3' and intra3.dbo.ge1ch.ge1no=ge1no_4 and intra3.dbo.ge1ch.pl1no=pl1no_4
update intra3.dbo.ge1ch set gl1pi2=gl1pi2-gp3pi_4 from #tmp4 where gp3type_4='4' and intra3.dbo.ge1ch.ge1no=ge1no_4 and intra3.dbo.ge1ch.pl1no=pl1no_4
update intra3.dbo.ge1ch set gl1pi3=gl1pi3-gp3pi_4 from #tmp4 where gp3type_4='5' and intra3.dbo.ge1ch.ge1no=ge1no_4 and intra3.dbo.ge1ch.pl1no=pl1no_4
update intra3.dbo.ge1ch set gl1pi5=gl1pi5-gp3pi_4 from #tmp4 where gp3type_4='6' and intra3.dbo.ge1ch.ge1no=ge1no_4 and intra3.dbo.ge1ch.pl1no=pl1no_4
update intra3.dbo.ge1ch set gl1pi6=gl1pi6-gp3pi_4 from #tmp4 where gp3type_4='7' and intra3.dbo.ge1ch.ge1no=ge1no_4 and intra3.dbo.ge1ch.pl1no=pl1no_4
update intra3.dbo.ge1ch set gl1pi7=gl1pi7-gp3pi_4 from #tmp4 where gp3type_4='8' and intra3.dbo.ge1ch.ge1no=ge1no_4 and intra3.dbo.ge1ch.pl1no=pl1no_4
update intra3.dbo.ge1ch set gl1pi8=gl1pi8-gp3pi_4 from #tmp4 where gp3type_4='9' and intra3.dbo.ge1ch.ge1no=ge1no_4 and intra3.dbo.ge1ch.pl1no=pl1no_4
drop table #tmp4
*/
-------------------現場新增股數
create table #tmp5 (ge1no_5 char(5),pl1no_5 char(4),gp4type_5 char(1),gp4pi_5 decimal(9, 4),gp4type3_5 char(1))
if @type2='4'
	insert into #tmp5 (ge1no_5,pl1no_5,gp4type_5,gp4pi_5,gp4type3_5) select ge1no,pl1no,gp4type,sum(gp4pi)as gp4pi,gp4type3 from gp4 where pl1no=@pl1no and ge1no=@ge1no and gp4date>=@idate3 group by ge1no,pl1no,gp4type,gp4type3 order by ge1no
if @type2='5'
	insert into #tmp5 (ge1no_5,pl1no_5,gp4type_5,gp4pi_5,gp4type3_5) select ge1no,pl1no,gp4type,sum(gp4pi)as gp4pi,gp4type3 from gp4 where pl1no=@pl1no and ge1no in (@ge1no,@ge1no2) and gp4date>=@idate3 group by ge1no,pl1no,gp4type,gp4type3 order by ge1no
if @type2='6'  ----不使用
	insert into #tmp5 (ge1no_5,pl1no_5,gp4type_5,gp4pi_5,gp4type3_5) select ge1no,pl1no,gp4type,sum(gp4pi)as gp4pi,gp4type3 from gp4 where gp4date>=@idate3 group by ge1no,pl1no,gp4type,gp4type3 order by ge1no
if @type2='7'  ----不使用
	insert into #tmp5 (ge1no_5,pl1no_5,gp4type_5,gp4pi_5,gp4type3_5) select ge1no,pl1no,gp4type,sum(gp4pi)as gp4pi,gp4type3 from gp4 where ge1no=@ge1no and gp4date>=@idate3 group by ge1no,pl1no,gp4type,gp4type3 order by ge1no
----------------1.新股數
update intra3.dbo.ge1ch set gl1pi1=gl1pi1+gp4pi_5 from #tmp5 where gp4type3_5 ='1' and gp4type_5='D' and intra3.dbo.ge1ch.ge1no=ge1no_5 and intra3.dbo.ge1ch.pl1no=pl1no_5
update intra3.dbo.ge1ch set gl1pia=gl1pia+gp4pi_5 from #tmp5 where gp4type3_5 ='1' and gp4type_5='A' and intra3.dbo.ge1ch.ge1no=ge1no_5 and intra3.dbo.ge1ch.pl1no=pl1no_5
update intra3.dbo.ge1ch set gl1pi3=gl1pi3+gp4pi_5 from #tmp5 where gp4type3_5 ='1' and gp4type_5='F' and intra3.dbo.ge1ch.ge1no=ge1no_5 and intra3.dbo.ge1ch.pl1no=pl1no_5
update intra3.dbo.ge1ch set gl1pi5=gl1pi5+gp4pi_5 from #tmp5 where gp4type3_5 ='1' and gp4type_5='B' and intra3.dbo.ge1ch.ge1no=ge1no_5 and intra3.dbo.ge1ch.pl1no=pl1no_5
update intra3.dbo.ge1ch set gl1pi7=gl1pi7+gp4pi_5 from #tmp5 where gp4type3_5 ='1' and gp4type_5='C' and intra3.dbo.ge1ch.ge1no=ge1no_5 and intra3.dbo.ge1ch.pl1no=pl1no_5
update intra3.dbo.ge1ch set gl1pib=gl1pib+gp4pi_5 from #tmp5 where gp4type3_5 ='1' and gp4type_5='E' and intra3.dbo.ge1ch.ge1no=ge1no_5 and intra3.dbo.ge1ch.pl1no=pl1no_5
----------------2.現場買回
update intra3.dbo.ge1ch set gl1pi1=gl1pi1-gp4pi_5 from #tmp5 where gp4type3_5 ='2' and gp4type_5='D' and intra3.dbo.ge1ch.ge1no=ge1no_5 and intra3.dbo.ge1ch.pl1no=pl1no_5
update intra3.dbo.ge1ch set gl1pia=gl1pia-gp4pi_5 from #tmp5 where gp4type3_5 ='2' and gp4type_5='A' and intra3.dbo.ge1ch.ge1no=ge1no_5 and intra3.dbo.ge1ch.pl1no=pl1no_5
update intra3.dbo.ge1ch set gl1pi3=gl1pi3-gp4pi_5 from #tmp5 where gp4type3_5 ='2' and gp4type_5='F' and intra3.dbo.ge1ch.ge1no=ge1no_5 and intra3.dbo.ge1ch.pl1no=pl1no_5
update intra3.dbo.ge1ch set gl1pi5=gl1pi5-gp4pi_5 from #tmp5 where gp4type3_5 ='2' and gp4type_5='B' and intra3.dbo.ge1ch.ge1no=ge1no_5 and intra3.dbo.ge1ch.pl1no=pl1no_5
update intra3.dbo.ge1ch set gl1pi7=gl1pi7-gp4pi_5 from #tmp5 where gp4type3_5 ='2' and gp4type_5='C' and intra3.dbo.ge1ch.ge1no=ge1no_5 and intra3.dbo.ge1ch.pl1no=pl1no_5
update intra3.dbo.ge1ch set gl1pib=gl1pib-gp4pi_5 from #tmp5 where gp4type3_5 ='2' and gp4type_5='E' and intra3.dbo.ge1ch.ge1no=ge1no_5 and intra3.dbo.ge1ch.pl1no=pl1no_5
----------------D.股東放棄
update intra3.dbo.ge1ch set gl1pi1=gl1pi1-gp4pi_5 from #tmp5 where gp4type3_5 ='D' and gp4type_5='D' and intra3.dbo.ge1ch.ge1no=ge1no_5 and intra3.dbo.ge1ch.pl1no=pl1no_5
update intra3.dbo.ge1ch set gl1pia=gl1pia-gp4pi_5 from #tmp5 where gp4type3_5 ='D' and gp4type_5='A' and intra3.dbo.ge1ch.ge1no=ge1no_5 and intra3.dbo.ge1ch.pl1no=pl1no_5
update intra3.dbo.ge1ch set gl1pi3=gl1pi3-gp4pi_5 from #tmp5 where gp4type3_5 ='D' and gp4type_5='F' and intra3.dbo.ge1ch.ge1no=ge1no_5 and intra3.dbo.ge1ch.pl1no=pl1no_5
update intra3.dbo.ge1ch set gl1pi5=gl1pi5-gp4pi_5 from #tmp5 where gp4type3_5 ='D' and gp4type_5='B' and intra3.dbo.ge1ch.ge1no=ge1no_5 and intra3.dbo.ge1ch.pl1no=pl1no_5
update intra3.dbo.ge1ch set gl1pi7=gl1pi7-gp4pi_5 from #tmp5 where gp4type3_5 ='D' and gp4type_5='C' and intra3.dbo.ge1ch.ge1no=ge1no_5 and intra3.dbo.ge1ch.pl1no=pl1no_5
update intra3.dbo.ge1ch set gl1pi8=gl1pi8+gp4pi_5 from #tmp5 where gp4type3_5 ='D' and intra3.dbo.ge1ch.ge1no=ge1no_5 and intra3.dbo.ge1ch.pl1no=pl1no_5
update intra3.dbo.ge1ch set gl1pib=gl1pib-gp4pi_5 from #tmp5 where gp4type3_5 ='D' and gp4type_5='E' and intra3.dbo.ge1ch.ge1no=ge1no_5 and intra3.dbo.ge1ch.pl1no=pl1no_5
----------------F.股份稀釋
update intra3.dbo.ge1ch set gl1pi1=gl1pi1-gp4pi_5 from #tmp5 where gp4type3_5 ='F' and gp4type_5='D' and intra3.dbo.ge1ch.ge1no=ge1no_5 and intra3.dbo.ge1ch.pl1no=pl1no_5
update intra3.dbo.ge1ch set gl1pia=gl1pia-gp4pi_5 from #tmp5 where gp4type3_5 ='F' and gp4type_5='A' and intra3.dbo.ge1ch.ge1no=ge1no_5 and intra3.dbo.ge1ch.pl1no=pl1no_5
update intra3.dbo.ge1ch set gl1pi3=gl1pi3-gp4pi_5 from #tmp5 where gp4type3_5 ='F' and gp4type_5='F' and intra3.dbo.ge1ch.ge1no=ge1no_5 and intra3.dbo.ge1ch.pl1no=pl1no_5
update intra3.dbo.ge1ch set gl1pi5=gl1pi5-gp4pi_5 from #tmp5 where gp4type3_5 ='F' and gp4type_5='B' and intra3.dbo.ge1ch.ge1no=ge1no_5 and intra3.dbo.ge1ch.pl1no=pl1no_5
update intra3.dbo.ge1ch set gl1pi7=gl1pi7-gp4pi_5 from #tmp5 where gp4type3_5 ='F' and gp4type_5='C' and intra3.dbo.ge1ch.ge1no=ge1no_5 and intra3.dbo.ge1ch.pl1no=pl1no_5
update intra3.dbo.ge1ch set gl1pi8=gl1pi8+gp4pi_5 from #tmp5 where gp4type3_5 ='F' and intra3.dbo.ge1ch.ge1no=ge1no_5 and intra3.dbo.ge1ch.pl1no=pl1no_5
update intra3.dbo.ge1ch set gl1pib=gl1pib-gp4pi_5 from #tmp5 where gp4type3_5 ='F' and gp4type_5='E' and intra3.dbo.ge1ch.ge1no=ge1no_5 and intra3.dbo.ge1ch.pl1no=pl1no_5
----------------E.乾股異動
update intra3.dbo.ge1ch set gl1pib=gl1pib+gp4pi_5 from #tmp5 where gp4type3_5 ='E' and gp4type_5='E' and intra3.dbo.ge1ch.ge1no=ge1no_5 and intra3.dbo.ge1ch.pl1no=pl1no_5
drop table #tmp5
update intra3.dbo.ge1ch set ge1no1=(select ge1no1 from ge1 where ge1no=intra3.dbo.ge1ch.ge1no)
----------------------------------------------------------------------------------------------------------------
-----******
update gl1 set gl1pi1=ge1ch.gl1pi1,gl1pi4=ge1ch.gl1pi4,gl1pia=ge1ch.gl1pia,gl1pi2=ge1ch.gl1pi2,gl1pi3=ge1ch.gl1pi3,gl1pi5=ge1ch.gl1pi5,gl1pi6=ge1ch.gl1pi6,gl1pi7=ge1ch.gl1pi7,gl1pi8=ge1ch.gl1pi8,gl1pib=ge1ch.gl1pib,gl1pi=ge1ch.gl1pi1+ge1ch.gl1pi2+ge1ch.gl1pi3+ge1ch.gl1pi4+ge1ch.gl1pi5+ge1ch.gl1pi6+ge1ch.gl1pi7+ge1ch.gl1pi9+ge1ch.gl1pia+ge1ch.gl1pib from intra3.dbo.ge1ch as ge1ch where gl1.pl1no=ge1ch.pl1no and gl1.ge1no=ge1ch.ge1no
select @gl1sum=sum(gl1pi1+gl1pi2+gl1pi3+gl1pi4+gl1pi5+gl1pi6+gl1pi7+gl1pi9+gl1pia) from gl1 where pl1no=@pl1no group by pl1no
update gl2 set gl1sum=@gl1sum where pl1no=@pl1no
END
go

