-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[be1_A0811] (@nowno char(9),@bb1no char(6),@dp1lun char(1),@bym char(4),@byy char(4),@top char(1))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
	if (select object_id('tempdb..#tmp2'))is not null
	begin
		drop table #tmp2;
	end
delete from intra3.dbo.be1_A0311 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)

if @top='Y'
 begin
 insert into intra3.dbo.be1_A0311 (nowno,pl1no,dp1lun,be1month,bb1no,bb1name,bb1eng,bh1num,be1price,bh1mac,bi1range,rate,bb1r1,bb1r2) select @nowno,pl1no,'T',(select be1month from intranet.dbo.depcode where DP1NO=intranet2.dbo.be1.pl1no) as be1month,bb1no,(select bb1name from intranet.dbo.bb1 where bb1no=@bb1no) as name,(select bb1eng from intranet.dbo.bb1 where bb1no=@bb1no) as eng,sum(be1qty),be1price,bh1mac,bi1range,rate,0,0 from intranet2.dbo.be1 where bh1ym=@bym and pl1no in (select DP1NO from intranet.dbo.depcode where dp1lun='T' and bb1no=@bb1no) and bb1id in (select bb1id from intranet.dbo.bc3n where pl1no='TOP' and bc3flag='A') group by pl1no,bb1no,be1price,bh1mac,bi1range,rate order by pl1no
 end
else
 begin

 if @dp1lun='A'
  begin
	insert into intra3.dbo.be1_A0311 (nowno,pl1no,dp1lun,be1month,bb1no,bb1name,bb1eng,bh1num,be1price,bh1mac,bi1range,rate,bb1r1,bb1r2) select @nowno,pl1no,(select dp1lun from intranet.dbo.depcode where DP1NO=intranet2.dbo.be1.pl1no) as lun,(select be1month from intranet.dbo.depcode where DP1NO=intranet2.dbo.be1.pl1no) as be1month,bb1no,(select bb1name from intranet.dbo.bb1 where bb1no=@bb1no) as name,(select bb1eng from intranet.dbo.bb1 where bb1no=@bb1no) as eng,sum(be1qty),be1price,bh1mac,bi1range,rate,0,0 from intranet2.dbo.be1 where bh1ym=@bym and pl1no in (select DP1NO from intranet.dbo.depcode where bb1no=@bb1no) group by pl1no,bb1no,be1price,bh1mac,bi1range,rate order by pl1no
	--update intra3.dbo.be1_A0311 set dp1lun=depcode.dp1lun from depcode join be1_A0811 on depcode.dp1no=be1_A0811.pl1no where nowno=@nowno
  end
else
  begin
	insert into intra3.dbo.be1_A0311 (nowno,pl1no,dp1lun,be1month,bb1no,bb1name,bb1eng,bh1num,be1price,bh1mac,bi1range,rate,bb1r1,bb1r2) select @nowno,pl1no,@dp1lun,(select be1month from intranet.dbo.depcode where DP1NO=intranet2.dbo.be1.pl1no) as be1month,bb1no,(select bb1name from intranet.dbo.bb1 where bb1no=@bb1no) as name,(select bb1eng from intranet.dbo.bb1 where bb1no=@bb1no) as eng,sum(be1qty),be1price,bh1mac,bi1range,rate,0,0 from intranet2.dbo.be1 where bh1ym=@bym and pl1no in (select DP1NO from intranet.dbo.depcode where dp1lun=@dp1lun and bb1no=@bb1no) group by pl1no,bb1no,be1price,bh1mac,bi1range,rate order by pl1no
  end

 end

 CREATE TABLE #tmp (pl1no2 char(4),bh1mac2 decimal(4, 0))
 CREATE TABLE #tmp2 (pl1no2 char(4),bi1range2 char(4),bh1num2 decimal(8, 0),dd decimal(4, 0)) 
  if @byy+RIGHT(@bym,2)>='201704'
  begin
  insert into #tmp (pl1no2) select pl1no from intra3.dbo.be1_A0311 where pl1no in(select dp1no from intranet.dbo.depcode where be1ok='Y' and be1month<=@byy+RIGHT(@bym,2)) group by pl1no
  update #tmp set bh1mac2=(select count(distinct(bb1id)) from intranet2.dbo.be1 where bb1no=@bb1no and bh1ym2=@byy+RIGHT(@bym,2) and pl1no=#tmp.pl1no2 and substring(intranet2.dbo.be1.bh1lst,7,1)<>'A') 
  update intra3.dbo.be1_A0311 set bh1mac=(select bh1mac2 from #tmp where pl1no2=pl1no) where nowno=@nowno and pl1no in (select pl1no2 from #tmp) and bb1no=@bb1no
   --修正起迄日期合併2018-03-07  若A0311有重複店號便修正
  insert into #tmp2 (pl1no2,dd,bh1num2) SELECT pl1no,(select ROUND(sum(cast (right(bi1range, 2)as decimal)- cast(left(bi1range ,2) as decimal)+1 )/(select top 1 bh1mac from intra3.dbo.be1_A0311 where nowno=@nowno and pl1no=a1.pl1no and bb1no=@bb1no),0) from intra3.dbo.be1_A0311 where nowno=@nowno and pl1no=a1.pl1no and bb1no=@bb1no) ,sum(bh1num) FROM intra3.dbo.be1_A0311 as a1 where nowno=@nowno and bb1no=@bb1no GROUP BY pl1no HAVING count(*)>1 
  update #tmp2 set bi1range2 = RIGHT(REPLICATE('0', 2) + CAST(( datediff(dd,@byy+'-'+RIGHT(@bym,2)+'-01',dateadd(mm,1,@byy+'-'+RIGHT(@bym,2)+'-01'))   - dd+1) as NVARCHAR), 2) +  CONVERT(varchar(2), datediff(dd,@byy+'-'+RIGHT(@bym,2)+'-01',dateadd(mm,1,@byy+'-'+RIGHT(@bym,2)+'-01')))    
  update intra3.dbo.be1_A0311 set bi1range=(select bi1range2 from #tmp2 where pl1no2=pl1no),bh1num=(select bh1num2 from #tmp2 where pl1no2=pl1no) where nowno=@nowno and bb1no=@bb1no and pl1no in(select pl1no2 from #tmp2)
  end
  drop table #tmp
  drop table #tmp2
END


go

