-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[pe1b0823] (@nowno char(9),@bdate datetime,@edate datetime,@pl1no char(4),@pe1no char(5),@order char(1))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

delete from intra3.dbo.pe1_b0823 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
insert into intra3.dbo.pe1_b0823 (nowno,pl1no,pe1no,ps1date,ps1ari,ps1type,pl1no2,usrname) 
	select @nowno,ps5.pl1no,ps5.pe1no,ps5.ps1date,ps5.ps1ari, CASE ps5.ps1flag WHEN 'A' THEN '外出' WHEN 'B' THEN '回公司' END,ps5.pl1no2,usr.usrname from ps5,usr where ps5.pe1no=usr.usrno and ps5.ps1date between @bdate and @edate order by ps5.pe1no
if @order='1'
begin
	select * from intra3.dbo.pe1_b0823 where nowno=@nowno order by ps1date,pe1no
end
else
begin
	select * from intra3.dbo.pe1_b0823 where nowno=@nowno order by pe1no,ps1date
end
END
go

