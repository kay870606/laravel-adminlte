-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[be1_A0810] (@nowno char(9),@pl1no char(4),@byy char(4),@bmm char(2),@edate datetime,@bb1no char(6))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	delete from intra3.dbo.be1_A0310 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
	if @edate is null
	  begin
	    if @bb1no=''
			insert into intra3.dbo.be1_A0310 (nowno,pl1no,bb1no,sg1date,bb1name,sg1qty)	select  @nowno,pl1no,bb1no,sg1date,(select bb1name from bb1 where bb1no=sg1s.bb1no) as bb1name,sg1qty from sg1s where pl1no=@pl1no and year(sg1date)=@byy and month(sg1date)=@bmm order by sg1date,sg1num
		else
			insert into intra3.dbo.be1_A0310 (nowno,pl1no,bb1no,sg1date,bb1name,sg1qty)	select  @nowno,pl1no,bb1no,sg1date,(select bb1name from bb1 where bb1no=sg1s.bb1no) as bb1name,sg1qty from sg1s where pl1no=@pl1no and year(sg1date)=@byy and month(sg1date)=@bmm and bb1no=@bb1no order by sg1date,sg1num
	  end
	else
	  begin
	    if @bb1no=''
			insert into intra3.dbo.be1_A0310 (nowno,pl1no,bb1no,sg1date,bb1name,sg1qty)	select  @nowno,pl1no,bb1no,sg1date,(select bb1name from bb1 where bb1no=sg1s.bb1no) as bb1name,sg1qty from sg1s where pl1no=@pl1no and year(sg1date)=@byy and month(sg1date)=@bmm and sg1date<=@edate order by sg1num
		else
			insert into intra3.dbo.be1_A0310 (nowno,pl1no,bb1no,sg1date,bb1name,sg1qty)	select  @nowno,pl1no,bb1no,sg1date,(select bb1name from bb1 where bb1no=sg1s.bb1no) as bb1name,sg1qty from sg1s where pl1no=@pl1no and year(sg1date)=@byy and month(sg1date)=@bmm and sg1date<=@edate and bb1no=@bb1no order by sg1num
	  end

END
go

