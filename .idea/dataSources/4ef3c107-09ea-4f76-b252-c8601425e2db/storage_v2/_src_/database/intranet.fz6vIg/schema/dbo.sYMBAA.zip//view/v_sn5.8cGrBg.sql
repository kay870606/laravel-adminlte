CREATE VIEW dbo.v_sn5
AS
SELECT     dbo.sn5.sn5no, dbo.sn5.sn5date, dbo.sn5.su1no, dbo.sn5.su1uno, dbo.sn5.su1tl, dbo.sn5.sn5month, dbo.sn5.sx1no, dbo.sn5.sn5memo, dbo.sn5.sn5mon, dbo.sn5.pu1ctax, dbo.sn5.pu2pi, 
                      dbo.sn5.pu2tax, dbo.sn6.sn6id, dbo.sn6.sn8qty, dbo.sn6.sn6memo, dbo.sn6.pt1mon, dbo.sn6.pt1price, dbo.sn6.pt1qty, dbo.sn6.sn1no
FROM         dbo.sn5 INNER JOIN
                      dbo.sn6 ON dbo.sn5.sn5no = dbo.sn6.sn5no
go

