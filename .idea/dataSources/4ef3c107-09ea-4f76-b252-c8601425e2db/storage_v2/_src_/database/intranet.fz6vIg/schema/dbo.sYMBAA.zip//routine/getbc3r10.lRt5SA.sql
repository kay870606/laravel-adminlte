-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[getbc3r10] (@nowno char(9),@pl1no char(4),@byy char(4),@bmm char(2),@emm char(2))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
	delete from intra3.dbo.bc3r10 where (nowno=@nowno and pl1no=@pl1no) or idate<CONVERT(nvarchar(30), GETDATE(), 111)
	select bc3.*,bb1.bb1name,bb1.bb1eng into #tmp from bc3n as bc3,bb1 where bc3.bb1no=bb1.bb1no and bc3.pl1no=@pl1no and year(bc3date2)=@byy and month(bc3date2) between @bmm and @emm and bc3.bc3flag='A'
	insert into intra3.dbo.bc3r10 (nowno,pl1no,bc3month,bb1no,bb1id,bb1name,bb1eng,bc1ser,bc1prc,bc1sum,bc3date2,bc1name,bc3memo) select @nowno,@pl1no,MONTH(bc3date2),bb1no,bb1id,bb1name,bb1eng,bc1ser,bc1prc,bc1ser*bc1prc,bc3date2,bc1name,bc3memo  from tempdb.#tmp
	drop table #tmp

END
go

