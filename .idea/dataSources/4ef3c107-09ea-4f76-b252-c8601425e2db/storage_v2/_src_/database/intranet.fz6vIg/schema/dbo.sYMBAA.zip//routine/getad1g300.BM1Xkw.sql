-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[getad1g300] (@nowno char(9),@ac3yy char(4),@dp1lun char(1))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	declare @ac1tyy char(4),@ac1cyy char(4),@ac1pyy char(4)
	declare @run1 nvarchar(300),@run2 nvarchar(350),@run nvarchar(750),@accok char(1)
	
	select @ac1tyy=ac1tyy,@ac1cyy=ac1cyy,@ac1pyy=ac1pyy from intranet.dbo.ac1yy
	create table #tmp2 (ad1date datetime,pl1no char(4),ac2no char(4),ac2no2 char(6),ad1dmon decimal(12, 2),ad1cmon decimal(12, 2))
	delete from intra3.dbo.ad2g3 where nowno=@nowno or ad1idate<getdate()
	if @dp1lun='T'
	begin
	if @ac3yy<=@ac1tyy
--		set @run1='select ad1.ad1date,ad1.pl1no,ad2.ac2no, ad2.ac2no2, ad2.ad1dmon, ad2.ad1cmon FROM  ad1'+@ac3yy+' as ad1,ad2'+@ac3yy+' as ad2 '
		set @run1='select ad1.ad1date,ad1.pl1no,ad2.ac2no, ad2.ac2no2, sum(ad2.ad1dmon) as ad1dmon, sum(ad2.ad1cmon) as ad1cmon FROM  ad1'+@ac3yy+' as ad1,ad2'+@ac3yy+' as ad2 '
	else
--		set @run1='select ad1.ad1date,ad1.pl1no,ad2.ac2no, ad2.ac2no2, ad2.ad1dmon, ad2.ad1cmon FROM  ad1,ad2 '
		set @run1='select ad1.ad1date,ad1.pl1no,ad2.ac2no, ad2.ac2no2, sum(ad2.ad1dmon) as ad1dmon, sum(ad2.ad1cmon) as ad1cmon FROM  ad1,ad2 '
	end
	if @dp1lun='C'
	begin
	if @ac3yy<=@ac1cyy
--		set @run1='select ad1.ad1date,ad1.pl1no,ad2.ac2no, ad2.ac2no2, ad2.ad1dmon, ad2.ad1cmon FROM  intranet2.dbo.ad1o'+@ac3yy+' as ad1,intranet2.dbo.ad2o'+@ac3yy+' as ad2 '
		set @run1='select ad1.ad1date,ad1.pl1no,ad2.ac2no, ad2.ac2no2, sum(ad2.ad1dmon) as ad1dmon, sum(ad2.ad1cmon) as ad1cmon FROM  intranet2.dbo.ad1o'+@ac3yy+' as ad1,intranet2.dbo.ad2o'+@ac3yy+' as ad2 '
	else
--		set @run1='select ad1.ad1date,ad1.pl1no,ad2.ac2no, ad2.ac2no2, ad2.ad1dmon, ad2.ad1cmon FROM  intranet2.dbo.ad1c as ad1,intranet2.dbo.ad2c as ad2 '
		set @run1='select ad1.ad1date,ad1.pl1no,ad2.ac2no, ad2.ac2no2, sum(ad2.ad1dmon) as ad1dmon, sum(ad2.ad1cmon) as ad1cmon FROM  intranet2.dbo.ad1c as ad1,intranet2.dbo.ad2c as ad2 '
	end
	if @dp1lun='P'
	begin
	if @ac3yy<=@ac1pyy
--		set @run1='select ad1.ad1date,ad1.pl1no,ad2.ac2no, ad2.ac2no2, ad2.ad1dmon, ad2.ad1cmon FROM  intranet2.dbo.ad1o'+@ac3yy+' as ad1,intranet2.dbo.ad2o'+@ac3yy+' as ad2 '
		set @run1='select ad1.ad1date,ad1.pl1no,ad2.ac2no, ad2.ac2no2, sum(ad2.ad1dmon) as ad1dmon, sum(ad2.ad1cmon) as ad1cmon FROM  intranet2.dbo.ad1o'+@ac3yy+' as ad1,intranet2.dbo.ad2o'+@ac3yy+' as ad2 '
	else
--		set @run1='select ad1.ad1date,ad1.pl1no,ad2.ac2no, ad2.ac2no2, ad2.ad1dmon, ad2.ad1cmon FROM  intranet2.dbo.ad1o as ad1,intranet2.dbo.ad2o as ad2 '
		set @run1='select ad1.ad1date,ad1.pl1no,ad2.ac2no, ad2.ac2no2, sum(ad2.ad1dmon) as ad1dmon, sum(ad2.ad1cmon) as ad1cmon FROM  intranet2.dbo.ad1o as ad1,intranet2.dbo.ad2o as ad2 '
	end
	set @run2=' WHERE ad1.ad1no+ad1.pl1no=ad2.ad1no+ad2.pl1no AND (YEAR(ad1.ad1date) = '+@ac3yy+') AND (ad2.ad1yy = '+@ac3yy+') and ad1.pl1no in (select pl1no from intra3.dbo.dp1ch where nowno='''+@nowno+''') group by ad1.ad1date,ad1.pl1no,ad2.pl1no,ad2.pl1no,ad2.ac2no, ad2.ac2no2'
--	set @run2=' WHERE ad1.ad1no+ad1.pl1no=ad2.ad1no+ad2.pl1no AND (YEAR(ad1.ad1date) = '+@ac3yy+') AND (ad2.ad1yy = '+@ac3yy+') and ad1.pl1no in (select dp1no from depcode where dp1lun='''+@dp1lun+''')'
	set @run=@run1+@run2
	insert into #tmp2 (ad1date,pl1no,ac2no,ac2no2,ad1dmon,ad1cmon) exec (@run)
	insert into intra3.dbo.ad2g3 (nowno,ad1date,pl1no,ac2no,ac2no2,ad1dmon,ad1cmon) select @nowno,ad1date,pl1no,ac2no,ac2no2,sum(ad1dmon) as ad1dmon,sum(ad1cmon) ad1cmon from #tmp2 where pl1no in (select pl1no from intra3.dbo.dp1ch where nowno=@nowno) group by ad1date,pl1no,ac2no,ac2no2
	--select * from intra3.dbo.ad2g3
	drop table #tmp2;
END
go

