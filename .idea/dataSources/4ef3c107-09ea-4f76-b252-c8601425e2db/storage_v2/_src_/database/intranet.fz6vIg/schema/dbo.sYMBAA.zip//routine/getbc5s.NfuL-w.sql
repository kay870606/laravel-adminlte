-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[getbc5s] (@nowno char(9),@pl1no varchar(4),@bcode varchar(11),@ecode varchar(11))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	delete from intra3.dbo.bc5s where nowno=@nowno or bc5idate2<CONVERT(nvarchar(30), GETDATE(), 111)
	if @bcode=''
	begin
	   insert into intra3.dbo.bc5s (nowno,pl1no,bc5id,bc5name,bc5sname,bc5model,bc4no,bc5from,bc5memo,bc5qty) select @nowno,pl1no,bc5id,bc5name,bc5sname,bc5model,bc4no,bc5from,bc5memo,0 from intranet.dbo.bc5 where pl1no=@pl1no
	   insert into intra3.dbo.bc5s (nowno,pl1no,bc5id,bc5sname,bc5model,bc5qty,bc5name) select @nowno,pl1no,bc5id,bc5sname,bc5model,1,(select bc5name from bc5 where pl1no=@pl1no and bc5id=bc6.bc5id) as bc5name from intranet.dbo.bc6 where pl1no=@pl1no
	   insert into intra3.dbo.bc5s (nowno,pl1no,bc5id,bc5qty,bc5name) select @nowno,pl1no,bc5id,-1,(select bc5name from bc5 where pl1no=@pl1no and bc5id=bc7.bc5id) as bc5name from intranet.dbo.bc7 where pl1no=@pl1no
	end
	else
	begin
	   insert into intra3.dbo.bc5s (nowno,pl1no,bc5id,bc5name,bc5sname,bc5model,bc4no,bc5from,bc5memo,bc5qty) select @nowno,pl1no,bc5id,bc5name,bc5sname,bc5model,bc4no,bc5from,bc5memo,0 from intranet.dbo.bc5 where pl1no=@pl1no and bc5id between @bcode and @ecode
	   insert into intra3.dbo.bc5s (nowno,pl1no,bc5id,bc5sname,bc5model,bc5qty,bc5name) select @nowno,pl1no,bc5id,bc5sname,bc5model,1,(select bc5name from bc5 where pl1no=@pl1no and bc5id=bc6.bc5id) as bc5name from intranet.dbo.bc6 where pl1no=@pl1no and bc5id between @bcode and @ecode
	   insert into intra3.dbo.bc5s (nowno,pl1no,bc5id,bc5qty,bc5name) select @nowno,pl1no,bc5id,-1,(select bc5name from bc5 where pl1no=@pl1no and bc5id=bc7.bc5id) as bc5name from intranet.dbo.bc7 where pl1no=@pl1no and bc5id between @bcode and @ecode
	end

END
go

