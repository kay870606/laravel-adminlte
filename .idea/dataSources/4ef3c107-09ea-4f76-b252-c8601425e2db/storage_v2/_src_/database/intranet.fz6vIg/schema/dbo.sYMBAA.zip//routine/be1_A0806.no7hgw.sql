-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[be1_A0806] (@nowno char(9),@pl1no char(4),@yymm char(4),@fe1no char(2),@byy char(4),@in1p decimal(4,2),@be3get char(1))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
	if (select object_id('tempdb..#tmp2'))is not null
	begin
		drop table #tmp2;
	end
update intra3 .dbo. be1_A0306 set bb1name=( select bb1name from intranet.dbo .bb1 where bb1no =intra3. dbo.be1_A0306 .bb1no)  where nowno=@nowno
update intra3 .dbo. be1_A0306 set bb1open=( select bb1open from intranet.dbo .bb1 where bb1no =intra3. dbo.be1_A0306 .bb1no)  where nowno=@nowno
update intra3 .dbo. be1_A0306 set bh1cal=(bh1mon/ bd1rel)/((cast (right(bi1range, 2)as decimal)- cast(left(bi1range ,2) as decimal)+1 )) where nowno=@nowno and bh1cal is null          
--update intra3 .dbo. be1_A0306 set bc3price=(select top 1 bc1prc from intranet.dbo.bc3n where bc3flag='A' and pl1no in (select dp1no from depcode where dp1lun='T') and bb1no=(select top 1 bb1no from bc3n where bb1id=intra3. dbo.be1_A0306.bb1id) and bc1prc>0 order by bc3date2 desc) where nowno=@nowno
update intra3 .dbo. be1_A0306 set bc3price=(select top 1 bc1prc from intranet.dbo.bc3n where bc3flag='A' and pl1no in (select dp1no from depcode where dp1lun=(select dp1lun from depcode where dp1no=@pl1no)) and bb1no=intra3. dbo.be1_A0306.bb1no and bc1prc>0 order by bc3date2 desc) where nowno=@nowno

declare @bh1monsum decimal(10, 1)
set @bh1monsum = (select sum(bh1mon) from intra3.dbo.be1_A0306 where nowno=@nowno)
update intra3.dbo.be1_A0306 set pi1=bh1mon/@bh1monsum*100 where nowno=@nowno
CREATE TABLE #tmp (bb1no2 char(6),rate decimal(6, 2))

if @be3get='Y'
  begin
  if (@fe1no <> '')
  begin
 insert into #tmp (bb1no2,rate) select bb1no,rate from intranet2.dbo.be3 where pl1no=@pl1no and bh1ym=@yymm and fe1no=@fe1no and be1bad<>'Y' and rate<>0  group by bb1no,rate
   end
else
  begin
  insert into #tmp (bb1no2,rate) select bb1no,rate from intranet2.dbo.be3 where pl1no=@pl1no and bh1ym=@yymm and be1bad<>'Y' and rate<>0 group by bb1no,rate
  end
  end
else
  begin
  if (@fe1no <> '')
  begin
 insert into #tmp (bb1no2,rate) select bb1no,rate from intranet2.dbo.be1 where pl1no=@pl1no and bh1ym=@yymm and fe1no=@fe1no and be1bad<>'Y' and rate<>0  group by bb1no,rate
   end
else
  begin
  insert into #tmp (bb1no2,rate) select bb1no,rate from intranet2.dbo.be1 where pl1no=@pl1no and bh1ym=@yymm and be1bad<>'Y' and rate<>0 group by bb1no,rate
  end
  end

update intra3.dbo.be1_A0306 set rate=(select top 1 rate from #tmp where bb1no2=intra3.dbo.be1_A0306.bb1no)  where nowno=@nowno
drop table #tmp

update intra3.dbo.be1_A0306 set bc3price=0 where nowno=@nowno and bc3price is null

CREATE TABLE #tmp2 (bb1no2 char(6),bb1id2 char(11),bd1qty2 int,bb1fcost2 decimal(8, 0)) 
if (@fe1no <> '')
  begin
  insert into #tmp2 (bb1no2,bb1id2,bd1qty2,bb1fcost2) select bb1no,bb1id,bd1qty,bb1fcost from intranet2.dbo.bd1 where fe1no=@fe1no and bb1yyyy=@byy and pl1no=@pl1no
   end
else
  begin
  insert into #tmp2 (bb1no2,bb1id2,bd1qty2,bb1fcost2) select bb1no,bb1id,bd1qty,bb1fcost from intranet2.dbo.bd1 where bb1yyyy=@byy and pl1no=@pl1no   
  end

update intra3.dbo.be1_A0306 set bd1qty=(select top 1 bd1qty2 from #tmp2 where bb1id2=intra3.dbo.be1_A0306.bb1id) where nowno=@nowno
update intra3.dbo.be1_A0306 set bb1fcost=(select top 1 bb1fcost2 from #tmp2 where bb1id2=intra3.dbo.be1_A0306.bb1id and bb1fcost2<>0) where nowno=@nowno
update intra3 .dbo. be1_A0306 set bb1fcost=(select TOP 1 bb1fcost from #tmp2 where bb1no2=intra3.dbo.be1_A0306.bb1no and bb1fcost<>0)  where nowno=@nowno and bb1fcost is null
drop table #tmp2

update intra3.dbo.be1_A0306 set bb1fcost=0 where nowno=@nowno and bb1fcost is null
update intra3 .dbo. be1_A0306 set bh1mon=bh1mon*@in1p where nowno=@nowno  
update intra3 .dbo. be1_A0306 set bh1cal=bh1cal*@in1p where nowno=@nowno  
END
go

