-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[getrg5m] (@pe1no char(5),@po2no char(3),@po2no2 char(3),@dp1lun char(1))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp
	end
	if (select object_id('tempdb..#tmp2'))is not null
	begin
		drop table #tmp2
	end
	if @dp1lun='T'
	begin
		select left(fu1group,1) as fu1group into #tmp from po2fu3,fu3 where po2fu3.fu1no=fu3.fu1no and (po2fu3.po2no=@po2no or po2fu3.po2no=@po2no2) and po2fu3.fu1lun_t='Y' and fu3.fu1type='P' group by left(fu3.fu1group,1)
		select left(fu3.fu1group,1) as fu1group into #tmp2 from rg5,fu3 where rg5.fu1no=fu3.fu1no and rg5.pe1no=@pe1no and fu3.fu1type='M' group by left(fu3.fu1group,1)
		insert into tempdb.#tmp (fu1group) select fu1group from tempdb.#tmp2
		select DISTINCT * from tempdb.#tmp order by fu1group
		drop table #tmp2
		drop table #tmp
	end
	if @dp1lun='C'
	begin
		select left(fu1group,1) as fu1group into #tmpC from po2fu3,fu3 where po2fu3.fu1no=fu3.fu1no and (po2fu3.po2no=@po2no or po2fu3.po2no=@po2no2) and po2fu3.fu1lun_c='Y' and fu3.fu1type='P' group by left(fu3.fu1group,1)
		select left(fu3.fu1group,1) as fu1group into #tmp2C from rg5,fu3 where rg5.fu1no=fu3.fu1no and rg5.pe1no=@pe1no and fu3.fu1type='M' group by left(fu3.fu1group,1)
		insert into tempdb.#tmpC (fu1group) select fu1group from tempdb.#tmp2C
		select DISTINCT * from tempdb.#tmpC order by fu1group
		drop table #tmp2C
		drop table #tmpC
	end
	if @dp1lun='P'
	begin
		select left(fu1group,1) as fu1group into #tmpP from po2fu3,fu3 where po2fu3.fu1no=fu3.fu1no and (po2fu3.po2no=@po2no or po2fu3.po2no=@po2no2) and po2fu3.fu1lun_p='Y' and fu3.fu1type='P' group by left(fu3.fu1group,1)
		select left(fu3.fu1group,1) as fu1group into #tmp2P from rg5,fu3 where rg5.fu1no=fu3.fu1no and rg5.pe1no=@pe1no and fu3.fu1type='M' group by left(fu3.fu1group,1)
		insert into tempdb.#tmpP (fu1group) select fu1group from tempdb.#tmp2P
		select DISTINCT * from tempdb.#tmpP order by fu1group
		drop table #tmp2P
		drop table #tmpP
	end
	if @dp1lun='S'
	begin
		select left(fu1group,1) as fu1group into #tmpP2 from po2fu3,fu3 where po2fu3.fu1no=fu3.fu1no and (po2fu3.po2no=@po2no or po2fu3.po2no=@po2no2) and po2fu3.fu1lun_s='Y' and fu3.fu1type='P' group by left(fu3.fu1group,1)
		select left(fu3.fu1group,1) as fu1group into #tmp2P2 from rg5,fu3 where rg5.fu1no=fu3.fu1no and rg5.pe1no=@pe1no and fu3.fu1type='M' group by left(fu3.fu1group,1)
		insert into tempdb.#tmpP2 (fu1group) select fu1group from tempdb.#tmp2P2
		select DISTINCT * from tempdb.#tmpP2 order by fu1group
		drop table #tmp2P2
		drop table #tmpP2
	end
END
go

