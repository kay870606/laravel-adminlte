CREATE VIEW dbo.v_ge1bk
AS
SELECT          dbo.ge1bk.ge1bname, dbo.ge1bk.ge1no, dbo.ge1bk.ge1bn, dbo.ge1bk.ge1ba, dbo.ge1bk.ge1bb, dbo.ge1bk.ge1month, 
                            dbo.ge1bk.ge1edate, dbo.ge1bk.us1no, dbo.ge1bk.ge1idate
FROM              dbo.ge1 INNER JOIN
                            dbo.ge1bk ON dbo.ge1.ge1num = dbo.ge1bk.ge1num AND dbo.ge1.ge1no = dbo.ge1bk.ge1no
go

