-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[in1_a0205] (@nowno char(9),@byy char(4),@bmm char(2),@mon21 char(1),@dp1yn2 char(1))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
	if (select object_id('tempdb..#tmp2'))is not null
	begin
		drop table #tmp2;
	end
	if (select object_id('tempdb..#tmp3'))is not null
	begin
		drop table #tmp3;
	end

create table #tmp (dp1no char(4),in1mon decimal(12, 2))
create table #tmp2 (dp1no char(4),bc3mon decimal(12, 2))
create table #tmp3 (dp1no char(4),bc2mon decimal(12, 2))

delete from intra3.dbo.in1_a0125 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
insert into intra3.dbo.in1_a0125 (nowno,pl1no,dp1lun2,m4,pi1) select @nowno,pl1no,'',0,0 from intra3.dbo.dp1ch where nowno=@nowno
update intra3.dbo.in1_a0125 set pl1name=(select dp1name from intranet.dbo.depcode where dp1no=pl1no)
update intra3.dbo.in1_a0125 set dp1lun2=(select dp1lun2 from intranet.dbo.depcode where dp1no=pl1no)

insert into #tmp (dp1no,in1mon) select pl1no,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as in1mon from intranet2.dbo.in2 where pl1no in (select pl1no from intra3.dbo.dp1ch where nowno=@nowno) and year(bk1date)=@byy and month(bk1date)<=@bmm group by pl1no
update intra3.dbo.in1_a0125 set m1=(select in1mon from #tmp where dp1no=pl1no)

-- bc3yn=Y才算再投資機台
insert into #tmp2 (dp1no,bc3mon) select pl1no,sum(bc1prc) as bc3mon from intranet.dbo.bc3n where bc3flag='A' and bc3yn='Y' and year(bc3date2)=@byy and month(bc3date2)<=@bmm and pl1no in (select pl1no from intra3.dbo.dp1ch where nowno=@nowno) group by pl1no
update intra3.dbo.in1_a0125 set m2=(select bc3mon from #tmp2 where dp1no=pl1no)

insert into #tmp3 (dp1no,bc2mon) select pl1no,sum(bz1price) as bc2mon from intranet.dbo.bc2n where bc2flag='1' and year(bz1date2)=@byy and month(bz1date2)<=@bmm and pl1no in (select pl1no from intra3.dbo.dp1ch where nowno=@nowno) group by pl1no
update intra3.dbo.in1_a0125 set m3=(select bc2mon from #tmp3 where dp1no=pl1no)
update intra3.dbo.in1_a0125 set m1=0 where m1 is null and nowno=@nowno
update intra3.dbo.in1_a0125 set m2=0 where m2 is null and nowno=@nowno
update intra3.dbo.in1_a0125 set m3=0 where m3 is null and  nowno=@nowno
if @mon21='2'
  update intra3.dbo.in1_a0125 set m1=m1/2,m2=m2/2,m3=m3/2 where  nowno=@nowno

update intra3.dbo.in1_a0125 set m4=m2-m3 where  nowno=@nowno
update intra3.dbo.in1_a0125 set PI1=CASE  
		WHEN M1>0 THEN (M2-M3)/M1*100
		ELSE 0 
		END  where nowno=@nowno

drop table #tmp
drop table #tmp2
drop table #tmp3
END
go

