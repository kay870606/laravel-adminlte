-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[getac3t21_2]  (@nowno char(9),@ac3yy char(4),@bmm char(2),@ac2no char(4),@ac2no2 char(6),@dp1lun char(1))
AS
BEGIN
-- 抓單科目各店每月借,貸金額-監管費計算-4110(大陸含4110-2,4110-3)
	SET NOCOUNT ON;
	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
	if (select object_id('tempdb..#tmp2'))is not null
	begin
		drop table #tmp2;
	end
	if (select object_id('tempdb..#tmp4'))is not null
	begin
		drop table #tmp4;
	end
	delete from intra3.dbo.ac3t where nowno=@nowno or ac3idate<CONVERT(nvarchar(30), GETDATE(), 111)
	
	if @dp1lun='T'
	BEGIN
		create table #tmp3 (mm char(2),pl1no char(4),ac2no1 char(10),ac2no char(4),ad1dmon decimal(12, 2),ad1cmon decimal(12, 2))
		select @nowno as nowno,ac3num,pl1no,ac3yy,ac2no,ac2no2,ac2name,ac2eng,ac2type, ac3mb1,ac3mb2 into #tmp from ac3 where ac3yy=@ac3yy and ac2no=@ac2no and (ac2no2=@ac2no2 or ac2no2='2' or ac2no2='3' or ac2no2='5') order by ac2no,ac2no2;
		insert into intra3.dbo.ac3t (nowno,ac3num,pl1no,dp1lun,ac3yy,ac2no1,ac2no,ac2no2,ac2name,ac2eng,ac2type,ac3mb1,ac3mb2) select nowno,ac3num,pl1no,@dp1lun,ac3yy,ac2no+ac2no2,ac2no,ac2no2,ac2name,ac2eng,ac2type,ac3mb1,ac3mb2 from tempdb.#tmp
		drop table #tmp
		insert into #tmp3 execute getad1g22 @nowno,@ac3yy,@bmm,@ac2no,@ac2no2,@dp1lun
		delete from intra3.dbo.ac3t2 where nowno=@nowno
		insert into intra3.dbo.ac3t2 (nowno,pl1no,ac3yy,ac3mm,ac2no1,ac2no,ad1dmon,ad1cmon) select @nowno,pl1no,@ac3yy,mm,ac2no,ac2no,ad1dmon,ad1cmon from #tmp3
		drop table #tmp3
	END
	if @dp1lun='P' or @dp1lun='C'
	BEGIN
		create table #tmp33 (mm char(2),pl1no char(4),ac2no1 char(10),ac2no char(4),ad1dmon decimal(12, 2),ad1cmon decimal(12, 2))
		select @nowno as nowno,ac3num,pl1no,ac3yy,ac2no,ac2no2,ac2name,ac2eng,ac2type, ac3mb1,ac3mb2 into #tmp2 from intranet2.dbo.ac3o where ac3yy=@ac3yy and ac2no=@ac2no and (ac2no2=@ac2no2 or ac2no2='2' or ac2no2='3' or ac2no2='5') order by ac2no,ac2no2;
		insert into intra3.dbo.ac3t (nowno,ac3num,pl1no,dp1lun,ac3yy,ac2no1,ac2no,ac2no2,ac2name,ac2eng,ac2type,ac3mb1,ac3mb2) select nowno,ac3num,pl1no,@dp1lun,ac3yy,ac2no+ac2no2,ac2no,ac2no2,ac2name,ac2eng,ac2type,ac3mb1,ac3mb2 from tempdb.#tmp2
		drop table #tmp2
		insert into #tmp33 execute getad1g22 @nowno,@ac3yy,@bmm,@ac2no,@ac2no2,@dp1lun
		--insert into #tmp3 execute getad1g22 @nowno,@ac3yy,@bmm,'4110','2',@dp1lun
		--insert into #tmp3 execute getad1g22 @nowno,@ac3yy,@bmm,'4110','3',@dp1lun
		--insert into #tmp33 execute getad1g22 @nowno,@ac3yy,@bmm,'4110','5',@dp1lun
		delete from intra3.dbo.ac3t2 where nowno=@nowno
		insert into intra3.dbo.ac3t2 (nowno,pl1no,ac3yy,ac3mm,ac2no1,ac2no,ad1dmon,ad1cmon) select @nowno,pl1no,@ac3yy,mm,ac2no,ac2no,ad1dmon,ad1cmon from #tmp33
		drop table #tmp33
	END
	UPDATE intra3.dbo.AC3T set dp1name=d.dp1name,dp1lun2=d.dp1lun2 from intra3.dbo.ac3t inner join depcode as d on intra3.dbo.ac3t.pl1no=d.dp1no
	update intra3.dbo.ac3t set lu1sort=lu1.lu1sort from intra3.dbo.ac3t inner join lu1 on intra3.dbo.ac3t.dp1lun2=lu1.lu1no
END
go

