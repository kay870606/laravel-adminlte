-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[pe1b0826] (@nowno char(9),@pl1no char(4),@bdate datetime)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	delete from intra3.dbo.pe1_B0826 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
	declare @tdate datetime,@byy char(4)
	set @byy = year(@bdate)
	set @tdate = @byy +'/'+'01'+'/'+'01' --取啟始日用
	
	insert into intra3.dbo.pe1_B0826 (nowno,pl1no,pe1no,sp1date,ph1pre,sp1hrs,sp1yy,ph1rest) select @nowno,pl1no,pe1no,sp1date,pf1hr,sp1hrs,sp1yy,0 from sp1 where year(@bdate)=sp1yy and pl1no=@pl1no 

	create table #tmp1 (pe1no char(5),ph1pre decimal(18,2))
	insert into #tmp1 (pe1no,ph1pre) select pe1no,sum(ph1hrs) as ph1hrs from ph1 where pe1no=ph1.pe1no and hl1no='D' and year(ph1date)=@byy and ph1date<=@bdate GROUP BY pe1no

	update intra3.dbo.pe1_B0826 set nowno=@nowno 
	update intra3.dbo.pe1_B0826 set usrname=usr.usrname from usr join intra3.dbo.pe1_B0826 ON usr.usrno=intra3.dbo.pe1_B0826.pe1no
	update intra3.dbo.pe1_B0826 set pf1ari=usr.pf1ari from usr join intra3.dbo.pe1_B0826 ON usr.usrno=intra3.dbo.pe1_B0826.pe1no --到職日期
	update intra3.dbo.pe1_B0826 set sp1date=sp1.sp1date from sp1 join intra3.dbo.pe1_B0826 ON sp1.pe1no=intra3.dbo.pe1_B0826.pe1no --啟休日期
	update intra3.dbo.pe1_B0826 set ph1pre=#tmp1.ph1pre from #tmp1 join intra3.dbo.pe1_B0826 ON #tmp1.pe1no=intra3.dbo.pe1_B0826.pe1no --本年度應休時數ph1pre
	update intra3.dbo.pe1_B0826 set ph1hrs=ph1.ph1hrs from ph1 join intra3.dbo.pe1_B0826 ON ph1.pe1no=intra3.dbo.pe1_B0826.pe1no --已休時數
	update intra3.dbo.pe1_B0826 set ph1rest=ph1pre-ph1hrs --剩餘時數
	drop table #tmp1

	select * from intra3.dbo.pe1_B0826 where nowno=@nowno order by pl1no,pe1no
END
go

