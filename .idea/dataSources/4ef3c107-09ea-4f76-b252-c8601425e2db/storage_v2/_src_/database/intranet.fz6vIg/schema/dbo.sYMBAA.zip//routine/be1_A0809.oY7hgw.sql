-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[be1_A0809] (@nowno char(9))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
	 create table #tmp (bd1no char(6),bb1name nvarchar(50))
  insert into #tmp (bd1no,bb1name) select bb1no,bb1name from bb1
update intra3.dbo.be1_A0309 set bb1name=(select bb1name from #tmp where bb1no=bd1no) where nowno=@nowno
drop table #tmp;
END
go

