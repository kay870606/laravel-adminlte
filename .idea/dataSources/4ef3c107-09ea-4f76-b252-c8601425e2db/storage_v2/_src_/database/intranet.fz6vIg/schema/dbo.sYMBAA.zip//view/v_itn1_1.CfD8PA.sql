CREATE VIEW dbo.v_itn1_1
AS
SELECT          dbo.itn1.no, dbo.itn1.itnno, dbo.itn1.itnsub, dbo.itn1.itnbody, dbo.itn1.usrno, dbo.itn1.endtime, dbo.itn1.itnlevel, 
                            dbo.itn1.fitnno, dbo.usr.usrname, dbo.usr.dep, dbo.itn1.itn1edate, dbo.itn1.itn1date
FROM              dbo.itn1 INNER JOIN
                            dbo.usr ON dbo.itn1.usrno = dbo.usr.usrno
go

