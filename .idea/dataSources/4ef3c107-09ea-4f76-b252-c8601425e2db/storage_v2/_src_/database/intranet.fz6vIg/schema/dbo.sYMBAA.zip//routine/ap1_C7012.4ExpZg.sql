-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[ap1_C7012] (@nowno char(9),@ap1ym char(5),@bcode char(4),@ecode char(4))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	delete from intra3.dbo.ap1c7012 where nowno=@nowno or ap1idate<CONVERT(nvarchar(30), GETDATE(), 111)
	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
	if (select object_id('tempdb..#tmp2'))is not null
	begin
		drop table #tmp2;
	end
	if @bcode=''
		insert into intra3.dbo.ap1c7012 (nowno,ap1ym,pl1no,su1no,ap1giv,ap1mac,ap1oth,ap1oth2,ap1not,dp1lun2) select @nowno,ap1ym,pl1no,su1no,ap1giv,ap1mac,ap1oth,ap1oth2,ap1not,dp1lun2 from v_ap1 where ap1ym=@ap1ym and ap1yn='Y' order by su1no,pl1no
	else
		insert into intra3.dbo.ap1c7012 (nowno,ap1ym,pl1no,su1no,ap1giv,ap1mac,ap1oth,ap1oth2,ap1not,dp1lun2) select @nowno,ap1ym,pl1no,su1no,ap1giv,ap1mac,ap1oth,ap1oth2,ap1not,dp1lun2 from v_ap1 where su1no between @bcode and @ecode and ap1ym=@ap1ym and ap1yn='Y' order by su1no,pl1no

	update intra3.dbo.ap1C7012 set pl1name=(select dp1name from depcode where dp1no=pl1no)
	
	select su1no,sum(su1mon) as su1mon into #tmp2 from ko1 where ap1ym=@ap1ym group by su1no
	if @bcode=''
		insert into intra3.dbo.ap1C7012 (nowno,ap1ym,su1no,pl1name,pl1no,ap1giv) select @nowno,@ap1ym,su1no,'代扣郵電費','ZZZ',su1mon*-1 from #tmp2 where su1mon>0
	else
		insert into intra3.dbo.ap1C7012 (nowno,ap1ym,su1no,pl1name,pl1no,ap1giv) select @nowno,@ap1ym,su1no,'代扣郵電費','ZZZ',su1mon*-1 from #tmp2 where su1mon>0 and su1no between @bcode and @ecode
	
	select su1no as no2,ecomp into #tmp from su1 where dp1lun='T'
	update intra3.dbo.ap1C7012 set ecomp=(select ecomp from #tmp where no2=su1no)
	update intra3.dbo.ap1C7012 set ap1mac=0 where ap1mac is null
	update intra3.dbo.ap1C7012 set ap1oth=0 where ap1oth is null
	update intra3.dbo.ap1C7012 set ap1oth2=0 where ap1oth2 is null
	drop table #tmp
	drop table #tmp2
END
go

