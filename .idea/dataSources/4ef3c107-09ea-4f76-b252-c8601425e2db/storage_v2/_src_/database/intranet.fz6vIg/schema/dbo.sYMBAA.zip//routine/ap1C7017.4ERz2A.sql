-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[ap1C7017] (@nowno char(9),@ap1ym char(5))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
 delete from intra3.dbo.ap1C7017 where nowno=@nowno or ap1idate<CONVERT(nvarchar(30), GETDATE(), 111)
  
    insert into intra3.dbo.ap1C7017 (nowno,pl1no,dp1name,ap1mon) select @nowno,pl1no,(select dp1name from intranet.dbo.depcode where ap1.pl1no=depcode.dp1no) as dp1name,sum(ap1giv+ap1mac+ap1oth-ap1oth2) as ap1mon from intranet.dbo.ap1 where ap1ym=@ap1ym group by pl1no
END
go

