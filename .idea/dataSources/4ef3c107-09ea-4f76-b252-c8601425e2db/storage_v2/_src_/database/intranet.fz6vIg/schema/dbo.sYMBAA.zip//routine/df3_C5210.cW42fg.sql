-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[df3_C5210] (@nowno char(9),@df3no char(7),@byy char(4),@bmm char(2),@dp1lun char(1))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	delete from intra3.dbo.df3_C5210 where nowno=@nowno
	if @dp1lun<>'C'
		insert into intra3.dbo.df3_C5210 (nowno,pl1no,df1pi,in1mon,in1mon4,df1mon,in1rmon,in1tmon,df5mon1,df5mon2,df5mon3) select @nowno,pl1no,df1pi,in1mon,in1mon4,df1mon,in1rmon,in1tmon,df5mon1,df5mon2,df5mon3 from df4 where df3no=@df3no and (df1bdate is null or month(df1bdate)=@bmm) order by pl1no
	else
		insert into intra3.dbo.df3_C5210 (nowno,pl1no,df1pi,in1mon,in1mon4,df1mon,in1rmon,in1tmon,df5mon1,df5mon2,df5mon3) select @nowno,pl1no,df1pi,in1mon,in1mon4,df1mon,in1rmon,in1tmon,df5mon1,df5mon2,df5mon3 from df4 where df3no=@df3no order by pl1no
	update intra3.dbo.df3_C5210 set pl1name=d.dp1name from intra3.dbo.df3_C5210 inner join depcode as d ON intra3.dbo.df3_C5210.pl1no=d.dp1no
	update intra3.dbo.df3_C5210 set dp1lun2=d.dp1lun2 from intra3.dbo.df3_C5210 inner join depcode as d ON intra3.dbo.df3_C5210.pl1no=d.dp1no

END
go

