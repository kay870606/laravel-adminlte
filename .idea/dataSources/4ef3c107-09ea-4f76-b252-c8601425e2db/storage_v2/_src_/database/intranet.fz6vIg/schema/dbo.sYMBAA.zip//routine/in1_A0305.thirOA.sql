-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[in1_A0124] (@byy char(4),@bmm char(2),@dp1lun char(1),@dp1over char(1),@nowno char(9))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	declare @yy char(4)

	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
	if (select object_id('tempdb..#tmp2'))is not null
	begin
		drop table #tmp2;
	end
	delete from intra3.dbo.in1_A0124 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
	

  if @dp1lun='A'
  begin
  insert into intra3.dbo.in1_A0124 (nowno,dp1lun,lu1no,lu1name,pin1,pi1,pin2,pi2,pin3,pi3) select @nowno,@dp1lun,lu1no,lu1name,0,0,0,0,0,0 from intranet.dbo.lu1 order by lu1no,lu1name
	  create table #tmp (pl1no char(4),dp1lun2 char(2),mm char(2),mon decimal(12, 0))
	  if @dp1over='Y'
	  begin
		  insert into #tmp (pl1no,dp1lun2,mm,mon) select pl1no,(select dp1lun2 from depcode as dd where dd.dp1no=pl1no) as dp1lune,SUBSTRING( CONVERT(char(10),bk1date,111),6,2) as mm,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon from intranet2.dbo.in2 where year(bk1date)=@byy and month(bk1date)<=@bmm and pl1no in (select dp1no from depcode as d where d.dp1over<>'Y') group by SUBSTRING( CONVERT(char(10),bk1date,111),6,2),pl1no
	  end
	  else
	  begin
		  insert into #tmp (pl1no,dp1lun2,mm,mon) select pl1no,(select dp1lun2 from depcode as dd where dd.dp1no=pl1no) as dp1lune,SUBSTRING( CONVERT(char(10),bk1date,111),6,2) as mm,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon from intranet2.dbo.in2 where year(bk1date)=@byy and month(bk1date)<=@bmm group by SUBSTRING( CONVERT(char(10),bk1date,111),6,2),pl1no
	  end
	  select dp1lun2,mm,sum(mon) as mon,(select lu1name from intranet.dbo.lu1 where lu1.lu1no=dp1lun2) as lu1name from #tmp where dp1lun2 in (select dp1lun2 from depcode) group by dp1lun2,mm order by dp1lun2,mm
	  --select dp1lun2,mm,sum(mon) as mon from #tmp2 group by dp1lun2,mm	
	  delete from intra3.dbo.in1_A0124 where nowno=@nowno and lu1no>'97'  
	  drop table #tmp
  end
  else
  begin
	insert into intra3.dbo.in1_A0124 (nowno,dp1lun,lu1no,lu1name,pin1,pi1,pin2,pi2,pin3,pi3) select @nowno,@dp1lun,lu1no,lu1name,0,0,0,0,0,0 from intranet.dbo.lu1 where lu1lun=@dp1lun order by lu1no,lu1name
	  create table #tmp2 (pl1no char(4),dp1lun2 char(2),mm char(2),mon decimal(12, 0))
	  if @dp1over='Y'
	  begin
		  insert into #tmp2 (pl1no,dp1lun2,mm,mon) select pl1no,(select dp1lun2 from depcode as dd where dd.dp1no=pl1no) as dp1lune,SUBSTRING( CONVERT(char(10),bk1date,111),6,2) as mm,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon from intranet2.dbo.in2 where year(bk1date)=@byy and month(bk1date)<=@bmm and pl1no in (select dp1no from depcode as d where d.dp1lun=@dp1lun and d.dp1over<>'Y') group by SUBSTRING( CONVERT(char(10),bk1date,111),6,2),pl1no
	  end
	  else
	  begin
		  insert into #tmp2 (pl1no,dp1lun2,mm,mon) select pl1no,(select dp1lun2 from depcode as dd where dd.dp1no=pl1no) as dp1lune,SUBSTRING( CONVERT(char(10),bk1date,111),6,2) as mm,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon from intranet2.dbo.in2 where year(bk1date)=@byy and month(bk1date)<=@bmm and pl1no in (select dp1no from depcode as d where d.dp1lun=@dp1lun) group by SUBSTRING( CONVERT(char(10),bk1date,111),6,2),pl1no
	  end
	  select dp1lun2,mm,sum(mon) as mon,(select lu1name from intranet.dbo.lu1 where lu1.lu1no=dp1lun2) as lu1name from #tmp2 where dp1lun2 in (select dp1lun2 from depcode) group by dp1lun2,mm order by dp1lun2,mm
	  --select dp1lun2,mm,sum(mon) as mon from #tmp2 group by dp1lun2,mm
	  delete from intra3.dbo.in1_A0124 where nowno=@nowno and lu1no>'97'
	  drop table #tmp2
  end
END
go

