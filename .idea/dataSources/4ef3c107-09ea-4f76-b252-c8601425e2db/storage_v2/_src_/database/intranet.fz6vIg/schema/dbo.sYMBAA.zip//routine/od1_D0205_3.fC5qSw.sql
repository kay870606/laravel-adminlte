-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[od1_D0205_3] (@nowno char(9),@su1no char(2))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

delete from intra3.dbo.od1_D0205_3 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
insert into intra3.dbo.od1_D0205_3 (nowno,pl1no,pt1no,pt1name,model,pt1qty,su1name,giftno) select @nowno,pl1no,pt1no,pt1name,(select model from intranet.dbo.upt1 where pt1no=uorder2.pt1no),pt1qty,(select su1name from usu1 where su1no=@su1no),giftno from intranet.dbo.uorder2 where left(pt1no,2)=@su1no
update intra3.dbo.od1_D0205_3 set pl1name=(select DP1NAME from depcode where DP1NO=intra3.dbo.od1_D0205_3.pl1no)
END
go

