-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[getrg5pe1] (@fu1no char(5),@po2no char(3))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp
	end
	if (select object_id('tempdb..#tmp2'))is not null
	begin
		drop table #tmp2
	end
	--先抓有設定的
	select rg5.pe1no,usr.usrname,usr.dep,usr.po2no,usr.po2no2,'Y' as pe1set into #tmp from rg5,usr where rg5.pe1no=usr.usrno and rg5.fu1no=@fu1no and (usr.po2no=@po2no or usr.po2no2=@po2no) and usr.pf1lef is null order by rg5.pe1no
	select usrno as pe1no,usrname,dep,po2no,po2no2,'N' as pe1set into #tmp2 from usr where pf1lef is null and po2no=@po2no and not (usr.usrno in (select pe1no from rg5 where fu1no=@fu1no)) order by usr.usrno
	insert into tempdb.#tmp (pe1no,usrname,dep,po2no,po2no2,pe1set) select pe1no,usrname,dep,po2no,po2no2,pe1set from tempdb.#tmp2
	select t.*,depcode.dp1lun from tempdb.#tmp as t,depcode where t.dep=depcode.dp1no order by t.pe1set desc,depcode.dp1lun,t.pe1no
	drop table #tmp2
	drop table #tmp
END
go

