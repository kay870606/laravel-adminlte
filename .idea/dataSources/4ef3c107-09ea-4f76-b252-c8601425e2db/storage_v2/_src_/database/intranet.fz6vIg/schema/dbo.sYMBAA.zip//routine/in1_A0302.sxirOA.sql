-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[in1_A0118] (@byy char(4),@dp1lun2 char(2),@bdate1 char(10),@bdate2 char(10),@edate1 char(10),@edate2 char(10))
AS
BEGIN
	SET NOCOUNT ON;
	declare @eyy char(4),@edate char(10)
set @eyy=CAST( (CAST(@byy as int)-1) as char(4)) /* 前一年度 */
--set @nyy=SUBSTRING( CONVERT(char(10),getdate(),111),1,4) /*--今年度--*/
	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
	if (select object_id('tempdb..#tmp2'))is not null
	begin
		drop table #tmp2;
	end
	if (select object_id('tempdb..#tmp3'))is not null
	begin
		drop table #tmp3;
	end
  --set @edate=@byy+SUBSTRING( CONVERT(char(10),getdate(),111),5,4)+'01'
  --select @edate
  create table #tmp (pl1no char(4),yy char(4),mm char(2),mon decimal(12, 0))
  create table #tmp2 (pl1no char(4),mm char(2),n1 decimal(3, 0))
  create table #tmp3 (pl1no char(4),mm char(2),n1 decimal(3, 0))

  insert into #tmp (pl1no,yy,mm,mon) select pl1no,year(bk1date) as yy,SUBSTRING( CONVERT(char(10),bk1date,111),6,2) as mm,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon from intranet2.dbo.in2 where year(bk1date)=@byy and bk1date between @edate1 and @edate2 and pl1no in (select dp1no from INTRANET.DBO.depcode as d where d.dp1lun2=@dp1lun2) group by year(bk1date),SUBSTRING( CONVERT(char(10),bk1date,111),6,2),pl1no
  insert into #tmp (pl1no,yy,mm,mon) select pl1no,year(bk1date) as yy,SUBSTRING( CONVERT(char(10),bk1date,111),6,2) as mm,sum(bk1cah+bk1oth+bk1oth2+bk1mon2+bk1mon3) as mon from intranet2.dbo.in2 where year(bk1date)=@eyy and bk1date between @bdate1 and @bdate2 and pl1no in (select dp1no from INTRANET.DBO.depcode as d where d.dp1lun2=@dp1lun2) group by year(bk1date),SUBSTRING( CONVERT(char(10),bk1date,111),6,2),pl1no
  insert into #tmp2 (pl1no,mm) select pl1no,SUBSTRING( CONVERT(char(10),bk1date,111),6,2) as mm from intranet2.dbo.in2 where year(bk1date)=@byy and bk1date between @edate1 and @edate2 and pl1no in (select dp1no from INTRANET.DBO.depcode as d where d.dp1lun2=@dp1lun2) group by SUBSTRING( CONVERT(char(10),bk1date,111),6,2),pl1no
  insert into #tmp3 (pl1no,mm) select pl1no,SUBSTRING( CONVERT(char(10),bk1date,111),6,2) as mm from intranet2.dbo.in2 where year(bk1date)=@eyy and bk1date between @bdate1 and @bdate2 and pl1no in (select dp1no from INTRANET.DBO.depcode as d where d.dp1lun2=@dp1lun2) group by SUBSTRING( CONVERT(char(10),bk1date,111),6,2),pl1no
  select @byy as yy,mm,sum(1) as nn from #tmp2 group by mm order by mm
  select @eyy as yy,mm,sum(1) as nn from #tmp3 group by mm order by mm
  select yy,mm,sum(mon) as mon from #tmp group by yy,mm order by yy,mm
  drop table #tmp
  drop table #tmp2
  drop table #tmp3
END
go

