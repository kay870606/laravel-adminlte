CREATE VIEW dbo.v_usr
AS
SELECT          usr_1.usrname AS mgrname, depcode_1.DP1NAME AS depname, po2_1.po2name AS po2no2name, 
                            postcode_1.PO1NAME AS po1no2name, dbo.usr.pe1num, dbo.usr.usrno, dbo.usr.usrid, dbo.usr.usrpwd, 
                            dbo.usr.usrname, dbo.usr.usrname2, dbo.usr.usrlevel, dbo.usr.usracc, dbo.usr.usrstat, dbo.usr.usreml, dbo.usr.mac, 
                            dbo.usr.cardno, dbo.usr.post, dbo.usr.dep, dbo.usr.tel, dbo.usr.agent, dbo.usr.CCagent, dbo.usr.lastip, 
                            dbo.usr.depbcount, dbo.usr.mgr, dbo.usr.us1no, dbo.usr.probcount, dbo.usr.dp1no, dbo.usr.po2no, dbo.usr.login1, 
                            dbo.usr.pf1eng, dbo.usr.pf1id, dbo.usr.pf1nat, dbo.usr.pf1psn, dbo.usr.pf1pse, dbo.usr.pf1sex, dbo.usr.pf1bld, 
                            dbo.usr.pf1bpc, dbo.usr.pf1add, dbo.usr.pf1cad, dbo.usr.pf1tel, dbo.usr.pf1com, dbo.usr.pf1mar, dbo.usr.pf1sup, 
                            dbo.usr.pf1edu, dbo.usr.pf1spc, dbo.usr.pf1acc, dbo.usr.pf1ind, dbo.usr.pf1inl, dbo.usr.pf1inm, dbo.usr.pf1gnd, 
                            dbo.usr.pf1gnl, dbo.usr.pf1gnm, dbo.usr.pf1ari, dbo.usr.pf1lef, dbo.usr.pf1start, dbo.usr.pf1inm2, dbo.usr.pf1mdi, 
                            dbo.usr.pf1bth, dbo.usr.oldno, dbo.usr.pf1yn1, dbo.usr.pf1yn2, dbo.usr.pf1yn3, dbo.usr.pf1nno, dbo.usr.pf1memo, 
                            dbo.usr.pf1type, dbo.usr.pf1all, dbo.usr.pf1otime, dbo.usr.pf1add1, dbo.usr.pf1add2, dbo.usr.pf1add3, dbo.usr.zp1no, 
                            dbo.usr.pf1cc, dbo.usr.oldno2, dbo.usr.pf1down, dbo.usr.pf1lun, dbo.usr.po2no2, dbo.usr.po2type, dbo.usr.dp3name, 
                            dbo.usr.pf1bank, dbo.usr.pf1ba2, dbo.usr.pf1type9, dbo.usr.pf1cc2, dbo.usr.pf1leave, dbo.usr.pf1sacc, dbo.usr.pf1sin, 
                            dbo.usr.pf1spe, dbo.usr.pf1chk, dbo.usr.pf1yn4, dbo.usr.pf1yn5, dbo.usr.pf1gyn, dbo.usr.po1no2, dbo.usr.pf1pi, 
                            dbo.usr.pf1pmon, dbo.usr.pf1upi1, dbo.usr.pf1upi2, dbo.usr.pf1umon, dbo.usr.pf1umon2, dbo.usr.pf1edu2, 
                            dbo.usr.pf1ind_e, dbo.usr.pf1inm_e, dbo.usr.pf1gnd_e, dbo.usr.pf1nno_e, dbo.usr.pf1pi_e, dbo.usr.pf1pi_ed, 
                            dbo.usr.pf1out_d, dbo.usr.pf1out_e, dbo.usr.pf1gover, dbo.usr.pf1hr, dbo.usr.pf1hr2, dbo.usr.pf1late, dbo.usr.pf1lef1, 
                            dbo.usr.pf1lef2, dbo.usr.pf1htype, dbo.usr.pe1one, dbo.usr.pe1nfing, dbo.usr.pe1new, dbo.usr.pe1dmain, 
                            dbo.usr.pe1fyn, dbo.usr.pe1fdate, dbo.usr.pe1insu, dbo.usr.fi1obig, dbo.usr.fi1tbig, dbo.usr.fi1date, dbo.usr.dp3bdate,
                             dbo.usr.dp3edate, dbo.usr.dp3mon1, dbo.usr.dp3mon2, dbo.usr.dp3name2, dbo.usr.dp3name3, dbo.usr.pf1pass, 
                            dbo.usr.sm1order, dbo.usr.sm1pno, dbo.po2.po2name, dbo.postcode.PO1NAME, depcode_1.dp1lun,
                                (SELECT          ye1nn
                                  FROM               dbo.v_ye1
                                  WHERE           (pe1no = dbo.usr.usrno)) AS ye1nn, dbo.depcode.DP1NAME, dbo.usr.pe1bdate, dbo.usr.pe1edate, 
                            dbo.usr.pe1mno, dbo.usr.pe1mdate, dbo.usr.pe1bmemo, dbo.usr.pf1eng2, dbo.usr.pe1low, dbo.usr.pe1gift, 
                            dbo.usr.pe1lay
FROM              dbo.usr INNER JOIN
                            dbo.depcode ON dbo.usr.dp1no = dbo.depcode.DP1NO LEFT OUTER JOIN
                            dbo.postcode AS postcode_1 ON dbo.usr.po1no2 = postcode_1.PO1NO LEFT OUTER JOIN
                            dbo.po2 AS po2_1 ON dbo.usr.po2no2 = po2_1.po2no LEFT OUTER JOIN
                            dbo.po2 ON dbo.usr.po2no = dbo.po2.po2no LEFT OUTER JOIN
                            dbo.depcode AS depcode_1 ON dbo.usr.dep = depcode_1.DP1NO LEFT OUTER JOIN
                            dbo.postcode ON dbo.usr.post = dbo.postcode.PO1NO LEFT OUTER JOIN
                            dbo.usr AS usr_1 ON dbo.usr.mgr = usr_1.usrno
go

