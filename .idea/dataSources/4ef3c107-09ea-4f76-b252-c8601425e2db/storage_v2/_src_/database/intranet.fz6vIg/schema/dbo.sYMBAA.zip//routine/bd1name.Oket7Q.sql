-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[bd1name] (@pl1no char(4),@bb1yyyy char(4),@nowno char(9))
AS
BEGIN
	SET NOCOUNT ON;
	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
delete from intra3.dbo.bb1ch where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111);
insert into intra3.dbo.bb1ch (nowno,bb1no,bb1name,bb1eng,bb1id,bb1id2) select @nowno,bb1no,(select bb1name from bb1 where bb1no=intranet2.dbo.bd1.bb1no) as bb1name,(select bb1eng from bb1 where bb1no=intranet2.dbo.bd1.bb1no) as bb1eng,bb1id,bb1id2 from intranet2.dbo.bd1 where bb1yyyy=@bb1yyyy and pl1no=@pl1no and bb1id<>'' and bb1id not in (select bb1id from bc2n where (bc2flag='1' or bc2flag='5') and pl1no=@pl1no)  group by bb1no,bb1id,bb1id2
END
go

