-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[ap1C7016] (@nowno char(9),@bcode char(4),@ecode char(4),@ap1ym char(5))

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

 delete from intra3.dbo.ap1C7016 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
if @bcode='' and @ecode=''
	insert into intra3.dbo.ap1C7016 (nowno,su1no,ecomp,su1mon,su1tl,ap1giv,ap1mac,ap1oth,ap1oth2,ap1yn,ko1mon,ko1no) select @nowno,su1no,ecomp,su1mon,su1tl,sum(ap1giv) as ap1giv,sum(ap1mac) as ap1mac,sum(ap1oth) as ap1oth,sum(ap1oth2) as ap1oth2,ap1yn,0,'' from v_ap1 where ap1ym=@ap1ym and ap1yn='Y' group by su1no,ecomp,su1mon,su1tl,ap1yn order by su1no
else
	insert into intra3.dbo.ap1C7016 (nowno,su1no,ecomp,su1mon,su1tl,ap1giv,ap1mac,ap1oth,ap1oth2,ap1yn,ko1mon,ko1no) select @nowno,su1no,ecomp,su1mon,su1tl,sum(ap1giv) as ap1giv,sum(ap1mac) as ap1mac,sum(ap1oth) as ap1oth,sum(ap1oth2) as ap1oth2,ap1yn,0,'' from v_ap1 where ap1ym=@ap1ym and ap1yn='Y' and su1no between @bcode and @ecode group by su1no,ecomp,su1mon,su1tl,ap1yn order by su1no

--update intra3.dbo.ap1C7016 set ko1no=a.ko1no from intra3.dbo.ap1C7016 inner join intranet.dbo.ko1 as a ON ap1C7016.su1no=a.su1no

END
go

