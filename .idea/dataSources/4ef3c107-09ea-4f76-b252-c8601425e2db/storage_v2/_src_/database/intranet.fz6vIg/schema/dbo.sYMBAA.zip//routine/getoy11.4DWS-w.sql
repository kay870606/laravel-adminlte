-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[getoy11] (@nowno char(9),@pl1no char(4),@oy1ym char(5),@oy1month char(6),@ch char(1))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

delete from intra3.dbo.oy1 where nowno=@nowno or oy1idate<CONVERT(nvarchar(30), GETDATE(), 111)
if @ch='1'
begin
	insert into intra3.dbo.oy1 (nowno,oy1no1,oy1no2,oy1ym,oy1mon,oy1bonus,oy1ticket,dp1name,oy1month) select @nowno,oy1.oy1no1,oy1.oy1no2,oy1.oy1ym,oy1.oy1mon,oy1.oy1bonus,oy1.oy1ticket,dp1.dp1name,dp1.oy1month from oy1,depcode as dp1 where oy1.oy1no2=dp1.dp1no and oy1.oy1no1=@pl1no and oy1.oy1ym=@oy1ym and oy1.oy1no2 in (select (case when oy1month='' or oy1month>=@oy1month then dp1no else '' end) as dp1no from depcode) order by oy1.oy1no2
end
else
begin
	insert into intra3.dbo.oy1 (nowno,oy1no1,oy1no2,oy1ym,oy1mon,oy1bonus,oy1ticket,dp1name,oy1month) select @nowno,oy1.oy1no1,oy1.oy1no2,oy1.oy1ym,oy1.oy1mon,oy1.oy1bonus,oy1.oy1ticket,dp1.dp1name,dp1.oy1month from oy1,depcode as dp1 where oy1.oy1no1=dp1.dp1no and oy1.oy1no2=@pl1no and oy1.oy1ym=@oy1ym and oy1.oy1no1 in (select (case when oy1month='' or oy1month>=@oy1month then dp1no else '' end) as dp1no from depcode) order by oy1.oy1no1
end

END
go

