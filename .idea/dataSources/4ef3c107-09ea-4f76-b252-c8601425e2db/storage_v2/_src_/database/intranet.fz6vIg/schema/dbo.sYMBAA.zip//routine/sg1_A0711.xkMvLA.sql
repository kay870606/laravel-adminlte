-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sg1_A0711] (@nowno char(9),@pl1no char(4),@bdate Datetime,@edate Datetime,@bcode char(6),@ecode char(6))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
   delete from intra3.dbo.sg1_A0711 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
  if @bcode='' and @ecode=''
	insert into intra3.dbo.sg1_A0711 (nowno,pl1no,sg1date, bb1no,bb1name, sg1type,sg1qty, sg1memo) SELECT  @nowno,pl1no,sg1date, bb1no,(select bb1name from bb1 where bb1no=sg1s.bb1no), sg1type,sg1qty, sg1memo FROM  intranet.dbo.sg1s WHERE  (pl1no = @pl1no) and bb1no<>'' AND sg1date between @bdate and @edate order by sg1date,sg1num
  else
    insert into intra3.dbo.sg1_A0711 (nowno,pl1no,sg1date, bb1no,bb1name, sg1type,sg1qty, sg1memo) SELECT @nowno,pl1no,sg1date, bb1no,(select bb1name from bb1 where bb1no=sg1s.bb1no), sg1type,sg1qty, sg1memo FROM  intranet.dbo.sg1s WHERE  (pl1no = @pl1no) and bb1no<>'' and bb1no between @bcode and @ecode AND sg1date between @bdate and @edate order by sg1date,bb1no
--update intra3.dbo.sg1_A0711 set bb1name=(select bb1name from bb1 where bb1no=sg1_A0711.bb1no)
--insert into intra3.dbo.sg1_A0711 (nowno,pl1no,sg1date,sg1qty, sg1memo) SELECT  @nowno,pl1no,sg2date,sg2qty,sg2memo FROM  intranet.dbo.sg2 WHERE  (pl1no = @bcode) AND (YEAR(sg2date) = @byy) AND (MONTH(sg2date) = @bmm) 

END
go

