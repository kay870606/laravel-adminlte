-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[pe1b0802] (@nowno char(9),@yy char(4),@pl1no char(4))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	delete from intra3.dbo.pe1_b0801 where nowno=@nowno
	if @pl1no=''
	begin
		insert into intra3.dbo.pe1_b0801 (nowno,pl1no,pe1no,usrname,ph1date,ph1hrs,sp1hrs) select @nowno,ph1.pl1no,ph1.pe1no,usr.usrname,ph1.ph1date,ph1.ph1hrs,(select sp1hrs from sp1 where sp1.sp1yy=@yy and sp1.pe1no=ph1.pe1no) as sp1hrs from ph1,usr where ph1.pe1no=usr.usrno and ph1.hl1no='D' and usr.po2no<>'B9' and usr.pf1lef is null and year(ph1.ph1date)=@yy order by ph1.pl1no,ph1.pe1no,ph1.ph1date
	end
	else
	begin
		if @pl1no='TOP'
		begin
			insert into intra3.dbo.pe1_b0801 (nowno,pl1no,pe1no,usrname,ph1date,ph1hrs,sp1hrs) select @nowno,ph1.pl1no,ph1.pe1no,usr.usrname,ph1.ph1date,ph1.ph1hrs,(select sp1hrs from sp1 where sp1.sp1yy=@yy and sp1.pe1no=ph1.pe1no) as sp1hrs from ph1,usr where ph1.pe1no=usr.usrno and ph1.hl1no='D' and usr.po2no<>'B9' and usr.pf1lef is null and left(ph1.pl1no,3)='TOP' and year(ph1.ph1date)=@yy order by ph1.pl1no,ph1.pe1no,ph1.ph1date
		end
		else
		begin
			insert into intra3.dbo.pe1_b0801 (nowno,pl1no,pe1no,usrname,ph1date,ph1hrs,sp1hrs) select @nowno,ph1.pl1no,ph1.pe1no,usr.usrname,ph1.ph1date,ph1.ph1hrs,(select sp1hrs from sp1 where sp1.sp1yy=@yy and sp1.pe1no=ph1.pe1no) as sp1hrs from ph1,usr where ph1.pe1no=usr.usrno and ph1.hl1no='D' and usr.po2no<>'B9' and usr.pf1lef is null and ph1.pl1no=@pl1no and year(ph1.ph1date)=@yy order by ph1.pl1no,ph1.pe1no,ph1.ph1date
		end
	end
	update intra3.dbo.pe1_b0801 set sp1hrs=0 where sp1hrs is null
	select pl1no,pe1no,usrname,sum(ph1hrs) as ph1hrs,sp1hrs from intra3.dbo.pe1_b0801 where nowno=@nowno group by pl1no,pe1no,usrname,sp1hrs order by pl1no,pe1no
END
go

