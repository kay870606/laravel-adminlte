-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[ps1up] (@nowno char(9),@pl1no char(5),@byy char(4),@bmm char(2),@pe1no char(5),@ecode char(5))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end

	if (select object_id('tempdb..#tmp2'))is not null
	begin
		drop table #tmp2;
	end

	if (select object_id('tempdb..#tmp_usr'))is not null
	begin
		drop table #tmp_usr;
	end
	if (select object_id('tempdb..#tmp_usr2'))is not null
	begin
		drop table #tmp_usr2;
	end


	if (@pl1no='TOP')    --------(總公司)
		begin
			select usrno into #tmp_usr from usr where (pf1lef is null or (year(pf1lef)>@byy or (year(pf1lef)=@byy and month(pf1lef)>=@bmm))) and (left(dep,3)=@pl1no or left(dp1no,3)=@pl1no)
			select pe1no into #tmp_usr2 from ps1 where year(ps1date)=@byy and month(ps1date)=@bmm and left(pl1no,3)='TOP' GROUP BY PE1NO
			INSERT into #tmp_usr (usrno) select pe1no from #tmp_usr2
			select * into #tmp2 from ps1 where year(ps1date)=@byy and month(ps1date)=@bmm and left(pl1no,3)='TOP'
--			select * into #tmp2 from ps1 where year(ps1date)=@byy and month(ps1date)=@bmm and pe1no in (select usrno from #tmp_usr)
			update intra3.dbo.ps1s set ps1yn='Y',ps1ari=left(#tmp2.ps1ari,2)+':'+substring(#tmp2.ps1ari,3,2)+':'+substring(#tmp2.ps1ari,5,2),ps1lef=left(#tmp2.ps1lef,2)+':'+substring(#tmp2.ps1lef,3,2)+':'+substring(#tmp2.ps1lef,5,2),ps1hrs=#tmp2.ps1hrs,ps1hrs2=#tmp2.ps1hrs2,as1no=#tmp2.as1no,pl1no1=#tmp2.pl1no1,pl1no2=#tmp2.pl1no2,ps1memo=#tmp2.ps1memo from tempdb.#tmp2  where intra3.dbo.ps1s.ps1date=#tmp2.ps1date and (left(#tmp2.pl1no,3)=@pl1no or (#tmp2.pl1no=(select top 1 dp1no from usr where usrno=#tmp2.pe1no))) and intra3.dbo.ps1s.pe1no=#tmp2.pe1no and intra3.dbo.ps1s.as1no='-->無資料'
			drop table #tmp2
		end
	else                 --------(現場)
		begin
			select * into #tmp from ps1 where year(ps1date)=@byy and month(ps1date)=@bmm and pe1no between @pe1no and @ecode
			update intra3.dbo.ps1s set ps1yn='Y',ps1ari=left(#tmp.ps1ari,2)+':'+substring(#tmp.ps1ari,3,2)+':'+substring(#tmp.ps1ari,5,2),ps1lef=left(#tmp.ps1lef,2)+':'+substring(#tmp.ps1lef,3,2)+':'+substring(#tmp.ps1lef,5,2),ps1hrs=#tmp.ps1hrs,ps1hrs2=#tmp.ps1hrs2,as1no=#tmp.as1no,pl1no1=#tmp.pl1no1,pl1no2=#tmp.pl1no2,ps1memo=#tmp.ps1memo from tempdb.#tmp  where intra3.dbo.ps1s.pe1no=#tmp.pe1no and intra3.dbo.ps1s.ps1date=#tmp.ps1date and intra3.dbo.ps1s.nowno=@nowno and intra3.dbo.ps1s.as1no='-->無資料'
			drop table #tmp
		end
END
go

