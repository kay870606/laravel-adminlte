-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[pt1_D0408] (@nowno char(9),@byymm char(4),@mon1 int,@mon2 int)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	delete from intra3.dbo.pt1_D0408 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)

	insert into intra3.dbo.pt1_D0408(nowno,giftno,giftname,mqty,msum,cost) select @nowno,giftno,gift,sum(lottery+spend)as mqty,sum((lottery+spend)*cost)as msum,ROUND(ISNULL(sum((lottery+spend)*cost) / (NULLIF(sum(lottery+spend),0)),0),1)as cost from intranet2.dbo.stock where pl1no in (select dp1no from depcode where dp1lun='T') and date=@byymm and cost between @mon1 and @mon2 and lottery+spend<>0 group by giftno,gift order by mqty desc
END
go

