CREATE VIEW dbo.v_itn2_1
AS
SELECT          dbo.itn1.itnno, dbo.itn1.itnsub, dbo.itn1.endtime, dbo.itn1.itnlevel, dbo.itn2.usrno, dbo.itn1.usrno AS fromusr, 
                            dbo.itn2.itnstat, dbo.itn2.rectime, dbo.itn2.itntype, dbo.usr.usrname, dbo.itn2.no, usr_1.usrname AS fromusrname, 
                            dbo.itn2.itn2idate, dbo.itn2.vartime, dbo.itn2.bodynote, dbo.depcode.DP1NAME, dbo.itn1.itnbody, 
                            dbo.depcode.dp1lun, dbo.itn1.itn1edate, dbo.itn2.status, dbo.itn1.itn1date, dbo.usr.dep, usr_1.dep AS pl1no
FROM              dbo.depcode INNER JOIN
                            dbo.usr ON dbo.depcode.DP1NO = dbo.usr.dep INNER JOIN
                            dbo.itn1 INNER JOIN
                            dbo.itn2 ON dbo.itn1.no = dbo.itn2.no INNER JOIN
                            dbo.usr AS usr_1 ON dbo.itn1.usrno = usr_1.usrno ON dbo.usr.usrno = dbo.itn2.usrno
go

