-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[getad1g14] (@nowno char(9),@pl1no char(4),@dp1lun char(1),@bdate datetime,@edate datetime,@bcode char(10),@ecode char(10))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	declare @ac1tyy char(4),@ac1cyy char(4),@ac1pyy char(4),@byy char(4)
	declare @run varchar(450),@bt varchar(10),@et varchar(10),@accok char(1)
	
	set @bt=convert(varchar(10),@bdate,120)
	set @et=convert(varchar(10),@edate,120)
	set @byy=YEAR(@bdate)
	
	select @accok=accok from intranet.dbo.depcode where dp1no=@pl1no
	select @ac1tyy=ac1tyy,@ac1cyy=ac1cyy,@ac1pyy=ac1pyy from intranet.dbo.ac1yy
	if @dp1lun='T'
	begin
		if @bcode='' and @ecode='' ----科目代號空白
		begin
			if @byy<=@ac1tyy
				set @run='select ad1.ad1date,ad2.ad1no,ad2.ac2no,ad2.ac2no2,ad2.ac2name,ad2.ad1dc,ad2.ad1dmon,ad2.ad1cmon,ad2.ad1memo from intranet.dbo.ad1'+@byy+' as ad1,intranet.dbo.ad2'+@byy+' as ad2 where ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+@pl1no+''' and ad1.ad1date between '''+@bt+''' and '''+@et+''' and ad1.ad1no=ad2.ad1no '
			else
				set @run='select ad1.ad1date,ad2.ad1no,ad2.ac2no,ad2.ac2no2,ad2.ac2name,ad2.ad1dc,ad2.ad1dmon,ad2.ad1cmon,ad2.ad1memo from intranet.dbo.ad1,intranet.dbo.ad2 where ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+@pl1no+''' and ad1.ad1date between '''+@bt+''' and '''+@et+''' and ad1.ad1no=ad2.ad1no '
		end
		else
		begin
			if @byy<=@ac1tyy
				set @run='select ad1.ad1date,ad2.ad1no,ad2.ac2no,ad2.ac2no2,ad2.ac2name,ad2.ad1dc,ad2.ad1dmon,ad2.ad1cmon,ad2.ad1memo from intranet.dbo.ad1'+@byy+' as ad1,intranet.dbo.ad2'+@byy+' as ad2 where ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+ @pl1no+ '''  and (ad2.ac2no+ad2.ac2no2) between '''+@bcode+''' and '''+@ecode+''' and ad1.ad1date between '+@bt+' and '+@et+''' and ad1.ad1no=ad2.ad1no'
			else
			if @bdate is NULL
				set @run='select ad1.ad1date,ad2.ad1no,ad2.ac2no,ad2.ac2no2,ad2.ac2name,ad2.ad1dc,ad2.ad1dmon,ad2.ad1cmon,ad2.ad1memo from intranet.dbo.ad1,intranet.dbo.ad2 as ad2 where ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+ @pl1no+ '''  and (ad2.ac2no+ad2.ac2no2) between '''+@bcode+''' and '''+@ecode+''' and ad1.ad1no=ad2.ad1no and year(ad1.ad1date)='+@byy+' and ad2.ad1yy='+@byy
			else
				set @run='select ad1.ad1date,ad2.ad1no,ad2.ac2no,ad2.ac2no2,ad2.ac2name,ad2.ad1dc,ad2.ad1dmon,ad2.ad1cmon,ad2.ad1memo from intranet.dbo.ad1,intranet.dbo.ad2 as ad2 where ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+ @pl1no+ '''  and (ad2.ac2no+ad2.ac2no2) between '''+@bcode+''' and '''+@ecode+''' and ad1.ad1date between '''+@bt+''' and '''+@et+''' and ad1.ad1no=ad2.ad1no'
		end
		exec (@run)
	end
	if @dp1lun='C'
	begin
		if @bcode='' and @ecode='' ----科目代號空白
		begin
			if @byy<=@ac1cyy
				set @run='select ad1.ad1date,ad2.ad1no,ad2.ac2no,ad2.ac2no2,ad2.ac2name,ad2.ad1dc,ad2.ad1dmon,ad2.ad1cmon,ad2.ad1memo from intranet2.dbo.ad1o'+@byy+' as ad1,intranet2.dbo.ad2o'+@byy+' as ad2 where ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+@pl1no+''' and ad1.ad1date between '''+@bt+''' and '''+@et+''' and ad1.ad1no=ad2.ad1no '
			else
			begin
--				if @accok='Y'
					set @run='select ad1.ad1date,ad2.ad1no,ad2.ac2no,ad2.ac2no2,ad2.ac2name,ad2.ad1dc,ad2.ad1dmon,ad2.ad1cmon,ad2.ad1memo from intranet2.dbo.ad1c as ad1,intranet2.dbo.ad2c as ad2 where ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+@pl1no+''' and ad1.ad1date between '''+@bt+''' and '''+@et+''' and ad1.ad1no=ad2.ad1no '
--				else
--					set @run='select ad1.ad1date,ad2.ad1no,ad2.ac2no,ad2.ac2no2,ad2.ac2name,ad2.ad1dc,ad2.ad1dmon,ad2.ad1cmon,ad2.ad1memo from intranet2.dbo.ad1o as ad1,intranet2.dbo.ad2o as ad2 where ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+@pl1no+''' and ad1.ad1date between '''+@bt+''' and '''+@et+''' and ad1.ad1no=ad2.ad1no '
			end
		end
		else
		begin
			if @byy<=@ac1cyy
				set @run='select ad1.ad1date,ad2.ad1no,ad2.ac2no,ad2.ac2no2,ad2.ac2name,ad2.ad1dc,ad2.ad1dmon,ad2.ad1cmon,ad2.ad1memo from intranet2.dbo.ad1o'+@byy+' as ad1,intranet2.dbo.ad2o'+@byy+' as ad2 where ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+ @pl1no+ '''  and (ad2.ac2no+ad2.ac2no2) between '''+@bcode+''' and '''+@ecode+''' and ad1.ad1date between '+@bt+' and '+@et+''' and ad1.ad1no=ad2.ad1no'
			else
			begin
--				if @accok='Y'
					set @run='select ad1.ad1date,ad2.ad1no,ad2.ac2no,ad2.ac2no2,ad2.ac2name,ad2.ad1dc,ad2.ad1dmon,ad2.ad1cmon,ad2.ad1memo from intranet2.dbo.ad1c as ad1,intranet2.dbo.ad2c as ad2 where ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+ @pl1no+ '''  and (ad2.ac2no+ad2.ac2no2) between '''+@bcode+''' and '''+@ecode+''' and ad1.ad1date between '''+@bt+''' and '''+@et+''' and ad1.ad1no=ad2.ad1no'
--				else
--					set @run='select ad1.ad1date,ad2.ad1no,ad2.ac2no,ad2.ac2no2,ad2.ac2name,ad2.ad1dc,ad2.ad1dmon,ad2.ad1cmon,ad2.ad1memo from intranet2.dbo.ad1o as ad1,intranet2.dbo.ad2o as ad2 where ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+ @pl1no+ '''  and (ad2.ac2no+ad2.ac2no2) between '''+@bcode+''' and '''+@ecode+''' and ad1.ad1date between '''+@bt+''' and '''+@et+''' and ad1.ad1no=ad2.ad1no'
			end
		end
		exec (@run)
		--select @run as cc
	end
	if @dp1lun='P'
	begin
		if @bcode='' and @ecode='' ----科目代號空白
		begin
			if @byy<=@ac1pyy
--				set @run='select ad1.ad1date,ad2.ad1no,ad2.ac2no,ad2.ac2no2,ad2.ac2name,ad2.ad1dc,ad2.ad1dmon,ad2.ad1cmon,ad2.ad1memo from intranet2.dbo.ad1o'+@byy+' as ad1,intranet2.dbo.ad2o'+@byy+' as ad2 where ad1.ad1no=ad2.ad1no and ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+@pl1no+''' and ad1.ad1date between '''+@bt+' and '''+@et
				set @run='select ad1.ad1date,ad2.ad1no,ad2.ac2no,ad2.ac2no2,ad2.ac2name,ad2.ad1dc,ad2.ad1dmon,ad2.ad1cmon,ad2.ad1memo from intranet2.dbo.ad1o'+@byy+' as ad1,intranet2.dbo.ad2o'+@byy+' as ad2 where ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+@pl1no+''' and ad1.ad1date between '''+@bt+''' and '''+@et+''' and ad1.ad1no=ad2.ad1no '
			else
				--set @run='select ad1.ad1date,ad2.ad1no,ad2.ac2no,ad2.ac2no2,ad2.ac2name,ad2.ad1dc,ad2.ad1dmon,ad2.ad1cmon,ad2.ad1memo from intranet2.dbo.ad1o as ad1,intranet2.dbo.ad2o as ad2 where ad1.ad1no=ad2.ad1no and ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+@pl1no+''' and ad1.ad1date between '+@bt+' and '+@et
				set @run='select ad1.ad1date,ad2.ad1no,ad2.ac2no,ad2.ac2no2,ad2.ac2name,ad2.ad1dc,ad2.ad1dmon,ad2.ad1cmon,ad2.ad1memo from intranet2.dbo.ad1o as ad1,intranet2.dbo.ad2o as ad2 where ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+@pl1no+''' and ad1.ad1date between '''+@bt+''' and '''+@et+''' and ad1.ad1no=ad2.ad1no '
		end
		else
		begin
			if @byy<=@ac1pyy
				--set @run='select ad1.ad1date,ad2.ad1no,ad2.ac2no,ad2.ac2no2,ad2.ac2name,ad2.ad1dc,ad2.ad1dmon,ad2.ad1cmon,ad2.ad1memo from intranet2.dbo.ad1o'+@byy+' as ad1,intranet2.dbo.ad2o'+@byy+' as ad2 where ad1.ad1no=ad2.ad1no and ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+ @pl1no+ '''  and (ad2.ac2no+ad2.ac2no2) between '''+@bcode+''' and '''+@ecode+''' and ad1.ad1date between '+@bt+' and '+@et
				set @run='select ad1.ad1date,ad2.ad1no,ad2.ac2no,ad2.ac2no2,ad2.ac2name,ad2.ad1dc,ad2.ad1dmon,ad2.ad1cmon,ad2.ad1memo from intranet2.dbo.ad1o'+@byy+' as ad1,intranet2.dbo.ad2o'+@byy+' as ad2 where ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+ @pl1no+ '''  and (ad2.ac2no+ad2.ac2no2) between '''+@bcode+''' and '''+@ecode+''' and ad1.ad1date between '+@bt+' and '+@et+''' and ad1.ad1no=ad2.ad1no'
			else
--				set @run='select ad1.ad1date,ad2.ad1no,ad2.ac2no,ad2.ac2no2,ad2.ac2name,ad2.ad1dc,ad2.ad1dmon,ad2.ad1cmon,ad2.ad1memo from intranet2.dbo.ad1o as ad1,intranet2.dbo.ad2o as ad2 where ad1.ad1no=ad2.ad1no and ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+ @pl1no+ '''  and (ad2.ac2no+ad2.ac2no2) between '''+@bcode+''' and '''+@ecode+''' and ad1.ad1date between '+@bt+' and '+@et
					set @run='select ad1.ad1date,ad2.ad1no,ad2.ac2no,ad2.ac2no2,ad2.ac2name,ad2.ad1dc,ad2.ad1dmon,ad2.ad1cmon,ad2.ad1memo from intranet2.dbo.ad1o as ad1,intranet2.dbo.ad2o as ad2 where ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+ @pl1no+ '''  and (ad2.ac2no+ad2.ac2no2) between '''+@bcode+''' and '''+@ecode+''' and ad1.ad1date between '''+@bt+''' and '''+@et+''' and ad1.ad1no=ad2.ad1no'
		end
		exec (@run)
	end
END
go

