CREATE VIEW dbo.v_gl4
AS
SELECT          dbo.ge1.ge1name, dbo.gl4.pl1no, dbo.gl4.gl3month, dbo.gl4.ge1no, dbo.gl4.gl1pi, dbo.gl4.gl4mon, dbo.gl4.gl4mon2, 
                            dbo.gl4.ge1bname, dbo.gl4.gl4mon3, dbo.gl4.gl4memo, dbo.gl4.ge1bc, dbo.gl4.ge1bb, dbo.gl4.ge1ba, dbo.gl4.ge1bn, 
                            dbo.gl3.gl3mon, dbo.gl3.gl3mon2, dbo.depcode.dp1lun, dbo.ge1.ge1mtype, dbo.ge1.ge1mtype2, dbo.ge1.ge1no1, 
                            dbo.gl4.gl3t3040
FROM              dbo.ge1 INNER JOIN
                            dbo.gl4 ON dbo.ge1.ge1no = dbo.gl4.ge1no INNER JOIN
                            dbo.gl3 ON dbo.gl4.pl1no = dbo.gl3.pl1no AND dbo.gl4.gl3month = dbo.gl3.gl3month INNER JOIN
                            dbo.depcode ON dbo.gl4.pl1no = dbo.depcode.DP1NO
go

