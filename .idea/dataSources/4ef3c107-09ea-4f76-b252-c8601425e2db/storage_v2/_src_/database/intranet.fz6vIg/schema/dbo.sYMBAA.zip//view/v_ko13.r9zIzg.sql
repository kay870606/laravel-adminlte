CREATE VIEW dbo.v_ko13
AS
SELECT          dbo.ap1.ap1giv, dbo.ap1.ap1mac, dbo.ap1.ap1oth, dbo.ap1.ap1oth2, dbo.ap1.ap1ym, dbo.su1.su1tl, dbo.su1.su1no, 
                            dbo.su1.ecomp, dbo.ap1.su1mon
FROM              dbo.ap1 INNER JOIN
                            dbo.su1 ON dbo.ap1.su1no = dbo.su1.su1no
go

