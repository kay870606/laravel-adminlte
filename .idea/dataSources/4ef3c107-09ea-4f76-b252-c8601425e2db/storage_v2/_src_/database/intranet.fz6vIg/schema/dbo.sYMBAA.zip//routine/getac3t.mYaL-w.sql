-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[getac3t] (@nowno char(9),@pl1no varchar(10),@ac3yy char(4),@dp1lun char(1))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
	if (select object_id('tempdb..#tmp2'))is not null
	begin
		drop table #tmp2;
	end
	if (select object_id('tempdb..#tmp4'))is not null
	begin
		drop table #tmp4;
	end
	delete from intra3.dbo.ac3t where ac3idate<CONVERT(nvarchar(30), GETDATE(), 111)
	delete from intra3.dbo.ac3t313 where ac2idate<CONVERT(nvarchar(30), GETDATE(), 111)
	delete from intra3.dbo.ac3t where nowno=@nowno
	
	create table #tmp3 (mm char(2),ac2no1 char(10),ac2no char(4),ac2no2 char(6),ad1dmon decimal(12, 2),ad1cmon decimal(12, 2))
	if @dp1lun='T'
	BEGIN
		select @nowno as nowno,ac3num,pl1no,ac3yy,ac2no,ac2no2,ac2name,ac2eng,ac2type, ac3mb1,ac3mb2 into #tmp from ac3 where pl1no=@pl1no and ac3yy=@ac3yy order by ac2no,ac2no2;
		insert into intra3.dbo.ac3t (nowno,ac3num,pl1no,dp1lun,ac3yy,ac2no1,ac2no,ac2no2,ac2name,ac2eng,ac2type,ac3mb1,ac3mb2) select nowno,ac3num,pl1no,@dp1lun,ac3yy,ac2no+ac2no2,ac2no,ac2no2,ac2name,ac2eng,ac2type,ac3mb1,ac3mb2 from tempdb.#tmp
--		update intra3.dbo.ac3t set ac3t.dp1name=d.dp1name,ac3t.dp1lun2=d.dp1lun2 from intranet.dbo.depcode as d where d.dp1no=ac3t.pl1no
--		update intra3.dbo.ac3t set ac3t.lu1sort=lu1.lu1sort from intranet.dbo.lu1 where lu1.lu1no=ac3t.dp1lun2
		drop table #tmp
		insert into #tmp3 execute getad1g @nowno,@pl1no,@ac3yy,@dp1lun
		delete from intra3.dbo.ac3t2 where nowno=@nowno
		insert into intra3.dbo.ac3t2 (nowno,pl1no,ac3yy,ac3mm,ac2no1,ac2no,ac2no2,ad1dmon,ad1cmon) select @nowno,@pl1no,@ac3yy,mm,ac2no+ac2no2,ac2no,ac2no2,ad1dmon,ad1cmon from #tmp3
	END
	if @dp1lun='P' or @dp1lun='C'
	BEGIN
		select @nowno as nowno,ac3num,pl1no,ac3yy,ac2no,ac2no2,ac2name,ac2eng,ac2type, ac3mb1,ac3mb2 into #tmp2 from intranet2.dbo.ac3o where pl1no=@pl1no and ac3yy=@ac3yy order by ac2no,ac2no2;
		insert into intra3.dbo.ac3t (nowno,ac3num,pl1no,dp1lun,ac3yy,ac2no1,ac2no,ac2no2,ac2name,ac2eng,ac2type,ac3mb1,ac3mb2) select nowno,ac3num,pl1no,@dp1lun,ac3yy,ac2no+ac2no2,ac2no,ac2no2,ac2name,ac2eng,ac2type,ac3mb1,ac3mb2 from tempdb.#tmp2
		--update intra3.dbo.ac3t set dp1name=d.dp1name,dp1lun2=d.dp1lun2 from intranet.dbo.depcode as d where ac3t.pl1no=d.dp1no and nowno=@nowno
		--update intra3.dbo.ac3t set lu1sort=lu1.lu1sort from intranet.dbo.lu1 where lu1.lu1no=ac3t.dp1lun2 and nowno=@nowno
		drop table #tmp2

		insert into #tmp3 execute getad1g @nowno,@pl1no,@ac3yy,@dp1lun
		delete from intra3.dbo.ac3t2 where nowno=@nowno
		insert into intra3.dbo.ac3t2 (nowno,pl1no,ac3yy,ac3mm,ac2no1,ac2no,ac2no2,ad1dmon,ad1cmon) select @nowno,@pl1no,@ac3yy,mm,ac2no+ac2no2,ac2no,ac2no2,ad1dmon,ad1cmon from #tmp3
	END
		drop table #tmp3
END
go

