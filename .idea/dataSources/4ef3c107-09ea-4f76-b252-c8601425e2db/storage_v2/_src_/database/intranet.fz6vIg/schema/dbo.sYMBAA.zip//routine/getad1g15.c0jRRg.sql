-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[getad1g15] (@nowno char(9),@pl1no char(4),@dp1lun char(1),@byy char(4),@bcode char(8),@ecode char(8))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	declare @ac1tyy char(4),@ac1cyy char(4),@ac1pyy char(4),@ac3yy char(4)
	declare @run varchar(550),@accok char(1)
	
	select @accok=accok from intranet.dbo.depcode where dp1no=@pl1no
	select @ac1tyy=ac1tyy,@ac1cyy=ac1cyy,@ac1pyy=ac1pyy from intranet.dbo.ac1yy
	if @dp1lun='T'
	begin
		if(@bcode='' and @ecode='')
		begin
			if @byy<=@ac1tyy
				set @run='select ad1.ad1date,ad2.ad1no,ad2.ac2no,ad2.ac2no2,ad2.ac2name,ad2.ad1dc,ad2.ad1dmon,ad2.ad1cmon,ad2.ad1memo from ad1'+@byy+' as ad1,ad2'+@byy+' as ad2 where ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+@pl1no+''' and year(ad1.ad1date)='+@byy+' and ad1.ad1no=ad2.ad1no order by ad1.ad1no,ad2.ad1num'
			else
				set @run='select ad1.ad1date,ad2.ad1no,ad2.ac2no,ad2.ac2no2,ad2.ac2name,ad2.ad1dc,ad2.ad1dmon,ad2.ad1cmon,ad2.ad1memo from ad1,ad2 where ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+@pl1no+''' and year(ad1.ad1date)='+@byy+' and ad1.ad1no=ad2.ad1no order by ad1.ad1no,ad2.ad1num'
		end
		else
		begin
			if @byy<=@ac1tyy
				set @run='select ad1.ad1date,ad2.ad1no,ad2.ac2no,ad2.ac2no2,ad2.ac2name,ad2.ad1dc,ad2.ad1dmon,ad2.ad1cmon,ad2.ad1memo from ad1'+@byy+' as ad1,ad2'+@byy+' as ad2 where ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+@pl1no+''' and ad1.ad1no between '''+@bcode+''' and '''+@ecode+''' and year(ad1.ad1date)='+@byy+' and ad1.ad1no=ad2.ad1no order by ad1.ad1no,ad2.ad1num'
			else
				set @run='select ad1.ad1date,ad2.ad1no,ad2.ac2no,ad2.ac2no2,ad2.ac2name,ad2.ad1dc,ad2.ad1dmon,ad2.ad1cmon,ad2.ad1memo from ad1,ad2 where ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+@pl1no+''' and ad1.ad1no between '''+@bcode+''' and '''+@ecode+''' and year(ad1.ad1date)='+@byy+' and ad1.ad1no=ad2.ad1no order by ad1.ad1no,ad2.ad1num'
		end
		exec (@run)
	end
	if @dp1lun='C'
	begin
		if(@bcode='' and @ecode='')
		begin
			if @byy<=@ac1cyy
				set @run='select ad1.ad1date,ad2.ad1no,ad2.ac2no,ad2.ac2no2,ad2.ac2name,ad2.ad1dc,ad2.ad1dmon,ad2.ad1cmon,ad2.ad1memo from intranet2.dbo.ad1o'+@byy+' as ad1,intranet2.dbo.ad2o'+@byy+' as ad2 where ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+@pl1no+''' and year(ad1.ad1date)='+@byy+' and ad1.ad1no+ad1.pl1no=ad2.ad1no+ad2.pl1no order by ad1.ad1no,ad2.ad1num'
			else
				set @run='select ad1.ad1date,ad2.ad1no,ad2.ac2no,ad2.ac2no2,ad2.ac2name,ad2.ad1dc,ad2.ad1dmon,ad2.ad1cmon,ad2.ad1memo from intranet2.dbo.ad1c as ad1,intranet2.dbo.ad2c as ad2 where ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+@pl1no+''' and year(ad1.ad1date)='+@byy+' and ad1.ad1no=ad2.ad1no order by ad1.ad1no,ad2.ad1num'
		end
		else
		begin
			if @byy<=@ac1cyy
				set @run='select ad1.ad1date,ad2.ad1no,ad2.ac2no,ad2.ac2no2,ad2.ac2name,ad2.ad1dc,ad2.ad1dmon,ad2.ad1cmon,ad2.ad1memo from intranet2.dbo.ad1o'+@byy+' as ad1,intranet2.dbo.ad2o'+@byy+' as ad2 where ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+@pl1no+''' and ad1.ad1no between '''+@bcode+''' and '''+@ecode+''' and year(ad1.ad1date)='+@byy+' and ad1.ad1no+ad1.pl1no=ad2.ad1no+ad2.pl1no order by ad1.ad1no,ad2.ad1num'
			else
				set @run='select ad1.ad1date,ad2.ad1no,ad2.ac2no,ad2.ac2no2,ad2.ac2name,ad2.ad1dc,ad2.ad1dmon,ad2.ad1cmon,ad2.ad1memo from intranet2.dbo.ad1c as ad1,intranet2.dbo.ad2c as ad2 where ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+@pl1no+''' and ad1.ad1no between '''+@bcode+''' and '''+@ecode+''' and year(ad1.ad1date)='+@byy+' and ad1.ad1no+ad1.pl1no=ad2.ad1no+ad2.pl1no order by ad1.ad1no,ad2.ad1num'
		end
		exec (@run)
		--select @run as cc
	end
	if @dp1lun='P'
	begin
		if(@bcode='' and @ecode='')
		begin
			if @byy<=@ac1pyy
				set @run='select ad1.ad1date,ad2.ad1no,ad2.ac2no,ad2.ac2no2,ad2.ac2name,ad2.ad1dc,ad2.ad1dmon,ad2.ad1cmon,ad2.ad1memo from intranet2.dbo.ad1o'+@byy+' as ad1,intranet2.dbo.ad2o'+@byy+' as ad2 where ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+@pl1no+''' and year(ad1.ad1date)='+@byy+' and ad1.ad1no=ad2.ad1no order by ad1.ad1no,ad2.ad1num'
			else
				set @run='select ad1.ad1date,ad2.ad1no,ad2.ac2no,ad2.ac2no2,ad2.ac2name,ad2.ad1dc,ad2.ad1dmon,ad2.ad1cmon,ad2.ad1memo from intranet2.dbo.ad1o as ad1,intranet2.dbo.ad2o as ad2 where ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+@pl1no+''' and year(ad1.ad1date)='+@byy+' and ad1.ad1no=ad2.ad1no order by ad1.ad1no,ad2.ad1num'
		end
		else
		begin
			if @byy<=@ac1pyy
				set @run='select ad1.ad1date,ad2.ad1no,ad2.ac2no,ad2.ac2no2,ad2.ac2name,ad2.ad1dc,ad2.ad1dmon,ad2.ad1cmon,ad2.ad1memo from intranet2.dbo.ad1o'+@byy+' as ad1,intranet2.dbo.ad2o'+@byy+' as ad2 where ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+@pl1no+''' and ad1.ad1no between '''+@bcode+''' and '''+@ecode+''' and year(ad1.ad1date)='+@byy+' and ad1.ad1no=ad2.ad1no order by ad1.ad1no,ad2.ad1num'
			else
				set @run='select ad1.ad1date,ad2.ad1no,ad2.ac2no,ad2.ac2no2,ad2.ac2name,ad2.ad1dc,ad2.ad1dmon,ad2.ad1cmon,ad2.ad1memo from intranet2.dbo.ad1o as ad1,intranet2.dbo.ad2o as ad2 where ad1.pl1no='''+@pl1no+''' and ad2.pl1no='''+@pl1no+''' and ad1.ad1no between '''+@bcode+''' and '''+@ecode+''' and year(ad1.ad1date)='+@byy+' and ad1.ad1no=ad2.ad1no order by ad1.ad1no,ad2.ad1num'
		end
		exec (@run)
	end

END
go

