-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[pe1b0801] (@nowno char(9),@yy char(4),@pl1no char(4),@yn char(1))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	delete from intra3.dbo.pe1_b0801 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
	if @yn='N'  -----不含離職員工
	begin
		if @pl1no=''
		begin
			insert into intra3.dbo.pe1_b0801 (nowno,pl1no,pe1no,usrname,ph1date,ph1hrs,sp1hrs,pf1lef) select @nowno,ph1.pl1no,ph1.pe1no,usr.usrname,ph1.ph1date,ph1.ph1hrs,(select sp1hrs from sp1 where sp1.sp1yy=@yy and sp1.pe1no=ph1.pe1no) as sp1hrs,usr.pf1lef from ph1,usr where ph1.pe1no=usr.usrno and ph1.hl1no='D' and usr.pf1lef is null and ph1.pl1no in (select dp1no from depcode where dp1lun='T') and year(ph1.ph1date)=@yy order by ph1.pl1no,ph1.pe1no,ph1.ph1date
		end
		else
		begin
			insert into intra3.dbo.pe1_b0801 (nowno,pl1no,pe1no,usrname,ph1date,ph1hrs,sp1hrs,pf1lef) select @nowno,ph1.pl1no,ph1.pe1no,usr.usrname,ph1.ph1date,ph1.ph1hrs,(select sp1hrs from sp1 where sp1.sp1yy=@yy and sp1.pe1no=ph1.pe1no) as sp1hrs,usr.pf1lef from ph1,usr where ph1.pe1no=usr.usrno and ph1.hl1no='D' and usr.pf1lef is null and ph1.pl1no=@pl1no and year(ph1.ph1date)=@yy order by ph1.pl1no,ph1.pe1no,ph1.ph1date
		end
	end
	else
	begin
		if @pl1no=''
		begin
			insert into intra3.dbo.pe1_b0801 (nowno,pl1no,pe1no,usrname,ph1date,ph1hrs,sp1hrs,pf1lef) select @nowno,ph1.pl1no,ph1.pe1no,usr.usrname,ph1.ph1date,ph1.ph1hrs,(select sp1hrs from sp1 where sp1.sp1yy=@yy and sp1.pe1no=ph1.pe1no) as sp1hrs,usr.pf1lef from ph1,usr where ph1.pe1no=usr.usrno and ph1.hl1no='D' and (usr.pf1lef is null or year(usr.pf1lef)=2018) and ph1.pl1no in (select dp1no from depcode where dp1lun='T') and year(ph1.ph1date)=@yy order by ph1.pl1no,ph1.pe1no,ph1.ph1date
		end
		else
		begin
			insert into intra3.dbo.pe1_b0801 (nowno,pl1no,pe1no,usrname,ph1date,ph1hrs,sp1hrs,pf1lef) select @nowno,ph1.pl1no,ph1.pe1no,usr.usrname,ph1.ph1date,ph1.ph1hrs,(select sp1hrs from sp1 where sp1.sp1yy=@yy and sp1.pe1no=ph1.pe1no) as sp1hrs,usr.pf1lef from ph1,usr where ph1.pe1no=usr.usrno and ph1.hl1no='D' and (usr.pf1lef is null or year(usr.pf1lef)=2018) and ph1.pl1no=@pl1no and year(ph1.ph1date)=@yy order by ph1.pl1no,ph1.pe1no,ph1.ph1date
		end
	end

	update intra3.dbo.pe1_b0801 set sp1hrs=0 where sp1hrs is null
END
go

