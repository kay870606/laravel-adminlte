-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[in1_a0204_2] (@nowno char(9),@nowno2 char(9),@dp1lun char(1),@dp1yn2 char(1),@byy char(4),@byy2 char(4),@bmm char(2),@mon21 char(1))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	declare @yy char(4),@yy2 char(4)
	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
delete from intra3.dbo.in1_A0126_2 where nowno=@nowno2 or idate<CONVERT(nvarchar(30), GETDATE(), 111)
if @dp1yn2='1' --全部
insert into intra3.dbo.in1_A0126_2 (nowno,pl1no,pl1name,dp1yn2,lu1no) select @nowno2,pl1no,(select dp1name from depcode where dp1no=pl1no),dp1yn2,dp1lun2 from intra3.dbo.dp1ch where nowno=@nowno and fu1no='A0204' and dp1lun=@dp1lun and dp1over<>'Y' and dp1yn='Y'
if @dp1yn2='2' --不含衛星點
insert into intra3.dbo.in1_A0126_2 (nowno,pl1no,pl1name,dp1yn2,lu1no) select @nowno2,pl1no,(select dp1name from depcode where dp1no=pl1no),dp1yn2,dp1lun2 from intra3.dbo.dp1ch where nowno=@nowno and fu1no='A0204' and dp1lun=@dp1lun and dp1over<>'Y' and dp1yn='Y' and dp1yn2<>'Y'
if @dp1yn2='3' --只有衛星點
insert into intra3.dbo.in1_A0126_2 (nowno,pl1no,pl1name,dp1yn2,lu1no) select @nowno2,pl1no,(select dp1name from depcode where dp1no=pl1no),dp1yn2,dp1lun2 from intra3.dbo.dp1ch where nowno=@nowno and fu1no='A0204' and dp1lun=@dp1lun and dp1over<>'Y' and dp1yn='Y' and dp1yn2='Y'

update intra3.dbo.in1_A0126_2 set lu1name=(select lu1name from lu1 where lu1no=intra3.dbo.in1_A0126_2.lu1no) where nowno=@nowno2
update intra3.dbo.in1_A0126_2 set lu1dno=(select lu1dno from lu1 where lu1no=intra3.dbo.in1_A0126_2.lu1no) where nowno=@nowno2
update intra3.dbo.in1_A0126_2 set lu1sort=(select lu1sort from lu1 where lu1no=intra3.dbo.in1_A0126_2.lu1no) where nowno=@nowno2
update intra3.dbo.in1_A0126_2 set lu1dname=(select lu2name from lu2 where lu2no=intra3.dbo.in1_A0126_2.lu1dno) where nowno=@nowno2
create table #tmp (dp1no char(4),yy2 char(4),mon decimal(10, 0))
insert into #tmp (dp1no,yy2,mon) select pl1no, year(bk1date) as yy2, sum(bk1cah+bk1oth2+bk1oth+bk1mon3+bk1mon2) as mon from intranet2.dbo.in2 where (year(bk1date)=@byy or year(bk1date)=@byy2) and month(bk1date) between 1 and @bmm and pl1no in (select pl1no from intra3.dbo.dp1ch where nowno=@nowno and fu1no='A0204' and dp1lun=@dp1lun) group by pl1no,year(bk1date) order by pl1no,yy2
--select * from #tmp order by pl1no,yy2
update intra3.dbo.in1_A0126_2 set in1mon=(select mon from #tmp where yy2=@byy2 and dp1no=pl1no)
update intra3.dbo.in1_A0126_2 set in1pmon=(select mon from #tmp where yy2=@byy and dp1no=pl1no)
--update intra3.dbo.in1_A0126_3 set in1mon=(select sum(in1mon) from intra3.dbo.in1_A0126_2 where lu1dno=in1_A0126_3.lu1dno and nowno=in1_A0126_3.nowno)
--update intra3.dbo.in1_A0126_3 set in1pmon=(select sum(in1pmon) from intra3.dbo.in1_A0126_2 where lu1dno=in1_A0126_3.lu1dno and nowno=in1_A0126_3.nowno)
update intra3.dbo.in1_A0126_2 set in1mon=0 where in1mon is null
update intra3.dbo.in1_A0126_2 set in1pmon=0 where in1pmon is null
update intra3.dbo.in1_A0126_2 set in1pmon=in1pmon/@mon21,in1mon=in1mon/@mon21 where nowno=@nowno2
delete from intra3.dbo.in1_A0126_2 where in1pmon=0 and in1mon=0 and nowno=@nowno2
select * from intra3.dbo.in1_A0126_2 order by lu1dno

drop table #tmp

END
go

