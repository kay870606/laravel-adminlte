-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[pt1_D0406] (@giftno1 char(3),@giftno2 char(3))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	delete from intra3.dbo.pt1_D0406

	--insert into intra3.dbo.pt1_D0406(giftno,gift,date) select giftno,(select gift from pt1 where giftno=intranet2.dbo.todayrep.giftno)as gift,'0'+max(date) from intranet2.dbo.todayrep where right(left(giftno,5),3) between @giftno1 and @giftno2 and left(date,1)<>0  group by giftno
	--insert into intra3.dbo.pt1_D0406(giftno,gift,date) select giftno,(select gift from pt1 where giftno=intranet2.dbo.todayrep.giftno)as gift,'1'+max(date) from intranet2.dbo.todayrep where right(left(giftno,5),3) between @giftno1 and @giftno2 and left(date,1)=0 group by giftno

	--insert into intra3.dbo.pt1_D0406(giftno,date) select giftno,'0'+max(date) from intranet4.dbo.todayrep where right(left(giftno,5),3) between @giftno1 and @giftno2 and left(date,1)<>0  group by giftno
	--insert into intra3.dbo.pt1_D0406(giftno,date) select giftno,'1'+max(date) from intranet4.dbo.todayrep where right(left(giftno,5),3) between @giftno1 and @giftno2 and left(date,1)=0 group by giftno
	insert into intra3.dbo.pt1_D0406(giftno,gift,date) select giftno,gift,CONVERT(char(8),max(date),112) from intranet4.dbo.todayrep where right(left(giftno,5),3) between @giftno1 and @giftno2 group by giftno,gift
	
	
	update intra3.dbo.pt1_D0406 set gift=pt1.gift from pt1 join intra3.dbo.pt1_D0406 on pt1.giftno=intra3.dbo.pt1_D0406.giftno --補的 2018/08/31
END
go

