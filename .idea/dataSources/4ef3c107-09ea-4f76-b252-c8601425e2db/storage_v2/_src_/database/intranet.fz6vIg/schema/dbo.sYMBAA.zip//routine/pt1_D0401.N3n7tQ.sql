-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[pt1_D0401] (@nowno char(9),@bpos char(1),@pl1no char(4),@byyyy char(4),@byyy char(4),@byy char(4),@bmm char(2),@eyyyy char(4),@eyyy char(4),@eyy char(4),@emm char(2),@year100 int,@nmm int)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
	if (select object_id('tempdb..#tmp2'))is not null
	begin
		drop table #tmp2;
	end
	if (select object_id('tempdb..#tmp3'))is not null
	begin
		drop table #tmp3;
	end
	
	
if @bpos='1'
	begin
		delete from intra3.dbo.pt1_D0401 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
		insert into intra3.dbo.pt1_D0401 (nowno,date,pl1no,giftno,giftname,cost,msum,lottery,spend,mtotal) select @nowno,@byy+@bmm,@pl1no,giftno, gift, cost,(lottery+spend) as msum,lottery,spend,ROUND((lottery+spend)*cost,0)as mtotal from intranet4.dbo.stock where pl1no=@pl1no and date=@byyyy+@bmm order by msum desc
	end
else if @bpos='2'
	begin
		delete from intra3.dbo.pt1_D0401 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
		insert into intra3.dbo.pt1_D0401 (nowno,date,pl1no,giftno,giftname,cost,msum,lottery,spend,mtotal) select @nowno,@byy+@bmm,@pl1no,giftno, gift, cost,(lottery+spend) as msum,lottery,spend,ROUND((lottery+spend)*cost,0)as mtotal from intranet4.dbo.stock where pl1no=@pl1no and date=@byyyy+@bmm order by msum desc
	end
else if @bpos='3'
	begin
		delete from intra3.dbo.pt1_D0401 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
		insert into intra3.dbo.pt1_D0401 (nowno,date,pl1no,giftno,giftname,cost,msum,lottery,spend,mtotal) select @nowno,@byy+@bmm,@pl1no,giftno, gift, cost,(lottery+spend) as msum,lottery,spend,ROUND((lottery+spend)*cost,0)as mtotal from intranet4.dbo.stock where left(gift,4)='TOMS' and pl1no=@pl1no and date=@byyyy+@bmm order by msum desc
	end
else if @bpos='4'
	begin
		delete from intra3.dbo.pt1_D0401_4 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
		delete from intra3.dbo.pt1_D0401_restock where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
	
		create table #tmp (nowno char(9),giftno char(8),gift nvarchar(50),cost decimal(10, 3),talking decimal(6, 0),mdate date)
		select * into #tmp22 from intranet4.dbo.stock where date=@byyyy+@bmm and pl1no=@pl1no
		select * into #tmp23 from intranet4.dbo.todayrep where left(giftno,2)<>'AU' and talking>0 and point>0 and pl1no=@pl1no and year(date)=@byyyy and month(date)=@bmm
		insert into #tmp (nowno,giftno,gift,cost,talking,mdate) select @nowno,giftno,gift,(select top 1 cost from #tmp22 where giftno=#tmp23.giftno order by date desc) as cost,talking,date from #tmp23 where left(giftno,2)<>'AU' and talking>0 and point>0 and pl1no=@pl1no and year(date)=@byyyy and month(date)=@bmm
		drop table #tmp22
		drop table #tmp23

		insert into intra3.dbo.pt1_D0401_4 (nowno,pl1no,date,giftno) select @nowno,@pl1no,@byyyy+@bmm,giftno from #tmp group by giftno
		update intra3.dbo.pt1_D0401_4 set giftname=#tmp.gift from #tmp where intra3.dbo.pt1_D0401_4.giftno=#tmp.giftno
		update intra3.dbo.pt1_D0401_4 set cost=#tmp.cost from #tmp where intra3.dbo.pt1_D0401_4.giftno=#tmp.giftno
		update intra3.dbo.pt1_D0401_4 set talking=#tmp.talking from #tmp where intra3.dbo.pt1_D0401_4.giftno=#tmp.giftno
		update intra3.dbo.pt1_D0401_4 set mdate=#tmp.mdate from #tmp where intra3.dbo.pt1_D0401_4.giftno=#tmp.giftno
		
		delete from intra3.dbo.pt1_D0401_4 where nowno=@nowno and cost is null
		
		insert into intra3.dbo.pt1_D0401_restock (nowno,giftno,date,qty) select @nowno,giftno,date,qty from intranet4.dbo.restock where pl1no=@pl1no and ban<>'S' and giftno in (select giftno from intra3.dbo.pt1_D0401_4 where nowno=@nowno)

	end
else if @bpos='5'
	begin
		delete from intra3.dbo.pt1_D0401_5 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
		create table #tmp2 (giftno_2 char(8),date_2 char(6),cost_2 decimal(8, 1))
		
		insert into #tmp2 (giftno_2,date_2,cost_2) select giftno,CONVERT(char(6),year(date)+month(date)),cost from intranet4.dbo.restock where pl1no=@pl1no group by giftno,date,cost order by date desc
		
		insert into intra3.dbo.pt1_D0401_5 (nowno,pl1no,date,giftno,giftname,msum,cost,msum2,mnn,mqty) select @nowno,@pl1no,@byyyy+@bmm,giftno, gift,sum(lottery+spend) as msum,0,0,0,0 from intranet4.dbo.stock where left(gift,4)='TOMS' and pl1no=@pl1no and left(date,6) between @byyyy+@bmm and @eyyyy+@emm group by giftno,gift order by msum desc
		update intra3.dbo.pt1_D0401_5 set msum2=round(msum*cost_2,2),cost=cost_2 from #tmp2 where giftno_2=intra3.dbo.pt1_D0401_5.giftno
	
		
		create table #tmp3 (giftno char(8),cou decimal(4))
		insert into #tmp3 (giftno,cou) select giftno,count(*) #tmp from intranet4.dbo.stock where giftno in (select giftno from intra3.dbo.pt1_D0401_5) and date between @byyyy+@bmm and @eyyyy+@emm and (lottery+spend)<>0 and pl1no=@pl1no group by date,giftno,lottery,spend
		update intra3.dbo.pt1_D0401_5 set mnn=(select count(cou) from #tmp3 where #tmp3.giftno=intra3.dbo.pt1_D0401_5.giftno) where nowno=@nowno

		update intra3.dbo.pt1_D0401_5 set mqty=round(ISNULL(msum/(NULLIF(mnn,0)),0),0) where nowno=@nowno

	end
else
	insert into intra3.dbo.pt1_D0401 (nowno,date,pl1no,giftno,giftname,cost,msum,lottery,spend,mtotal) select @nowno,@byyyy+@bmm,@pl1no,giftno, gift, cost,(lottery+spend) as msum,lottery,spend,ROUND((lottery+spend)*cost,0)as mtotal from intranet4.dbo.stock where pl1no=@pl1no and left(date,6) between @byyyy+@bmm and CONVERT(char(4),datepart(yyyy,getdate()))+CONVERT(char(2),datepart(mm,getdate())) order by msum desc


	if(@bpos<>'4' and @bpos<>'5')
	begin
	update intra3.dbo.pt1_D0401 set spend=spendt
    from (select t.giftno ,sum(beuse) spendt
      from intranet4.dbo.mstock as t where date=@byyyy+@bmm and kindno<>'B' and pl1no=@pl1no group by t.giftno) Grouped 		
	where intra3.dbo.pt1_D0401.giftno = Grouped.giftno and nowno=@nowno

	update intra3.dbo.pt1_D0401 set spend1=spend1t
    from (select t.giftno ,sum(beuse) spend1t
      from intranet4.dbo.mstock as t where date=@byyyy+@bmm and kindno='B' and pl1no=@pl1no group by t.giftno) Grouped 		
	where intra3.dbo.pt1_D0401.giftno = Grouped.giftno and nowno=@nowno

	update intra3.dbo.pt1_D0401 set spend1=0 where nowno=@nowno and spend1 is null
	delete from  intra3.dbo.pt1_D0401 where nowno=@nowno and spend1=0 and spend=0 and lottery=0
	update intra3.dbo.pt1_D0401 set msum=lottery+spend1+spend,mtotal=ROUND((lottery+spend1+spend)*cost,0) where nowno=@nowno
	end
END

go

