CREATE VIEW dbo.v_ph1
AS
SELECT          dbo.ph1.pl1no, dbo.ph1.ph1date, dbo.ph1.pe1no, dbo.usr.usrname, dbo.usr.po2no, dbo.usr.post, dbo.ph1.ph1hrs, 
                            dbo.ph1.ph1memo, dbo.ph1.hl1no, dbo.ph1.sm1month, dbo.usr.dep, dbo.hl1.hl1name, dbo.hl1.hl1type, 
                            dbo.hl1.hl1mon, dbo.hl1.hl1hn
FROM              dbo.ph1 INNER JOIN
                            dbo.usr ON dbo.ph1.pe1no = dbo.usr.usrno INNER JOIN
                            dbo.hl1 ON dbo.ph1.hl1no = dbo.hl1.hl1no
go

