-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[pe1_B0812_3] (@nowno char(9),@bcode char(1),@ecode char(1),@edate datetime)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
delete from intra3.dbo.pe1_B0812_3
	create table #tmp (pe1no char(5),ye1nn decimal(6, 3))
	insert into #tmp (pe1no,ye1nn) select pe1no,sum(ye1nn) from ye1 group by pe1no
	--insert into intra3.dbo.pe1_B0812_3 (nowno,dp1no,dp3name,pe1no,usrname) select @nowno,dep,dp3name,usrno,usrname from usr where pf1lef is Null and pf1lun<>'Y' order by dep
	insert into intra3.dbo.pe1_B0812_3 (nowno,dp1no,dp3name,pe1no,po1no,usrname,pf1id,pf1bth,pf1ari,pw1a,pf1n1,ye1nn,pf1gnd,n2,pf1nno,mmon1,mmon2,mmon3,mmon4,pf1gover)
	 select @nowno,dep,dp3name,usrno,post,usrname,pf1id,pf1bth,pf1ari,0,0,0,pf1gnd,0,pf1nno,0,0,0,0,pf1gover from usr where pf1lef is Null and pf1lun<>'Y' AND po2no<>'B9' AND dep in (select dp1no from depcode where dp1over <> 'Y')order by dp1no,usrno,post
	 --update intra3.dbo.pe1_B0812_3 set pw1a=(select pw1a from pw1 where pw1.pe1no=pe1no AND pl1no='TOP') where dp1no='TOP'
	 update intra3.dbo.pe1_B0812_3 set pw1a=pw1.pw1a from intra3.dbo.pe1_B0812_3 inner join pw1 ON intra3.dbo.pe1_B0812_3.pe1no=pw1.pe1no where dp1no='TOP'
--update intra3.dbo.pe1_B0812_3 set pw1a=(select pw1a from pw2 where pw2.pe1no=pe1_B0812_3.pe1no AND pl1no=pe1_B0812_3.dp1no) where pe1_B0812_3.dp1no<>'TOP'
update intra3.dbo.pe1_B0812_3 set pw1a=pw2.pw1a from intra3.dbo.pe1_B0812_3 inner join pw2 ON intra3.dbo.pe1_B0812_3.pe1no=pw2.pe1no where intra3.dbo.pe1_B0812_3.dp1no<>'TOP'
--update intra3.dbo.ac3t4 set in1mon=d.bk1cah from intra3.dbo.ac3t4 inner join #tmp3 as d ON intra3.dbo.ac3t4.pl1no=d.pl1no
	 update intra3.dbo.pe1_B0812_3 set pw1a=0 where pw1a is null
	 update intra3.dbo.pe1_B0812_3 set ye1nn=(select top 1 ye1nn from #tmp where pe1no=pe1no)
	 drop table #tmp
END
go

