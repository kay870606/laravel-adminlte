-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[pe1_B0106] (@nowno char(9))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

delete from intra3.dbo.pe1_B0106 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
insert into intra3.dbo.pe1_B0106 (nowno,po1no,po1name,po1eng,po1mon,po4no,po4name,po1name2) select @nowno,po1no,po1name,po1eng,po1mon,po4no,(select po4name from po4 where po4no=postcode.po4no),po1name2 from postcode order by po1no

END
go

