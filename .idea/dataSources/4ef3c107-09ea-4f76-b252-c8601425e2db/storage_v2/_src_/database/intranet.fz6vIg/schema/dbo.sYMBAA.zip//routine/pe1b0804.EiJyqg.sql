-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[pe1b0804] (@nowno char(9),@yy char(4),@pl1no char(4))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

delete from intra3.dbo.pe1_b0804 where nowno=@nowno
if @pl1no=''
begin
	insert into intra3.dbo.pe1_b0804 (nowno,pl1no,pe1no,pf1ari,usrname) select @nowno,dep,usrno,pf1ari,usrname from usr where pf1lef is null order by dep,usrno
end
else
begin
	insert into intra3.dbo.pe1_b0804 (nowno,pl1no,pe1no,pf1ari,usrname) select @nowno,dep,usrno,pf1ari,usrname from usr where dep=@pl1no and pf1lef is null order by dep,usrno
end
select * from intra3.dbo.pe1_b0804 order by pl1no,pe1no
END
go

