-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[getac3t2] (@nowno char(9),@pl1no char(4),@ac3yy char(4),@bmm char(2),@emm char(2),@dp1lun char(1))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
	if (select object_id('tempdb..#tmp3'))is not null
	begin
		drop table #tmp3;
	end
	delete from intra3.dbo.ac3t32 where (nowno=@nowno and pl1no=@pl1no) or idate<CONVERT(nvarchar(30), GETDATE(), 111)
	create table #tmp (ac2no char(4),ac2no2 char(6),ac2name nvarchar(50),ad1dc char(1),ad1dmon decimal(12, 2),ad1cmon decimal(12, 2))

	insert into #tmp exec getac3t2g @nowno,@pl1no,@ac3yy,@bmm,@emm,@dp1lun
	select ac2no,ac2name into #tmp3 from #tmp group by ac2no,ac2name
	insert into intra3.dbo.ac3t32 (nowno,pl1no,ac3yy,ac2no,ac2no2,ac2name,ad1dmon,ad1cmon) select @nowno,@pl1no,@ac3yy,ac2no,left(ac2no,1),ac2name,0,0 from tempdb.#tmp3
	drop table #tmp
	drop table #tmp3
	update intra3.dbo.ac3t32 set ac2no1= case when ad1dmon>0 then '1' else '2' end where nowno=@nowno and pl1no=@pl1no
END
go

