-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[be1_a0804] (@nowno char(9),@pl1no char(4),@yymm char(4),@bcode char(8),@ecode char(8),@bb1bcode char(8),@bb1ecode char(8))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
delete from intra3.dbo.be1_a0304 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
if @bcode='' or @ecode='' or @bb1ecode=''or @bb1ecode=''
  begin
    insert into intra3.dbo.be1_a0304 (nowno,pl1no,bh1lst,bh1ser,bb1no,bh1count,bh1num,be1price,bh1mac,bb1not) select  @nowno,pl1no,bh1lst,bh1ser,bb1no,bh1count,bh1num,be1price,bh1mac,bb1not from intranet2.dbo.be1 where pl1no=@pl1no and left(bh1lst,4)=@yymm and be1bad<>'Y'
  end
else
  begin
    insert into intra3.dbo.be1_a0304 (nowno,pl1no,bh1lst,bh1ser,bb1no,bh1count,bh1num,be1price,bh1mac,bb1not) select @nowno,pl1no,bh1lst,bh1ser,bb1no,bh1count,bh1num,be1price,bh1mac,bb1not from intranet2.dbo.be1 where pl1no=@pl1no and left(bh1lst,4)=@yymm and bh1lst between @bcode and @ecode and be1bad<>'Y' and bb1no between @bb1bcode and @bb1ecode
  end
  create table #tmp (bd1no char(6),bb1name nvarchar(50),bb1eng nvarchar(50))
  insert into #tmp (bd1no,bb1name,bb1eng) select bb1no,bb1name,bb1eng from bb1
  update intra3.dbo.be1_a0304 set bb1name=(select bb1name from #tmp where bb1no=bd1no)
  update intra3.dbo.be1_a0304 set bb1eng=(select bb1eng from #tmp where bb1no=bd1no)
  drop table #tmp
END
go

