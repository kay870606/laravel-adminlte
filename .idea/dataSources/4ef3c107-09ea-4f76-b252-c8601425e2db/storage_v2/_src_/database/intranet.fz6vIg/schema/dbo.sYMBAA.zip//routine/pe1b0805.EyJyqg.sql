-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[pe1b0805] (@nowno char(9),@bmm char(2),@emm char(2),@bcode char(4))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	delete from intra3.dbo.pe1_b0805 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
	if @bcode=''
		insert into intra3.dbo.pe1_b0805 (nowno,pl1no,pl1name,pe1no,pe1name,pf1bth,pf1ari,po2no,lu1no) select @nowno,dep,(select dp1name from depcode as d where d.dp1no=usr.dep),usrno,usrname,pf1bth,pf1ari,po2no,(select dp1lun2 from depcode where dp1no=usr.dep) as lu1no from usr where month(pf1bth) between @bmm and @emm and pf1lef is null
	else
		insert into intra3.dbo.pe1_b0805 (nowno,pl1no,pl1name,pe1no,pe1name,pf1bth,pf1ari,po2no,lu1no) select @nowno,dep,(select dp1name from depcode as d where d.dp1no=usr.dep),usrno,usrname,pf1bth,pf1ari,po2no,(select dp1lun2 from depcode where dp1no=usr.dep) as lu1no from usr where month(pf1bth) between @bmm and @emm and dep=@bcode and pf1lef is null
	--update intra3.dbo.pe1_b0805 set lu1sort=(select DISTINCT lu1sort from lu1 where lu1.lu1no=lu1no group by lu1sort) where nowno=@nowno
	--select * from intra3.dbo.pe1_b0805 where nowno=@nowno order by lu1sort,pl1no
	select *,(select lu1sort from lu1 where lu1no=d.lu1no) as aa from intra3.dbo.pe1_b0805 as d where nowno=@nowno order by aa,pl1no
END
go

