CREATE VIEW dbo.v_po3
AS
SELECT          dbo.po3.po3num, dbo.po3.usrno, dbo.po3.po3date, dbo.po3.pl1no1, dbo.po3.po2no1, dbo.po3.po1name1, 
                            dbo.po3.post1, dbo.po3.po2name1, dbo.po3.pl1no2, dbo.po3.po2no2, dbo.po3.po1name2, dbo.po3.post2, 
                            dbo.po3.po2name2, dbo.po3.po3memo, dbo.po3.pl1no, dbo.po3.us1no, dbo.po3.po3idate, 
                            dbo.postcode.PO1NAME AS po2name, dbo.po2.po2name AS Expr1, dbo.po3.dp1no
FROM              dbo.po3 INNER JOIN
                            dbo.po2 ON dbo.po3.po2no1 = dbo.po2.po2no INNER JOIN
                            dbo.postcode ON dbo.po3.post1 = dbo.postcode.PO1NO
go

