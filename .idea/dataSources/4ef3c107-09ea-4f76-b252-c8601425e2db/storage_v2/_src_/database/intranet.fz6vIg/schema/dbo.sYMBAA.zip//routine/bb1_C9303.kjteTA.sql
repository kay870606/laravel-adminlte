-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[bb1_C9303] (@nowno char(9),@bcode char(4),@ecode char(4),@bpos char(1))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
delete from intra3.dbo.bb1C9301 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)

--if @bpos='1'
insert into intra3.dbo.bb1C9301 (nowno,ge1no,ge1no1,ge1name,pl1no,pl1name,gl1pi,gl1memo,dp1lun2) select @nowno,ge1no,(select ge1no1 from ge1 where ge1no=gl1.ge1no) AS ge1no1,(select ge1name from ge1 where ge1no=gl1.ge1no) AS ge1name ,pl1no,(select dp1name from depcode where dp1no=gl1.pl1no) AS pl1name,gl1pi,gl1memo,(select dp1lun2 from depcode where dp1no=gl1.pl1no) AS dp1lun2 from gl1 where pl1no between @bcode and @ecode
--else
--	insert into intra3.dbo.bb1C9301 (nowno,ge1no,ge1name,pl1no,pl1name,gl1pi,gl1memo,dp1lun2) select @nowno,ge1no,(select ge1name from ge1 where ge1no=intra3.dbo.ge1ch.ge1no)as ge1name,pl1no,(select dp1name from depcode where dp1no=pl1no)as pl1name,(gl1pi1+gl1pi4+gl1pia+gl1pi2+gl1pi3+gl1pi5+gl1pi6+gl1pi7+gl1pib) as gl1pi,(select gl1memo from gl1 where ge1no=intra3.dbo.ge1ch.ge1no and pl1no=intra3.dbo.ge1ch.pl1no)as gl1memo,(select dp1lun2 from depcode where DP1NO=pl1no)as dp1lun2 from intra3.dbo.ge1ch where pl1no between @bcode and @ecode order by ge1no1

END
go

