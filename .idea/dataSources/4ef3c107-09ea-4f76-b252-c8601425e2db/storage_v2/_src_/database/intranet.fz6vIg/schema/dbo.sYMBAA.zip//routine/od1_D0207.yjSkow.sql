-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[od1_D0207] (@nowno char(9),@type2 char(1),@pl1no char(4),@su1no char(4),@bcode char(14),@ecode char(14),@yymm char(6))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

delete from intra3.dbo.od1_D0207 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
if @type2='1'
insert into intra3.dbo.od1_D0207 (nowno,od1no,od1date,pt1no,pt1name,pt1qty,su1no,su1name,pl1no,pl1name,giftno) select @nowno,od1no,od1date,pt1no,pt1name,pt1qty,su1no,(select su1name from intranet.dbo.usu1 where su1no=uorder3.su1no),pl1no,(select dp1name from depcode where dp1no=pl1no),(select giftno from upt1 where pt1no=uorder3.pt1no)as giftno from intranet.dbo.uorder3 where left(od1no,6)=@yymm
if @type2='2'
insert into intra3.dbo.od1_D0207 (nowno,od1no,od1date,pt1no,pt1name,pt1qty,su1no,su1name,pl1no,pl1name,giftno) select @nowno,od1no,od1date,pt1no,pt1name,pt1qty,su1no,(select su1name from intranet.dbo.usu1 where su1no=uorder3.su1no),pl1no,(select dp1name from depcode where dp1no=pl1no),(select giftno from upt1 where pt1no=uorder3.pt1no)as giftno from intranet.dbo.uorder3 where left(od1no,6)=@yymm and su1no=@su1no
if @type2='3'
insert into intra3.dbo.od1_D0207 (nowno,od1no,od1date,pt1no,pt1name,pt1qty,su1no,su1name,pl1no,pl1name,giftno) select @nowno,od1no,od1date,pt1no,pt1name,pt1qty,su1no,(select su1name from intranet.dbo.usu1 where su1no=uorder3.su1no),pl1no,(select dp1name from depcode where dp1no=pl1no),(select giftno from upt1 where pt1no=uorder3.pt1no)as giftno from intranet.dbo.uorder3 where left(od1no,6)=@yymm and pl1no=@pl1no
if @type2='4'
insert into intra3.dbo.od1_D0207 (nowno,od1no,od1date,pt1no,pt1name,pt1qty,su1no,su1name,pl1no,pl1name,giftno) select @nowno,od1no,od1date,pt1no,pt1name,pt1qty,su1no,(select su1name from intranet.dbo.usu1 where su1no=@su1no),pl1no,(select dp1name from depcode where dp1no=pl1no),(select giftno from upt1 where pt1no=uorder3.pt1no)as giftno from intranet.dbo.uorder3 where left(od1no,6)=@yymm and od1no>=@bcode and od1no<=@ecode
if @type2='5'
insert into intra3.dbo.od1_D0207 (nowno,od1no,od1date,pt1no,pt1name,pt1qty,su1no,su1name,pl1no,pl1name,giftno) select @nowno,od1no,od1date,pt1no,pt1name,pt1qty,su1no,(select su1name from intranet.dbo.usu1 where su1no=@su1no),pl1no,(select dp1name from depcode where dp1no=pl1no),(select giftno from upt1 where pt1no=uorder3.pt1no)as giftno from intranet.dbo.uorder3 where left(od1no,6)=@yymm and pl1no=@pl1no and su1no=@su1no
if @type2='6'
insert into intra3.dbo.od1_D0207 (nowno,od1no,od1date,pt1no,pt1name,pt1qty,su1no,su1name,pl1no,pl1name,giftno) select @nowno,od1no,od1date,pt1no,pt1name,pt1qty,su1no,(select su1name from intranet.dbo.usu1 where su1no=@su1no),pl1no,(select dp1name from depcode where dp1no=pl1no),(select giftno from upt1 where pt1no=uorder3.pt1no)as giftno from intranet.dbo.uorder3 where left(od1no,6)=@yymm and su1no=@su1no and od1no>=@bcode and od1no<=@ecode
if @type2='7'
insert into intra3.dbo.od1_D0207 (nowno,od1no,od1date,pt1no,pt1name,pt1qty,su1no,su1name,pl1no,pl1name,giftno) select @nowno,od1no,od1date,pt1no,pt1name,pt1qty,su1no,(select su1name from intranet.dbo.usu1 where su1no=@su1no),pl1no,(select dp1name from depcode where dp1no=pl1no),(select giftno from upt1 where pt1no=uorder3.pt1no)as giftno from intranet.dbo.uorder3 where left(od1no,6)=@yymm and pl1no=@pl1no and od1no>=@bcode and od1no<=@ecode
if @type2='8'
insert into intra3.dbo.od1_D0207 (nowno,od1no,od1date,pt1no,pt1name,pt1qty,su1no,su1name,pl1no,pl1name,giftno) select @nowno,od1no,od1date,pt1no,pt1name,pt1qty,su1no,(select su1name from intranet.dbo.usu1 where su1no=@su1no),pl1no,(select dp1name from depcode where dp1no=pl1no),(select giftno from upt1 where pt1no=uorder3.pt1no)as giftno from intranet.dbo.uorder3 where left(od1no,6)=@yymm and pl1no=@pl1no and su1no=@su1no and od1no>=@bcode and od1no<=@ecode

END
go

