-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[te2_2] (@nowno char(9),@byy2 char(4))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

delete from intra3.dbo.te2 where nowno=@nowno or te2idate<CONVERT(nvarchar(30), GETDATE(), 111)
insert into intra3.dbo.te2 (nowno,te2yy,te0name,pl1no,pe1no,pe1name,te1range,te3mm,te3mon) select DISTINCT @nowno,te2yy,te0name,pl1no,pe1no,pe1name,te1range,te3mm,te3mon from te2 where te2yy=@byy2 and pe1no <>''

update intra3.dbo.te2 set dp1lun2=d.dp1lun2 from intra3.dbo.te2 inner join depcode as d ON intra3.dbo.te2.pl1no=d.dp1no
update intra3.dbo.te2 set pl1no2=d.dep from intra3.dbo.te2 inner join usr as d ON intra3.dbo.te2.pe1no=d.usrno
update intra3.dbo.te2 set lu1sort=d.lu1sort from intra3.dbo.te2 inner join lu1 as d ON intra3.dbo.te2.dp1lun2=d.lu1no
update intra3.dbo.te2 set dp1lun22=d.dp1lun2 from intra3.dbo.te2 inner join depcode as d ON intra3.dbo.te2.pl1no2=d.dp1no
update intra3.dbo.te2 set lu1sort2=d.lu1sort from intra3.dbo.te2 inner join lu1 as d ON intra3.dbo.te2.dp1lun22=d.lu1no
update intra3.dbo.te2 set te1pi=d.te1pi from intra3.dbo.te2 inner join te1 as d ON intra3.dbo.te2.pe1no=d.pe1no and intra3.dbo.te2.pl1no=d.pl1no and intra3.dbo.te2.te0name=d.te0name
update intra3.dbo.te2 set dp1lun22='' where dp1lun22 is null
update intra3.dbo.te2 set lu1sort2='' where lu1sort2 is null
update intra3.dbo.te2 set pl1no2='' where pl1no2 is null
END
go

