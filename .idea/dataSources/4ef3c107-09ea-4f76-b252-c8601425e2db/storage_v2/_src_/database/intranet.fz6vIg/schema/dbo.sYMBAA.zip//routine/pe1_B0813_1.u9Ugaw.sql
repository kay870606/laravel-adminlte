-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[pe1_B0813_1] (@nowno char(9),@dp3name char(50),@bdate datetime,@edate datetime)
AS
BEGIN
	SET NOCOUNT ON;

delete from intra3.dbo.pe1_B0813_1
insert into intra3.dbo.pe1_B0813_1 (nowno,dep,pe1no,usrname,pf1id,pf1bth,pf1ari,pf1lef,pf1gnd,pf1gnl,pf1nno,pf1out_d,pf1out_e,mon2,mon7,mon5,pf1gover,pf1pmon)
--pf1gnl= 退保日  pf1gnd 投保日
select @nowno,dep,usrno,usrname,pf1id,pf1bth,pf1ari,pf1lef,pf1gnd,pf1gnl,pf1nno,pf1out_d,pf1out_e,pf1pi,0,0,pf1gover,pf1pmon from usr where pf1yn4<>'Y' AND dp3name=@dp3name AND ((pf1lef is NULL or (pf1lef is not null and (pf1gnl>=@bdate or pf1gnl is null)))  or (pf1lef is not null and pf1leave='Y' and pf1gnl is null))  AND pf1gnd<=@edate AND dep in (select dp1no from depcode where dp1over <> 'Y')
insert into intra3.dbo.pe1_B0813_1 (nowno,dep,pe1no,usrname,pf1id,pf1bth,pf1ari,pf1lef,pf1gnd,pf1gnl,pf1nno,pf1out_d,pf1out_e,mon2,mon7,mon5,pf1gover,pf1pmon)
select @nowno,pl1no,'',usrname,pf1id,pf1bth,null,null,pf1gnd,pf1gnl,pf1nno,pf1out_d,pf1out_e,pf1pi,0,0,'N',0 from pe2 where dp3name=@dp3name AND pf1gnd<=@edate AND pl1no in (select dp1no from depcode where dp1over <> 'Y')

UPDATE
    intra3.dbo.pe1_B0813_1
SET
    intra3.dbo.pe1_B0813_1.pf1gnd = intranet2.dbo.pe4.pf1gnd2,
    intra3.dbo.pe1_B0813_1.pf1gnl = intranet2.dbo.pe4.pf1gnl2,
	 intra3.dbo.pe1_B0813_1.pf1nno = intranet2.dbo.pe4.pf1nno2,
 intra3.dbo.pe1_B0813_1.pf1out_d = intranet2.dbo.pe4.pf1out_d2,
  intra3.dbo.pe1_B0813_1.pf1out_e = intranet2.dbo.pe4.pf1out_e2,
    intra3.dbo.pe1_B0813_1.mon2 = intranet2.dbo.pe4.pf1pi2
FROM
    intra3.dbo.pe1_B0813_1 INNER JOIN  intranet2.dbo.pe4
        ON intra3.dbo.pe1_B0813_1.pe1no = intranet2.dbo.pe4.usrno
WHERE
    intra3.dbo.pe1_B0813_1.nowno = @nowno and intranet2.dbo.pe4.dp3name2=@dp3name and
	convert(varchar(6),intranet2.dbo.pe4.pf1gnd2,112) =convert(varchar(6),@bdate,112)

UPDATE
    intra3.dbo.pe1_B0813_1
SET
    intra3.dbo.pe1_B0813_1.pf1gnd = intranet2.dbo.pe4.pf1gnd,
    intra3.dbo.pe1_B0813_1.pf1gnl = intranet2.dbo.pe4.pf1gnl,
	 intra3.dbo.pe1_B0813_1.pf1nno = intranet2.dbo.pe4.pf1nno,
 intra3.dbo.pe1_B0813_1.pf1out_d = intranet2.dbo.pe4.pf1out_d,
  intra3.dbo.pe1_B0813_1.pf1out_e = intranet2.dbo.pe4.pf1out_e,
    intra3.dbo.pe1_B0813_1.mon2 = intranet2.dbo.pe4.pf1pi
FROM
    intra3.dbo.pe1_B0813_1 INNER JOIN  intranet2.dbo.pe4
        ON intra3.dbo.pe1_B0813_1.pe1no = intranet2.dbo.pe4.usrno
WHERE
    intra3.dbo.pe1_B0813_1.nowno = @nowno and intranet2.dbo.pe4.dp3name=@dp3name and
	convert(varchar(6),intranet2.dbo.pe4.pf1gnl,112) =convert(varchar(6),@bdate,112)

insert into intra3.dbo.pe1_B0813_1 (nowno,dep,pe1no,usrname,pf1id,pf1bth,pf1ari,pf1lef,pf1gnd,pf1gnl,pf1nno,pf1out_d,pf1out_e,mon2,mon7,mon5,pf1gover,pf1pmon)
select @nowno,pl1no,usrno,usrname,(select pf1id from usr where usrno=intranet2.dbo.pe4.usrno),(select pf1bth from usr where usrno=intranet2.dbo.pe4.usrno),(select pf1ari from usr where usrno=intranet2.dbo.pe4.usrno),(select pf1lef from usr where usrno=intranet2.dbo.pe4.usrno),pf1gnd,pf1gnl,pf1nno,pf1out_d,pf1out_e,pf1pi,0,0,(select pf1gover from usr where usrno=intranet2.dbo.pe4.usrno),(select pf1pmon from usr where usrno=intranet2.dbo.pe4.usrno)from intranet2.dbo.pe4 where dp3name=@dp3name and convert(varchar(6),pf1gnl,112) =convert(varchar(6),@bdate,112) and not exists (select pe1no from intra3.dbo.pe1_B0813_1 where nowno=@nowno and pe1no=intranet2.dbo.pe4.usrno)

insert into intra3.dbo.pe1_B0813_1 (nowno,dep,pe1no,usrname,pf1id,pf1bth,pf1ari,pf1lef,pf1gnd,pf1gnl,pf1nno,pf1out_d,pf1out_e,mon2,mon7,mon5,pf1gover,pf1pmon)
select @nowno,pl1no2,usrno,usrname,(select pf1id from usr where usrno=intranet2.dbo.pe4.usrno),(select pf1bth from usr where usrno=intranet2.dbo.pe4.usrno),(select pf1ari from usr where usrno=intranet2.dbo.pe4.usrno),(select pf1lef from usr where usrno=intranet2.dbo.pe4.usrno),pf1gnd2,pf1gnl2,pf1nno2,pf1out_d2,pf1out_e2,pf1pi2,0,0,(select pf1gover from usr where usrno=intranet2.dbo.pe4.usrno),(select pf1pmon from usr where usrno=intranet2.dbo.pe4.usrno)from intranet2.dbo.pe4 where dp3name2=@dp3name and convert(varchar(6),pf1gnd2,112) =convert(varchar(6),@bdate,112)  and  not exists (select pe1no from intra3.dbo.pe1_B0813_1 where nowno=@nowno and pe1no=intranet2.dbo.pe4.usrno)

----------------------------------------------------2019/04/29 調店分攤

UPDATE
    intra3.dbo.pe1_B0813_1
SET
    intra3.dbo.pe1_B0813_1.dep = intranet2.dbo.pe4.pl1no,
	 intra3.dbo.pe1_B0813_1.pf1gnl = DATEADD(day,-1,intranet2.dbo.pe4.pe4edate),
	intra3.dbo.pe1_B0813_1.ta1memo ='調店='+pl1no+'到'+pl1no2+'，調店日期='+ convert(varchar,pe4edate,111)
FROM
    intra3.dbo.pe1_B0813_1 INNER JOIN  intranet2.dbo.pe4
        ON intra3.dbo.pe1_B0813_1.pe1no = intranet2.dbo.pe4.usrno
WHERE
    intra3.dbo.pe1_B0813_1.nowno = @nowno and intranet2.dbo.pe4.dp3name=@dp3name and
	convert(varchar(6),intranet2.dbo.pe4.pe4edate,112)=convert(varchar(6),@bdate,112) and pl1no<>pl1no2


insert into intra3.dbo.pe1_B0813_1 (nowno,dep,pe1no,usrname,pf1id,pf1bth,pf1ari,pf1lef,pf1gnd,pf1gnl,pf1nno,pf1out_d,pf1out_e,mon2,mon7,mon5,pf1gover,pf1pmon,ta1memo)
select @nowno,pl1no2,usrno,usrname,(select pf1id from usr where usrno=intranet2.dbo.pe4.usrno),(select pf1bth from usr where usrno=intranet2.dbo.pe4.usrno),(select pf1ari from usr where usrno=intranet2.dbo.pe4.usrno),(select pf1lef from usr where usrno=intranet2.dbo.pe4.usrno),pe4edate,pf1gnl2,pf1nno2,pf1out_d2,pf1out_e2,pf1pi2,0,0,(select pf1gover from usr where usrno=intranet2.dbo.pe4.usrno),(select pf1pmon from usr where usrno=intranet2.dbo.pe4.usrno),'調店='+pl1no+'到'+pl1no2+'，調店日期='+ convert(varchar,pe4edate,111) from intranet2.dbo.pe4 where dp3name2=@dp3name and dp3name=dp3name2 and convert(varchar(6),pe4edate,112)=convert(varchar(6),@bdate,112) and pl1no<>pl1no2
-------------------------------------------------------------------------------------------

update intra3.dbo.pe1_B0813_1 set pw1a=(select top 1 pw1a from pw1 where pw1.pe1no=intra3.dbo.pe1_B0813_1.pe1no) where dep='TOP'
update intra3.dbo.pe1_B0813_1 set pw1a=(select top 1 pw1a from pw2 where pw2.pe1no=intra3.dbo.pe1_B0813_1.pe1no AND pw2.pl1no=intra3.dbo.pe1_B0813_1.dep) where dep<>'TOP'
END
go

