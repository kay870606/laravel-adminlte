-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[bb1_C9309] (@nowno char(9),@pe1no char(5),@gl3month char(6),@gl3t3040 char(6),@fucno char(5))

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp;
	end
	delete from intra3.dbo.bb1C9309 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)

	create table #tmp (pl1no char(4),gl3month char(6),gl3t3040 char(6),ge1no char(5),gl1pi decimal(9, 4),gl4mon decimal(8, 0),gl4mon2 decimal(8, 0))

	insert into #tmp (pl1no,gl3month,gl3t3040,ge1no,gl1pi,gl4mon,gl4mon2) select pl1no,gl3month,gl3t3040,ge1no,gl1pi,gl4mon,gl4mon2 from gl4 where gl4mon>0 and gl3month=@gl3month
	if @gl3t3040='A'
		insert into intra3.dbo.bb1C9309 (nowno,gl3t3040,pl1no,ge1no1,ge1no,ge1name,gl1pi,gl4mon,gl4mon2,gl3mon,gl3mon2) select @nowno,gl3t3040,pl1no,(select ge1no1 from ge1 where ge1no=#tmp.ge1no),ge1no,(select ge1name from ge1 where ge1no=#tmp.ge1no),gl1pi,gl4mon,gl4mon2,(select gl3mon from gl3 where gl3.pl1no=#tmp.pl1no and gl3.gl3month=#tmp.gl3month and gl3.gl3t3040=#tmp.gl3t3040),(select gl3mon2 from gl3 where gl3.pl1no=#tmp.pl1no and gl3.gl3month=#tmp.gl3month and gl3.gl3t3040=#tmp.gl3t3040) from #tmp where pl1no in (select pl1no from intra3.dbo.bb1C9309_2 where pe1no=@pe1no and fucno=@fucno)
	else
		insert into intra3.dbo.bb1C9309 (nowno,gl3t3040,pl1no,ge1no1,ge1no,ge1name,gl1pi,gl4mon,gl4mon2,gl3mon,gl3mon2) select @nowno,gl3t3040,pl1no,(select ge1no1 from ge1 where ge1no=#tmp.ge1no),ge1no,(select ge1name from ge1 where ge1no=#tmp.ge1no),gl1pi,gl4mon,gl4mon2,(select gl3mon from gl3 where gl3.pl1no=#tmp.pl1no and gl3.gl3month=#tmp.gl3month and gl3.gl3t3040=#tmp.gl3t3040),(select gl3mon2 from gl3 where gl3.pl1no=#tmp.pl1no and gl3.gl3month=#tmp.gl3month and gl3.gl3t3040=#tmp.gl3t3040) from #tmp where pl1no in (select pl1no from intra3.dbo.bb1C9309_2 where pe1no=@pe1no and fucno=@fucno)

	drop table #tmp
	update intra3.dbo.bb1C9309 set dep='' where nowno=@nowno and dep is null
	update intra3.dbo.bb1C9309 set usrno=(select usrno from ge1 where ge1no=intra3.dbo.bb1C9309.ge1no and pl1no='') where nowno=@nowno
	update intra3.dbo.bb1C9309 set usrno='' where nowno=@nowno and usrno is null
	update intra3.dbo.bb1C9309 set dep=(select dep from usr where usrno=intra3.dbo.bb1C9309.usrno) where nowno=@nowno and dep=''
	update intra3.dbo.bb1C9309 set dep='' where nowno=@nowno and dep is null
--	update intra3.dbo.bb1C9309 set lu1name=(select lu1name from lu1 where lu1no in (select dp1lun2 from depcode where dp1no=intra3.dbo.bb1C9309.dep)) where nowno=@nowno
END
go

