CREATE VIEW dbo.v_ko1
AS
SELECT          dbo.ko1.su1no AS Expr1, dbo.su1.su1addr, dbo.su1.su1name, dbo.ko1.su1mon, dbo.ap1.ap1ym AS Expr2
FROM              dbo.ko1 INNER JOIN
                            dbo.su1 ON dbo.ko1.su1no = dbo.su1.su1no INNER JOIN
                            dbo.ap1 ON dbo.ko1.ap1ym = dbo.ap1.ap1ym
go

