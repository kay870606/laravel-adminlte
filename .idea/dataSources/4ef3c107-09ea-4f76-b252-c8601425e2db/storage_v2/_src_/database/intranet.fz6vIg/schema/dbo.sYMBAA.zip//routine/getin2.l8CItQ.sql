-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[getin2] (@nowno char(9),@pl1no char(4), @yy char(4), @mm char(2),@mon21 int, @sy1deli char(1))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
 delete from intra3.dbo.in2d where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)

 if(@sy1deli='Y')
 begin
insert into intra3.dbo.in2d (nowno,pl1no,bk1date,bk1wek,bk1cah,bk1oth2,bk1oth,bk1opn,bk1not,bk1mon2,bk1mon3,bk1cash1,bk1cash2) select @nowno,pl1no,bk1date,bk1wek,round(bk1cah/@mon21,2),round(bk1oth2/@mon21,2),round(bk1oth/@mon21,2),round(bk1opn/@mon21,2),bk1not,round(bk1mon2/@mon21,2),round(bk1mon3/@mon21,2),round(bk1cash1/@mon21,2),round(bk1cash2/@mon21,2) from intranet2.dbo.in2 where pl1no=@pl1no and year(bk1date)=@yy and month(bk1date)=@mm order by bk1date
end
else
begin
insert into intra3.dbo.in2d (nowno,pl1no,bk1date,bk1wek,bk1cah,bk1oth2,bk1oth,bk1opn,bk1not,bk1mon2,bk1mon3,bk1cash1,bk1cash2) select @nowno,pl1no,bk1date,bk1wek,round(bk1cah/@mon21,0),round(bk1oth2/@mon21,0),round(bk1oth/@mon21,0),round(bk1opn/@mon21,0),bk1not,round(bk1mon2/@mon21,0),round(bk1mon3/@mon21,0),round(bk1cash1/@mon21,0),round(bk1cash2/@mon21,0) from intranet2.dbo.in2 where pl1no=@pl1no and year(bk1date)=@yy and month(bk1date)=@mm order by bk1date
end
END
go

