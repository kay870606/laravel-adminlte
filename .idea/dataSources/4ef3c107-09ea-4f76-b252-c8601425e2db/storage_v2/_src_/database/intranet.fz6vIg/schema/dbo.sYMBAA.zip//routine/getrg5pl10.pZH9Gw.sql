-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[getrg5pl10] (@pe1no char(5),@fu1no char(5))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	if (select object_id('tempdb..#tmp'))is not null
	begin
		drop table #tmp
	end
	if (select object_id('tempdb..#tmp_pl1'))is not null
	begin
		drop table #tmp_pl1
	end
	if (select object_id('tempdb..#tmp_lu1'))is not null
	begin
		drop table #tmp_lu1
	end
	if (select object_id('tempdb..#tmp_usr'))is not null
	begin
		drop table #tmp_usr
	end
	------本店usr
	select rg6.pl1no,rg6.rg5add,rg6.rg5edit,rg6.rg5del,rg6.rg5report,dp1.dp1name as pl1name,dp1.dp1lun,dp1.dp1lun2,dp1.dp1sort,dp1.dp1over,dp1.dp1yn,dp1.dp1yn2 into #tmp from rg6,depcode as dp1 where rg6.pl1no=dp1.dp1no and rg6.fu1no=@fu1no and rg6.pe1no=@pe1no
insert into tempdb.#tmp (pl1no,pl1name,dp1lun,dp1lun2,dp1sort,dp1over,dp1yn,dp1yn2,rg5add,rg5edit,rg5del,rg5report) select dp1no,dp1name,dp1lun,dp1lun2,dp1sort,dp1over,dp1yn,dp1yn2,'Y','Y','Y','Y' from depcode where CHARINDEX(dp1lun, (SELECT usrlun from usr where usrno=@pe1no)) > 0  and dp1no not in (select pl1no from tempdb.#tmp)

	select rg5pl1.pl1no,dp1.dp1name  as pl1name,dp1.dp1lun,dp1.dp1lun2,dp1.dp1sort,dp1.dp1over,dp1.dp1yn,dp1.dp1yn2 into #tmp_pl1 from rg5pl1,depcode as dp1 where rg5pl1.pl1no=dp1.dp1no and rg5pl1.pe1no=@pe1no and rg5pl1.pl1no not in (select pl1no from tempdb.#tmp)
	insert into tempdb.#tmp (pl1no,pl1name,dp1lun,dp1lun2,dp1sort,dp1over,dp1yn,dp1yn2,rg5add,rg5edit,rg5del,rg5report) select pl1no,pl1name,dp1lun,dp1lun2,dp1sort,dp1over,dp1yn,dp1yn2,'Y','Y','Y','Y' from tempdb.#tmp_pl1

	select dp1.dp1no as pl1no,dp1.dp1name as pl1name,dp1.dp1lun,dp1.dp1lun2,dp1.dp1sort,dp1.dp1over,dp1.dp1yn,dp1.dp1yn2 into #tmp_lu1 from rg5lu1,depcode as dp1 where rg5lu1.lu1no=dp1.dp1lun2 and rg5lu1.pe1no=@pe1no and dp1.dp1no not in (select pl1no from tempdb.#tmp)
	insert into tempdb.#tmp (pl1no,pl1name,dp1lun,dp1lun2,dp1sort,dp1over,dp1yn,dp1yn2,rg5add,rg5edit,rg5del,rg5report) select pl1no,pl1name,dp1lun,dp1lun2,dp1sort,dp1over,dp1yn,dp1yn2,'Y','Y','Y','Y' from tempdb.#tmp_lu1

	select dp1.dp1no as pl1no,dp1.dp1name as pl1name,dp1.dp1lun,dp1.dp1lun2,dp1.dp1sort,dp1.dp1over,dp1.dp1yn,dp1.dp1yn2 into #tmp_usr from usr,depcode as dp1 where usr.dep=dp1.dp1no and usr.usrno=@pe1no and usr.dep not in (select pl1no from tempdb.#tmp)
	insert into tempdb.#tmp (pl1no,pl1name,dp1lun,dp1lun2,dp1sort,dp1over,dp1yn,dp1yn2,rg5add,rg5edit,rg5del,rg5report) select pl1no,pl1name,dp1lun,dp1lun2,dp1sort,dp1over,dp1yn,dp1yn2,'Y','Y','Y','Y' from tempdb.#tmp_usr

	delete from tempdb.#tmp where pl1no in (select pl1no from intranet.dbo.rg5pl1d where pe1no=@pe1no)
	if(LEFT(@fu1no,1)='A' or LEFT(@fu1no,1)='0')
	begin
	select DISTINCT t.dp1lun2 as lu1no,lu1.lu1name,lu1.lu1lun,lu1.lu1sort from tempdb.#tmp as t,lu1 where t.dp1lun2=lu1.lu1no and t.dp1lun2<>'97' and t.dp1lun2<>'98'and t.dp1lun2<>'99' order by lu1.lu1sort
	end
	else
	begin
	select DISTINCT t.dp1lun2 as lu1no,lu1.lu1name,lu1.lu1lun,lu1.lu1sort from tempdb.#tmp as t,lu1 where t.dp1lun2=lu1.lu1no order by lu1.lu1sort
	end
	
	drop table #tmp
	drop table #tmp_pl1
	drop table #tmp_lu1
	drop table #tmp_usr

END
go

