-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[od1_D0204_2] (@nowno char(9),@mark char(5))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

delete from intra3.dbo.od1_D0204_2 where nowno=@nowno or idate<CONVERT(nvarchar(30), GETDATE(), 111)
insert into intra3.dbo.od1_D0204_2 (nowno,od1no,od1date,pt1no,pt1name,pt1qty,pt1cost,pl1no,pl1name,mark) select @nowno,od1no,left(od1date,16),pt1no,pt1name,pt1qty,pt1cost,pl1no,(select dp1name from depcode where dp1no=pl1no),(select mark from upt1 where od1no=uorder.od1no and pt1no=uorder.pt1no) from intranet.dbo.uorder
if @mark='true'
delete from intra3.dbo.od1_D0204_2 where mark = 'Y'
END
go

